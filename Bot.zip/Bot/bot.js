const { Client, GatewayIntentBits, EmbedBuilder, PermissionFlagsBits, SlashCommandBuilder, REST, Routes, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, AuditLogEvent, Collection, StringSelectMenuBuilder, ActivityType, MessageFlags, Partials, VoiceChannel, VoiceState, NoSubscriberBehavior, StreamType, generateDependencyReport, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const moment = require('moment');
const sqlite3 = require('sqlite3').verbose();

// =======================
// CONFIGURATION SYSTEM
// =======================
class ConfigManager {
    constructor() {
        this.configPath = './config.json';
        this.defaultConfig = {
            DISCORD_TOKEN: '',
            OPENWEATHER_API_KEY: '',
            GUILD_ID: '',
            SUPER_ADMINS: [],
            BOT_OWNER_ID: '',
            BOT_STATUS: 'online',
            BOT_ACTIVITY_NAME: 'Made by Hopingboyz ⭐ | /help',
            BOT_ACTIVITY_TYPE: 3,
            BOT_WATERMARK: 'Made by Hopingboyz ⭐',
            BOT_NAME: 'Advanced Security Bot',
            ANTI_NUKE: {
                enabled: true,
                max_roles_per_minute: 3,
                max_channels_per_minute: 3,
                max_bans_per_minute: 2,
                max_kicks_per_minute: 2,
                punishment: 'ban',
                log_channel: '',
                auto_revert: true
            },
            ANTI_SPAM: {
                enabled: true,
                max_messages: 5,
                time_window: 5000,
                max_duplicates: 3,
                max_mentions: 5,
                max_links: 2,
                punishment: 'timeout'
            },
            BAD_WORDS: ['nigga', 'fuck', 'shit', 'bitch', 'ass', 'damn'],
            WELCOME_MESSAGE: 'Welcome {user} to {server}!',
            GOODBYE_MESSAGE: '{user} has left {server}.',
            DM_ROLE_NOTIFICATION: '@everyone',
            EMBED_COLORS: {
                PRIMARY: 0x2F3136,
                SUCCESS: 0x57F287,
                ERROR: 0xED4245,
                WARNING: 0xFEE75C,
                INFO: 0x5865F2,
                PURPLE: 0x9B59B6
            },
            STATUS_MONITOR_INTERVAL: 300000,
            CLEANUP_INTERVAL: 3600000
        };
        this.loadConfig();
    }

    loadConfig() {
        if (!fs.existsSync(this.configPath)) {
            console.log('Creating default config file...');
            fs.writeFileSync(this.configPath, JSON.stringify(this.defaultConfig, null, 4));
            console.log('Please edit config.json with your settings and restart the bot.');
            process.exit(1);
        }
        
        const configData = JSON.parse(fs.readFileSync(this.configPath, 'utf8'));
        this.config = { ...this.defaultConfig, ...configData };
        
        if (!this.config.DISCORD_TOKEN) {
            console.error('DISCORD_TOKEN not set in config.json.');
            process.exit(1);
        }
        
        // Ensure arrays exist
        if (!Array.isArray(this.config.SUPER_ADMINS)) this.config.SUPER_ADMINS = [];
        if (!Array.isArray(this.config.BAD_WORDS)) this.config.BAD_WORDS = this.defaultConfig.BAD_WORDS;
        
        return this.config;
    }

    saveConfig() {
        fs.writeFileSync(this.configPath, JSON.stringify(this.config, null, 4));
    }

    isSuperAdmin(userId) {
        return this.config.SUPER_ADMINS.includes(userId) || userId === this.config.BOT_OWNER_ID;
    }

    addSuperAdmin(userId) {
        if (!this.isSuperAdmin(userId)) {
            this.config.SUPER_ADMINS.push(userId);
            this.saveConfig();
            return true;
        }
        return false;
    }

    removeSuperAdmin(userId) {
        const index = this.config.SUPER_ADMINS.indexOf(userId);
        if (index > -1 && userId !== this.config.BOT_OWNER_ID) {
            this.config.SUPER_ADMINS.splice(index, 1);
            this.saveConfig();
            return true;
        }
        return false;
    }
}

const configManager = new ConfigManager();
const config = configManager.config;

// =======================
// CLIENT INITIALIZATION
// =======================
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,        // PRIVILEGED - Enable in Discord Portal
        GatewayIntentBits.GuildMembers,          // PRIVILEGED - Enable in Discord Portal
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildVoiceStates,
        // GatewayIntentBits.GuildPresences,     // PRIVILEGED - Commented out (not essential)
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.DirectMessageReactions,
        GatewayIntentBits.GuildIntegrations,
        GatewayIntentBits.DirectMessageTyping
    ],
    partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.User]
});

// Colors from config
const COLORS = config.EMBED_COLORS || {
    PRIMARY: 0x2F3136,
    SUCCESS: 0x57F287,
    ERROR: 0xED4245,
    WARNING: 0xFEE75C,
    INFO: 0x5865F2,
    PURPLE: 0x9B59B6
};

// Unified embed factory for a professional, consistent look
function createEmbed({ title = '', description = '', color = COLORS.PRIMARY, fields = [], thumbnail = null, image = null, footer = null, author = null, timestamp = true }) {
    const e = new EmbedBuilder()
        .setColor(color || COLORS.PRIMARY);

    if (title) e.setTitle(title);
    if (description) e.setDescription(description);

    if (Array.isArray(fields) && fields.length > 0) {
        // Normalize fields to { name, value, inline }
        const normalized = fields.map(f => {
            if (!f) return null;
            if (typeof f === 'string') return { name: '\u200b', value: f, inline: false };
            return { name: f.name || '\u200b', value: f.value || '\u200b', inline: !!f.inline };
        }).filter(Boolean);
        if (normalized.length) e.addFields(...normalized);
    }

    if (thumbnail) e.setThumbnail(thumbnail);
    if (image) e.setImage(image);

    const footerText = footer || config.BOT_WATERMARK || config.BOT_NAME || 'Powered by Hopingboyz';
    e.setFooter({ text: footerText });

    if (author) {
        e.setAuthor({ name: author.name || author, iconURL: author.iconURL || null });
    }

    if (timestamp) e.setTimestamp();

    return e;
}

// Emojis
const EMOJIS = {
    success: '✅',
    error: '❌',
    warning: '⚠️',
    shield: '🛡️',
    info: 'ℹ️',
    gear: '⚙️',
    crown: '👑',
    envelope: '✉️',
    megaphone: '📢',
    lock: '🔒',
    hammer: '🔨',
    robot: '🤖',
    star: '⭐',
    gift: '🎁',
    timer: '⏰',
    users: '👥',
    channel: '📺',
    role: '🎭',
    ping: '🏓',
    weather: '🌤️',
    translate: '🌐',
    currency: '💱',
    qrcode: '📱',
    poll: '📊',
    reminder: '⏰',
    suggestion: '💡',
    afk: '😴',
    invite: '📨',
    verification: '✅',
    stats: '📊',
    play: '▶️',
    pause: '⏸️',
    stop: '⏹️',
    skip: '⏭️',
    volume: '🔊',
    repeat: '🔁',
    shuffle: '🔀',
    queue: '📋',
    search: '🔍',
    headphones: '🎧',
    microphone: '🎤',
    playlist: '📝',
    download: '📥',
    clock: '🕒',
    music: '🎵',
    previous: '⏮️',
    next: '⏭️',
    loop_one: '🔂',
    autoplay: '🔄',
    filter: '🎛️',
    lyrics: '📜',
    radio: '📻'
};

// Activity Type Mapper
function getActivityType(typeNum) {
    switch (typeNum) {
        case 0: return ActivityType.Playing;
        case 1: return ActivityType.Streaming;
        case 2: return ActivityType.Listening;
        case 3: return ActivityType.Watching;
        case 5: return ActivityType.Competing;
        default: return ActivityType.Playing;
    }
}

// Sanitize outgoing text to prevent the bot from mentioning @everyone, @here, users, or roles
function sanitizeMentions(text) {
    if (!text || typeof text !== 'string') return text;
    // Replace @everyone and @here with zero-width space to prevent mentions
    text = text.replace(/@everyone/gi, '@\u200beveryone').replace(/@here/gi, '@\u200bhere');
    // Replace Discord mention tags <@userid> and <@&roleid> with zero-width space
    text = text.replace(/<@!?(\d+)>/g, '<@\u200b$1>').replace(/<@&(\d+)>/g, '<@&\u200b$1>');
    return text;
}

// =======================
// DATABASE SYSTEM
// =======================
class Database {
    constructor() {
        this.db = new sqlite3.Database('./bot.db');
        this.initDatabase();
    }

    initDatabase() {
        this.db.serialize(() => {
            // Super Admins (separate from config)
            this.db.run(`CREATE TABLE IF NOT EXISTS super_admins (
                user_id TEXT PRIMARY KEY,
                added_by TEXT,
                added_at TEXT
            )`);

            // Extra Owners System
            this.db.run(`CREATE TABLE IF NOT EXISTS extra_owners (
                guild_id TEXT,
                user_id TEXT,
                added_by TEXT,
                added_at TEXT,
                PRIMARY KEY (guild_id, user_id)
            )`);

            // Anti-Nuke System
            this.db.run(`CREATE TABLE IF NOT EXISTS antinuke_config (
                guild_id TEXT PRIMARY KEY,
                enabled INTEGER DEFAULT 1,
                punishment TEXT DEFAULT 'ban',
                log_channel_id TEXT,
                revert_actions INTEGER DEFAULT 1,
                alert_threshold INTEGER DEFAULT 2,
                limits TEXT DEFAULT '{"role_create":1,"role_delete":1,"role_update":1,"channel_create":1,"channel_delete":1,"channel_update":1,"ban":2,"kick":2,"member_update":1,"emoji_create":1,"emoji_delete":1,"emoji_update":1,"webhook_create":2,"webhook_delete":2,"webhook_update":2,"sticker_create":1,"sticker_delete":1,"sticker_update":1,"invite_create":5,"invite_delete":5,"guild_update":1}',
                whitelist_enabled INTEGER DEFAULT 1
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS antinuke_whitelist (
                guild_id TEXT,
                user_id TEXT,
                added_by TEXT,
                added_at TEXT,
                PRIMARY KEY (guild_id, user_id)
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS antinuke_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT,
                user_id TEXT,
                action_type TEXT,
                timestamp TEXT,
                details TEXT,
                prevented INTEGER DEFAULT 0
            )`);

            // Anti-Spam System
            this.db.run(`CREATE TABLE IF NOT EXISTS antispam_config (
                guild_id TEXT PRIMARY KEY,
                enabled INTEGER DEFAULT 1,
                punishment TEXT DEFAULT 'timeout',
                message_threshold INTEGER DEFAULT 5,
                time_window INTEGER DEFAULT 5000,
                duplicate_threshold INTEGER DEFAULT 3,
                mention_threshold INTEGER DEFAULT 5,
                link_threshold INTEGER DEFAULT 2,
                warn_before_punish INTEGER DEFAULT 1,
                exempt_roles TEXT DEFAULT '[]',
                exempt_channels TEXT DEFAULT '[]'
            )`);

            // Bad Words Filter
            this.db.run(`CREATE TABLE IF NOT EXISTS bad_words_config (
                guild_id TEXT PRIMARY KEY,
                enabled INTEGER DEFAULT 1,
                words TEXT DEFAULT '[]',
                exempt_roles TEXT DEFAULT '[]',
                exempt_channels TEXT DEFAULT '[]',
                action TEXT DEFAULT 'delete',
                custom_message TEXT DEFAULT 'Watch your language!'
            )`);

            // Welcome/Goodbye
            this.db.run(`CREATE TABLE IF NOT EXISTS welcome_config (
                guild_id TEXT PRIMARY KEY,
                enabled INTEGER DEFAULT 1,
                channel_id TEXT,
                message TEXT,
                embed_enabled INTEGER DEFAULT 1,
                embed_color TEXT DEFAULT '#57F287',
                ping_user INTEGER DEFAULT 1,
                dm_enabled INTEGER DEFAULT 0,
                dm_message TEXT,
                image_url TEXT,
                thumbnail_type TEXT DEFAULT 'avatar',
                show_rules INTEGER DEFAULT 0,
                rules_channel_id TEXT,
                show_invite_info INTEGER DEFAULT 0
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS goodbye_config (
                guild_id TEXT PRIMARY KEY,
                enabled INTEGER DEFAULT 1,
                channel_id TEXT,
                message TEXT,
                embed_enabled INTEGER DEFAULT 1,
                embed_color TEXT DEFAULT '#ED4245',
                image_url TEXT,
                thumbnail_type TEXT DEFAULT 'avatar',
                show_stats INTEGER DEFAULT 1
            )`);

            // Custom Commands
            this.db.run(`CREATE TABLE IF NOT EXISTS custom_commands (
                guild_id TEXT,
                trigger TEXT,
                response TEXT,
                creator_id TEXT,
                created_at TEXT,
                uses INTEGER DEFAULT 0,
                PRIMARY KEY (guild_id, trigger)
            )`);

            // Status Monitor
            this.db.run(`CREATE TABLE IF NOT EXISTS status_monitors (
                guild_id TEXT,
                url TEXT,
                channel_id TEXT,
                message_id TEXT,
                name TEXT,
                last_status TEXT DEFAULT 'unknown',
                last_check TEXT,
                uptime_start TEXT,
                total_checks INTEGER DEFAULT 0,
                successful_checks INTEGER DEFAULT 0,
                failed_checks INTEGER DEFAULT 0,
                last_response_time INTEGER DEFAULT 0,
                avg_response_time INTEGER DEFAULT 0,
                check_interval INTEGER DEFAULT 300000,
                alert_enabled INTEGER DEFAULT 1,
                alert_role_id TEXT,
                embed_color TEXT DEFAULT '#5865F2',
                show_response_time INTEGER DEFAULT 1,
                show_uptime INTEGER DEFAULT 1,
                show_history INTEGER DEFAULT 1,
                PRIMARY KEY (guild_id, url)
            )`);
            
            // Status Monitor History
            this.db.run(`CREATE TABLE IF NOT EXISTS status_monitor_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT,
                url TEXT,
                status TEXT,
                response_time INTEGER,
                timestamp TEXT,
                error_message TEXT
            )`);

            // Warnings System
            this.db.run(`CREATE TABLE IF NOT EXISTS warnings (
                guild_id TEXT,
                user_id TEXT,
                warning_id INTEGER,
                reason TEXT,
                moderator_id TEXT,
                timestamp TEXT,
                PRIMARY KEY (guild_id, user_id, warning_id)
            )`);

            // AFK System
            this.db.run(`CREATE TABLE IF NOT EXISTS afk (
                guild_id TEXT,
                user_id TEXT,
                reason TEXT,
                timestamp TEXT,
                PRIMARY KEY (guild_id, user_id)
            )`);

            // Reaction Roles
            this.db.run(`CREATE TABLE IF NOT EXISTS reaction_roles (
                guild_id TEXT,
                message_id TEXT,
                emoji TEXT,
                role_id TEXT,
                PRIMARY KEY (guild_id, message_id, emoji)
            )`);

            // Invite Tracking System
            this.db.run(`CREATE TABLE IF NOT EXISTS invites (
                guild_id TEXT,
                user_id TEXT,
                inviter_id TEXT,
                invite_code TEXT,
                joined_at TEXT,
                is_fake INTEGER DEFAULT 0,
                is_left INTEGER DEFAULT 0,
                PRIMARY KEY (guild_id, user_id)
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS invite_stats (
                guild_id TEXT,
                user_id TEXT,
                total_invites INTEGER DEFAULT 0,
                valid_invites INTEGER DEFAULT 0,
                fake_invites INTEGER DEFAULT 0,
                left_invites INTEGER DEFAULT 0,
                PRIMARY KEY (guild_id, user_id)
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS invite_codes (
                guild_id TEXT,
                code TEXT,
                inviter_id TEXT,
                uses INTEGER DEFAULT 0,
                PRIMARY KEY (guild_id, code)
            )`);

            // Starboard
            this.db.run(`CREATE TABLE IF NOT EXISTS starboard (
                guild_id TEXT PRIMARY KEY,
                channel_id TEXT,
                threshold INTEGER DEFAULT 5
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS starred_messages (
                original_message_id TEXT PRIMARY KEY,
                starboard_message_id TEXT,
                stars INTEGER DEFAULT 1
            )`);

            // Auto Publish
            this.db.run(`CREATE TABLE IF NOT EXISTS auto_publish (
                guild_id TEXT PRIMARY KEY,
                channel_id TEXT
            )`);

            // Verification
            this.db.run(`CREATE TABLE IF NOT EXISTS verification (
                guild_id TEXT PRIMARY KEY,
                role_id TEXT,
                channel_id TEXT
            )`);

            // AutoRole
            this.db.run(`CREATE TABLE IF NOT EXISTS autorole (
                guild_id TEXT PRIMARY KEY,
                role_id TEXT
            )`);

            // Sticky Roles
            this.db.run(`CREATE TABLE IF NOT EXISTS sticky_config (
                guild_id TEXT PRIMARY KEY,
                enabled INTEGER DEFAULT 0
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS sticky_roles (
                guild_id TEXT,
                user_id TEXT,
                roles TEXT,
                PRIMARY KEY (guild_id, user_id)
            )`);

            // Moderation Logs
            this.db.run(`CREATE TABLE IF NOT EXISTS moderation_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT,
                action TEXT,
                user_id TEXT,
                moderator_id TEXT,
                reason TEXT,
                timestamp TEXT
            )`);

            // Suggestion System
            this.db.run(`CREATE TABLE IF NOT EXISTS suggestion_config (
                guild_id TEXT PRIMARY KEY,
                channel_id TEXT
            )`);

            // Cooldowns
            this.db.run(`CREATE TABLE IF NOT EXISTS cooldowns (
                guild_id TEXT,
                user_id TEXT,
                command TEXT,
                timestamp TEXT,
                PRIMARY KEY (guild_id, user_id, command)
            )`);

            // Giveaways
            this.db.run(`CREATE TABLE IF NOT EXISTS giveaways (
                message_id TEXT PRIMARY KEY,
                guild_id TEXT,
                channel_id TEXT,
                prize TEXT,
                end_time TEXT,
                winners INTEGER,
                host_id TEXT,
                entrants_count INTEGER DEFAULT 0,
                ended INTEGER DEFAULT 0
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS giveaway_entrants (
                message_id TEXT,
                user_id TEXT,
                entered_at TEXT,
                PRIMARY KEY (message_id, user_id)
            )`);

            // DM Logs
            this.db.run(`CREATE TABLE IF NOT EXISTS dm_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT,
                guild_id TEXT,
                moderator_id TEXT,
                message TEXT,
                timestamp TEXT,
                direction TEXT,
                role_mention TEXT DEFAULT NULL
            )`);

            // Server Stats Channels
            this.db.run(`CREATE TABLE IF NOT EXISTS server_stats_channels (
                guild_id TEXT PRIMARY KEY,
                category_id TEXT,
                members_channel_id TEXT,
                bots_channel_id TEXT
            )`);

            // Ticket System
            this.db.run(`CREATE TABLE IF NOT EXISTS ticket_config (
                guild_id TEXT PRIMARY KEY,
                enabled INTEGER DEFAULT 1,
                category_id TEXT,
                support_role_id TEXT,
                log_channel_id TEXT,
                max_tickets INTEGER DEFAULT 1,
                ticket_name_format TEXT DEFAULT '{type}-ticket-{number}',
                welcome_message TEXT DEFAULT 'Thank you for contacting support! A staff member will be with you shortly.',
                close_confirmation INTEGER DEFAULT 1,
                transcript_enabled INTEGER DEFAULT 1,
                auto_close_hours INTEGER DEFAULT 0,
                rating_enabled INTEGER DEFAULT 1,
                claim_enabled INTEGER DEFAULT 1
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS ticket_panels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT,
                channel_id TEXT,
                message_id TEXT,
                title TEXT,
                description TEXT,
                color TEXT DEFAULT '#5865F2',
                emoji TEXT DEFAULT '🎫',
                button_label TEXT DEFAULT 'Create Ticket',
                ticket_type TEXT DEFAULT 'general',
                created_at TEXT
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS ticket_types (
                guild_id TEXT,
                type_name TEXT,
                emoji TEXT,
                description TEXT,
                support_role_id TEXT,
                PRIMARY KEY (guild_id, type_name)
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS tickets (
                ticket_id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT,
                channel_id TEXT,
                user_id TEXT,
                ticket_number INTEGER,
                ticket_type TEXT DEFAULT 'general',
                status TEXT DEFAULT 'open',
                claimed_by TEXT,
                created_at TEXT,
                closed_at TEXT,
                closed_by TEXT,
                close_reason TEXT,
                rating INTEGER,
                rating_feedback TEXT
            )`);

            // Add closed_by column if it doesn't exist (migration)
            this.db.run(`ALTER TABLE tickets ADD COLUMN closed_by TEXT`, (err) => {
                if (err && !err.message.includes('duplicate column')) {
                    // Ignore error if column already exists
                }
            });

            this.db.run(`CREATE TABLE IF NOT EXISTS ticket_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER,
                user_id TEXT,
                username TEXT,
                message TEXT,
                timestamp TEXT,
                attachments TEXT
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS ticket_participants (
                ticket_id INTEGER,
                user_id TEXT,
                added_by TEXT,
                added_at TEXT,
                PRIMARY KEY (ticket_id, user_id)
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS ticket_stats (
                guild_id TEXT,
                user_id TEXT,
                tickets_created INTEGER DEFAULT 0,
                tickets_closed INTEGER DEFAULT 0,
                average_rating REAL DEFAULT 0,
                total_ratings INTEGER DEFAULT 0,
                PRIMARY KEY (guild_id, user_id)
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS ticket_transcripts (
                ticket_id INTEGER PRIMARY KEY,
                guild_id TEXT,
                transcript_url TEXT,
                created_at TEXT
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS ticket_list_channel (
                guild_id TEXT PRIMARY KEY,
                channel_id TEXT,
                message_id TEXT,
                last_updated TEXT
            )`);

            // AI Chat System
            this.db.run(`CREATE TABLE IF NOT EXISTS ai_channels (
                guild_id TEXT,
                channel_id TEXT,
                enabled INTEGER DEFAULT 1,
                provider TEXT DEFAULT 'auto',
                system_prompt TEXT,
                temperature REAL DEFAULT 0.7,
                max_tokens INTEGER DEFAULT 1000,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (guild_id, channel_id)
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS ai_conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            )`);

            // Migration: Check if old schema exists and migrate
            this.db.all(`PRAGMA table_info(ai_conversations)`, [], (err, columns) => {
                if (err) return;
                
                const hasRole = columns.some(col => col.name === 'role');
                const hasContent = columns.some(col => col.name === 'content');
                const hasMessage = columns.some(col => col.name === 'message');
                
                // If old schema exists, we need to recreate the table
                if (hasMessage && !hasRole) {
                    console.log('Migrating ai_conversations table to new schema...');
                    this.db.run(`DROP TABLE IF EXISTS ai_conversations_old`);
                    this.db.run(`ALTER TABLE ai_conversations RENAME TO ai_conversations_old`);
                    this.db.run(`CREATE TABLE ai_conversations (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        guild_id TEXT NOT NULL,
                        channel_id TEXT NOT NULL,
                        user_id TEXT NOT NULL,
                        role TEXT NOT NULL,
                        content TEXT NOT NULL,
                        timestamp INTEGER NOT NULL
                    )`);
                    console.log('✓ Database schema migrated successfully');
                }
            });            this.db.run(`CREATE TABLE IF NOT EXISTS ai_rate_limits (
                user_id TEXT,
                guild_id TEXT,
                requests INTEGER DEFAULT 0,
                reset_time TEXT,
                PRIMARY KEY (user_id, guild_id)
            )`);

            // Super Admin Memory System
            this.db.run(`CREATE TABLE IF NOT EXISTS super_admin_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_id TEXT NOT NULL,
                command TEXT NOT NULL,
                memory_data TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                expires_at INTEGER
            )`);

            // User-specific AI restrictions set by SUPER_ADMINS
            this.db.run(`CREATE TABLE IF NOT EXISTS user_ai_restrictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                restriction_type TEXT NOT NULL,
                restriction_data TEXT,
                set_by TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                UNIQUE(guild_id, user_id, restriction_type)
            )`);

            // Indexes for performance
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_antinuke_logs ON antinuke_logs (guild_id, timestamp)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_dm_logs ON dm_logs (user_id, timestamp)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_giveaways ON giveaways (guild_id, end_time)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_moderation_logs ON moderation_logs (guild_id, timestamp)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_warnings ON warnings (guild_id, user_id)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_afk ON afk (guild_id, user_id)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_invites ON invites (guild_id, inviter_id)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_invite_stats ON invite_stats (guild_id, valid_invites DESC)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_invite_codes ON invite_codes (guild_id, inviter_id)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_tickets ON tickets (guild_id, user_id, status)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_ticket_messages ON ticket_messages (ticket_id, timestamp)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_ai_conversations ON ai_conversations (guild_id, channel_id, timestamp)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_ai_rate_limits ON ai_rate_limits (user_id, guild_id, reset_time)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_ticket_stats ON ticket_stats (guild_id, user_id)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_super_admin_memory ON super_admin_memory (admin_id, timestamp)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_user_ai_restrictions ON user_ai_restrictions (guild_id, user_id)`);

            // Review System
            this.db.run(`CREATE TABLE IF NOT EXISTS review_config (
                guild_id TEXT PRIMARY KEY,
                enabled INTEGER DEFAULT 1,
                review_channel_id TEXT,
                log_channel_id TEXT,
                max_reviews_per_user INTEGER DEFAULT 3,
                cooldown_hours INTEGER DEFAULT 24,
                min_account_age_days INTEGER DEFAULT 7,
                require_role_id TEXT,
                allow_anonymous INTEGER DEFAULT 0,
                auto_publish INTEGER DEFAULT 1
            )`);

            this.db.run(`CREATE TABLE IF NOT EXISTS reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                rating INTEGER NOT NULL,
                note TEXT,
                anonymous INTEGER DEFAULT 0,
                message_id TEXT,
                created_at TEXT NOT NULL,
                edited_at TEXT,
                status TEXT DEFAULT 'published'
            )`);

            this.db.run(`CREATE INDEX IF NOT EXISTS idx_reviews ON reviews (guild_id, user_id, created_at)`);
            this.db.run(`CREATE INDEX IF NOT EXISTS idx_reviews_rating ON reviews (guild_id, rating)`);
        });

        // Run migrations
        this.runMigrations();
    }

    async runMigrations() {
        // Add missing columns if needed
        const tables = {
            'welcome_config': ['enabled', 'embed_enabled', 'embed_color', 'ping_user', 'dm_enabled', 'dm_message', 'image_url', 'thumbnail_type', 'show_rules', 'rules_channel_id', 'show_invite_info'],
            'goodbye_config': ['enabled', 'embed_enabled', 'embed_color', 'image_url', 'thumbnail_type', 'show_stats'],
            'giveaways': ['ended'],
            'status_monitors': ['last_status', 'last_check', 'name', 'uptime_start', 'last_response_time', 'embed_color', 'alert_role_id'],
            'dm_logs': ['role_mention']
        };

        for (const [table, columns] of Object.entries(tables)) {
            for (const column of columns) {
                try {
                    await this.run(`ALTER TABLE ${table} ADD COLUMN ${column} TEXT DEFAULT NULL`);
                } catch (e) {
                    // Column already exists
                }
            }
        }
        
        // Add integer columns for status_monitors
        const integerColumns = {
            'status_monitors': [
                'total_checks',
                'successful_checks', 
                'failed_checks',
                'avg_response_time',
                'check_interval',
                'alert_enabled',
                'show_response_time',
                'show_uptime',
                'show_history'
            ]
        };
        
        for (const [table, columns] of Object.entries(integerColumns)) {
            for (const column of columns) {
                try {
                    let defaultValue = '0';
                    if (column === 'check_interval') defaultValue = '300000';
                    if (column === 'alert_enabled' || column === 'show_response_time' || column === 'show_uptime' || column === 'show_history') defaultValue = '1';
                    
                    await this.run(`ALTER TABLE ${table} ADD COLUMN ${column} INTEGER DEFAULT ${defaultValue}`);
                } catch (e) {
                    // Column already exists
                }
            }
        }
    }

    // Generic query methods
    run(query, params = []) {
        return new Promise((resolve, reject) => {
            this.db.run(query, params, function(err) {
                if (err) reject(err);
                else resolve(this);
            });
        });
    }

    get(query, params = []) {
        return new Promise((resolve, reject) => {
            this.db.get(query, params, (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    }

    all(query, params = []) {
        return new Promise((resolve, reject) => {
            this.db.all(query, params, (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }
}

const db = new Database();

// =======================
// ADVANCED MUSIC SYSTEM
// =======================

// Music System Configuration
// Custom settings stored separately (managed by our code)
const customMusicSettings = {
    defaultVolume: 50,
    maxQueueSize: 500,
    leaveOnEmptyDelay: 300000, // 5 minutes
    leaveOnFinishDelay: 300000, // 5 minutes  
    leaveOnStopDelay: 300000 // 5 minutes
};

// =======================
// SECURITY SYSTEMS
// =======================
class SecurityManager {
    constructor(client) {
        this.client = client;
        this.spamTracker = new Map();
        this.mentionSpamTracker = new Map();
        this.linkSpamTracker = new Map();
        this.spamWarnTracker = new Map(); // Tracks warnings issued per user for escalation
        this.antiNukeTracker = new Map();

        this.badWordsCache = new Map();
        this.customCommandsCache = new Map();
        this.giveawayEntrants = new Map();
        this.cooldowns = new Map();

        // Periodic cleanup of spam trackers to prevent memory leaks
        setInterval(() => this.cleanupSpamTrackers(), 120000); // Every 2 minutes
    }

    // Clean up stale entries from spam tracker Maps
    cleanupSpamTrackers() {
        const now = Date.now();
        const maxAge = 60000; // Remove entries older than 60 seconds

        for (const [key, messages] of this.spamTracker.entries()) {
            const filtered = messages.filter(m => now - m.time < maxAge);
            if (filtered.length === 0) this.spamTracker.delete(key);
            else this.spamTracker.set(key, filtered);
        }

        for (const [key, mentions] of this.mentionSpamTracker.entries()) {
            const filtered = mentions.filter(m => now - m.time < maxAge);
            if (filtered.length === 0) this.mentionSpamTracker.delete(key);
            else this.mentionSpamTracker.set(key, filtered);
        }

        for (const [key, links] of this.linkSpamTracker.entries()) {
            const filtered = links.filter(l => now - l.time < maxAge);
            if (filtered.length === 0) this.linkSpamTracker.delete(key);
            else this.linkSpamTracker.set(key, filtered);
        }

        for (const [key, warnData] of this.spamWarnTracker.entries()) {
            if (now - warnData.lastWarn > maxAge) {
                this.spamWarnTracker.delete(key);
            }
        }
    }

    // Anti-Nuke Methods
    async getAntiNukeConfig(guildId) {
        try {
            let config = await db.get('SELECT * FROM antinuke_config WHERE guild_id = ?', [guildId]);
            if (!config) {
                // Create default config
                await db.run(
                    'INSERT INTO antinuke_config (guild_id, enabled, punishment, revert_actions, alert_threshold, whitelist_enabled) VALUES (?, ?, ?, ?, ?, ?)',
                    [guildId, 1, 'ban', 1, 2, 1]
                );
                config = await db.get('SELECT * FROM antinuke_config WHERE guild_id = ?', [guildId]);
            }
            
            // Parse limits JSON
            if (config.limits) {
                try {
                    config.limits = JSON.parse(config.limits);
                } catch {
                    config.limits = JSON.parse('{"role_create":1,"role_delete":1,"role_update":1,"channel_create":1,"channel_delete":1,"channel_update":1,"ban":2,"kick":2,"member_update":1,"emoji_create":1,"emoji_delete":1,"emoji_update":1,"webhook_create":2,"webhook_delete":2,"webhook_update":2,"invite_create":5,"invite_delete":5,"guild_update":1}');
                }
            }
            // Backwards-compatible defaults for newer protection toggles
            // DB may not have these columns on older installs, so ensure sensible defaults here
            config.restrict_everyone = (typeof config.restrict_everyone !== 'undefined' && config.restrict_everyone !== null)
                ? Number(config.restrict_everyone)
                : 1; // enforce @everyone restriction by default

            config.protect_message_delete = (typeof config.protect_message_delete !== 'undefined' && config.protect_message_delete !== null)
                ? Number(config.protect_message_delete)
                : 1; // protect against unauthorized message deletes

            config.protect_channel_delete = (typeof config.protect_channel_delete !== 'undefined' && config.protect_channel_delete !== null)
                ? Number(config.protect_channel_delete)
                : 1; // protect against channel/category deletion

            config.log_channel_id = config.log_channel_id || config.log_channel || '';

            return config;
        } catch (error) {
            console.error('Error getting anti-nuke config:', error);
            return null;
        }
    }

    async isWhitelisted(guildId, userId) {
        try {
            const row = await db.get(
                'SELECT 1 FROM antinuke_whitelist WHERE guild_id = ? AND user_id = ?',
                [guildId, userId]
            );
            return !!row;
        } catch (error) {
            console.error('Error checking whitelist:', error);
            return false;
        }
    }

    async isExtraOwner(guildId, userId) {
        try {
            const row = await db.get(
                'SELECT 1 FROM extra_owners WHERE guild_id = ? AND user_id = ?',
                [guildId, userId]
            );
            return !!row;
        } catch (error) {
            console.error('Error checking extra owner:', error);
            return false;
        }
    }

    async logAntiNukeAction(guildId, userId, actionType, details, prevented = false) {
        try {
            await db.run(
                'INSERT INTO antinuke_logs (guild_id, user_id, action_type, timestamp, details, prevented) VALUES (?, ?, ?, ?, ?, ?)',
                [guildId, userId, actionType, new Date().toISOString(), details, prevented ? 1 : 0]
            );
        } catch (error) {
            console.error('Error logging anti-nuke action:', error);
        }
    }

    async getRecentActions(guildId, userId, actionType, seconds = 60) {
        try {
            const since = new Date(Date.now() - seconds * 1000).toISOString();
            const row = await db.get(
                'SELECT COUNT(*) as count FROM antinuke_logs WHERE guild_id = ? AND user_id = ? AND action_type = ? AND timestamp > ?',
                [guildId, userId, actionType, since]
            );
            return row ? row.count : 0;
        } catch (error) {
            console.error('Error getting recent actions:', error);
            return 0;
        }
    }

    async handleAntiNukeEvent(guild, actionType, entity, auditType) {
        try {
            const config = await this.getAntiNukeConfig(guild.id);
            if (!config || !config.enabled) return;

            const auditLogs = await guild.fetchAuditLogs({ type: auditType, limit: 1 }).catch(() => null);
            if (!auditLogs) return;

            const entry = auditLogs.entries.first();
            if (!entry || entry.executor.id === client.user.id || (Date.now() - entry.createdTimestamp > 5000)) return;

            // CRITICAL: Check if user is server owner, extra owner, bot owner, or super admin - NEVER punish them
            const isServerOwner = guild.ownerId === entry.executor.id;
            const isExtraOwner = await this.isExtraOwner(guild.id, entry.executor.id);
            const isSuperAdmin = configManager.isSuperAdmin(entry.executor.id);
            const isBotOwner = entry.executor.id === config.BOT_OWNER_ID;
            
            if (isServerOwner || isExtraOwner || isSuperAdmin || isBotOwner) {
                // These users are trusted and can do anything
                return;
            }

            // Check if whitelisted (full bypass)
            if (await this.isWhitelisted(guild.id, entry.executor.id)) {
                // Whitelisted users can do anything without restrictions
                return;
            }

            // Log the action
            await this.logAntiNukeAction(guild.id, entry.executor.id, actionType, `${actionType}: ${entity?.name || entity?.id || 'unknown'}`);

            // Check limits
            const count = await this.getRecentActions(guild.id, entry.executor.id, actionType);
            const limit = config.limits?.[actionType] || 1;

            if (count >= config.alert_threshold && count < limit) {
                await this.sendAntiNukeAlert(guild, entry.executor, `${actionType} suspicious activity (${count}/${limit})`, config);
            }

            if (count >= limit) {
                // Mark as prevented
                await this.logAntiNukeAction(guild.id, entry.executor.id, actionType, `PREVENTED: ${actionType} limit exceeded (${count}/${limit})`, true);
                
                // Apply punishment
                await this.applyAntiNukePunishment(guild, entry.executor, `${actionType} limit exceeded (${count}/${limit})`, config);
                
                // Revert the action if enabled
                if (config.revert_actions) {
                    await this.revertAction(guild, entry, actionType);
                }
            }
        } catch (error) {
            console.error('Error handling anti-nuke event:', error);
        }
    }

    async sendAntiNukeAlert(guild, user, reason, config) {
        try {
            if (config.log_channel_id) {
                const channel = guild.channels.cache.get(config.log_channel_id);
                if (channel) {
                    const alertEmbed = createEmbed({
                        title: `${EMOJIS.shield} ANTI-NUKE ALERT`,
                        description: reason,
                        color: COLORS.WARNING,
                        fields: [
                            { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
                            { name: 'Action', value: 'Monitoring', inline: true }
                        ],
                        footer: config.BOT_WATERMARK
                    });

                    await channel.send({ embeds: [alertEmbed] }).catch(() => {});
                }
            }
        } catch (error) {
            console.error('Error sending anti-nuke alert:', error);
        }
    }

    async applyAntiNukePunishment(guild, user, reason, config) {
        try {
            // Double-check: NEVER punish server owner, extra owners, or super admins
            const isServerOwner = guild.ownerId === user.id;
            const isExtraOwner = await this.isExtraOwner(guild.id, user.id);
            const isSuperAdmin = configManager.isSuperAdmin(user.id);
            
            if (isServerOwner || isExtraOwner || isSuperAdmin) {
                console.log(`Skipping punishment for protected user: ${user.tag}`);
                return;
            }

            // Check whitelist
            const isWhitelisted = await this.isWhitelisted(guild.id, user.id);
            if (isWhitelisted) {
                console.log(`Skipping punishment for whitelisted user: ${user.tag}`);
                return;
            }

            const member = await guild.members.fetch(user.id).catch(() => null);
            if (!member) {
                console.log(`Cannot fetch member: ${user.tag}`);
                return;
            }

            // Check if bot can actually punish this member
            const botMember = guild.members.me;
            if (!botMember) {
                console.log('Cannot fetch bot member');
                return;
            }

            // Check role hierarchy
            if (member.roles.highest.position >= botMember.roles.highest.position) {
                console.log(`Cannot punish ${user.tag} - role hierarchy (User: ${member.roles.highest.position}, Bot: ${botMember.roles.highest.position})`);
                
                // Send alert about failed punishment
                if (config.log_channel_id) {
                    const channel = guild.channels.cache.get(config.log_channel_id);
                    if (channel) {
                        const cannotPunishEmbed = createEmbed({
                            title: `${EMOJIS.shield} ANTI-NUKE ALERT - CANNOT PUNISH`,
                            description: '**Nuke attempt detected but cannot punish user!**',
                            color: COLORS.ERROR,
                            fields: [
                                { name: 'Attacker', value: `${user.tag} (${user.id})`, inline: true },
                                { name: 'Reason', value: 'Role hierarchy - User role is higher than bot', inline: false },
                                { name: 'Action', value: reason, inline: false },
                                { name: '⚠️ Required Action', value: 'Please move bot role higher or manually punish this user', inline: false }
                            ],
                            footer: config.BOT_WATERMARK
                        });

                        await channel.send({ embeds: [cannotPunishEmbed] }).catch(() => {});
                    }
                }
                return;
            }

            // Check if bot has timeout permission
            if (!botMember.permissions.has(PermissionFlagsBits.ModerateMembers)) {
                console.log('Bot does not have Moderate Members permission');
                
                // Send alert about missing permission
                if (config.log_channel_id) {
                    const channel = guild.channels.cache.get(config.log_channel_id);
                    if (channel) {
                        const missingPermEmbed = createEmbed({
                            title: `${EMOJIS.shield} ANTI-NUKE ALERT - MISSING PERMISSION`,
                            description: '**Nuke attempt detected but bot lacks permission!**',
                            color: COLORS.ERROR,
                            fields: [
                                { name: 'Attacker', value: `${user.tag} (${user.id})`, inline: true },
                                { name: 'Missing Permission', value: 'Moderate Members (Timeout)', inline: false },
                                { name: 'Action', value: reason, inline: false },
                                { name: '⚠️ Required Action', value: 'Please grant bot "Moderate Members" permission', inline: false }
                            ],
                            footer: config.BOT_WATERMARK
                        });

                        await channel.send({ embeds: [missingPermEmbed] }).catch(() => {});
                    }
                }
                return;
            }

            let actionTaken = false;
            let actionDescription = '';
            
            // Always use timeout for anti-nuke (safer than ban)
            const timeoutDuration = config.timeout_duration || 86400000; // Default 24 hours
            
            try {
                await member.timeout(timeoutDuration, `Anti-Nuke: ${reason}`);
                actionTaken = true;
                const hours = Math.floor(timeoutDuration / 3600000);
                actionDescription = `TIMED OUT (${hours}h)`;
            } catch (timeoutError) {
                console.error(`Failed to timeout ${user.tag}:`, timeoutError.message);
                
                // Send alert about failed timeout
                if (config.log_channel_id) {
                    const channel = guild.channels.cache.get(config.log_channel_id);
                    if (channel) {
                        const embed = new EmbedBuilder()
                            .setTitle(`${EMOJIS.shield} ANTI-NUKE ALERT - TIMEOUT FAILED`)
                            .setColor(COLORS.ERROR)
                            .setDescription(`**Nuke attempt detected but timeout failed!**`)
                            .addFields(
                                { name: 'Attacker', value: `${user.tag} (${user.id})`, inline: true },
                                { name: 'Error', value: timeoutError.message, inline: false },
                                { name: 'Action', value: reason, inline: false },
                                { name: '⚠️ Required Action', value: 'Please manually timeout or ban this user', inline: false }
                            )
                            .setTimestamp()
                            .setFooter({ text: config.BOT_WATERMARK || 'Advanced Security System' });
                        
                        await channel.send({ embeds: [embed] }).catch(() => {});
                    }
                }
                return;
            }

            if (actionTaken && config.log_channel_id) {
                const channel = guild.channels.cache.get(config.log_channel_id);
                if (channel) {
                    const takenEmbed = createEmbed({
                        title: `${EMOJIS.shield} ANTI-NUKE ACTION TAKEN`,
                        description: '**Nuke attempt detected and prevented!**',
                        color: COLORS.ERROR,
                        fields: [
                            { name: 'Attacker', value: `${user.tag} (${user.id})`, inline: true },
                            { name: 'Action Taken', value: actionDescription, inline: true },
                            { name: 'Reason', value: reason, inline: false }
                        ],
                        footer: config.BOT_WATERMARK
                    });

                    await channel.send({ embeds: [takenEmbed] }).catch(() => {});
                }
            }
        } catch (error) {
            console.error('Error applying anti-nuke punishment:', error);
        }
    }

    async isWhitelisted(guildId, userId) {
        try {
            const whitelist = await db.get(
                'SELECT * FROM antinuke_whitelist WHERE guild_id = ? AND user_id = ?',
                [guildId, userId]
            );
            return !!whitelist;
        } catch (error) {
            console.error('Error checking whitelist:', error);
            return false;
        }
    }

    async addToWhitelist(guildId, userId) {
        try {
            await db.run(
                'INSERT OR IGNORE INTO antinuke_whitelist (guild_id, user_id, added_at) VALUES (?, ?, ?)',
                [guildId, userId, new Date().toISOString()]
            );
            return true;
        } catch (error) {
            console.error('Error adding to whitelist:', error);
            return false;
        }
    }

    async removeFromWhitelist(guildId, userId) {
        try {
            await db.run(
                'DELETE FROM antinuke_whitelist WHERE guild_id = ? AND user_id = ?',
                [guildId, userId]
            );
            return true;
        } catch (error) {
            console.error('Error removing from whitelist:', error);
            return false;
        }
    }

    async getWhitelist(guildId) {
        try {
            const whitelist = await db.all(
                'SELECT * FROM antinuke_whitelist WHERE guild_id = ? ORDER BY added_at DESC',
                [guildId]
            );
            return whitelist;
        } catch (error) {
            console.error('Error getting whitelist:', error);
            return [];
        }
    }

    async revertAction(guild, entry, actionType) {
        try {
            console.log(`Reverting ${actionType} action...`);
            
            switch (actionType) {
                case 'role_create':
                    if (entry.target && entry.target.id) {
                        const role = guild.roles.cache.get(entry.target.id);
                        if (role) {
                            await role.delete('Anti-Nuke: Reverting unauthorized role creation');
                        }
                    }
                    break;
                    
                case 'role_delete':
                    if (entry.target && entry.changes) {
                        const roleData = {
                            name: entry.changes.find(c => c.key === 'name')?.old || 'Restored Role',
                            color: entry.changes.find(c => c.key === 'color')?.old || 0,
                            hoist: entry.changes.find(c => c.key === 'hoist')?.old || false,
                            permissions: entry.changes.find(c => c.key === 'permissions')?.old || [],
                            mentionable: entry.changes.find(c => c.key === 'mentionable')?.old || false,
                            position: entry.changes.find(c => c.key === 'position')?.old || 1
                        };
                        await guild.roles.create({
                            name: roleData.name,
                            color: roleData.color,
                            hoist: roleData.hoist,
                            permissions: roleData.permissions,
                            mentionable: roleData.mentionable,
                            position: roleData.position,
                            reason: 'Anti-Nuke: Restoring deleted role'
                        });
                    }
                    break;
                    
                case 'channel_create':
                    if (entry.target && entry.target.id) {
                        const channel = guild.channels.cache.get(entry.target.id);
                        if (channel) {
                            await channel.delete('Anti-Nuke: Reverting unauthorized channel creation');
                        }
                    }
                    break;
                    
                case 'channel_delete':
                    if (entry.target && entry.changes) {
                        const channelData = {
                            name: entry.changes.find(c => c.key === 'name')?.old || 'restored-channel',
                            type: entry.changes.find(c => c.key === 'type')?.old || 0,
                            topic: entry.changes.find(c => c.key === 'topic')?.old || null,
                            nsfw: entry.changes.find(c => c.key === 'nsfw')?.old || false,
                            bitrate: entry.changes.find(c => c.key === 'bitrate')?.old || null,
                            userLimit: entry.changes.find(c => c.key === 'user_limit')?.old || null,
                            rateLimitPerUser: entry.changes.find(c => c.key === 'rate_limit_per_user')?.old || null,
                            position: entry.changes.find(c => c.key === 'position')?.old || 0
                        };
                        
                        const createData = {
                            name: channelData.name,
                            type: channelData.type,
                            reason: 'Anti-Nuke: Restoring deleted channel'
                        };
                        
                        if (channelData.topic) createData.topic = channelData.topic;
                        if (channelData.nsfw !== null) createData.nsfw = channelData.nsfw;
                        if (channelData.bitrate) createData.bitrate = channelData.bitrate;
                        if (channelData.userLimit) createData.userLimit = channelData.userLimit;
                        if (channelData.rateLimitPerUser) createData.rateLimitPerUser = channelData.rateLimitPerUser;
                        if (channelData.position) createData.position = channelData.position;
                        
                        await guild.channels.create(createData);
                    }
                    break;
                    
                case 'ban':
                    if (entry.target && entry.target.id) {
                        await guild.members.unban(entry.target.id, 'Anti-Nuke: Reverting unauthorized ban');
                    }
                    break;
                    
                case 'kick':
                    // Cannot revert kicks, but log it
                    console.log('Cannot revert kick action');
                    break;
                    
                case 'webhook_create':
                    if (entry.target && entry.target.id) {
                        const webhooks = await guild.fetchWebhooks();
                        const webhook = webhooks.get(entry.target.id);
                        if (webhook) {
                            await webhook.delete('Anti-Nuke: Reverting unauthorized webhook creation');
                        }
                    }
                    break;
                    
                case 'emoji_create':
                    if (entry.target && entry.target.id) {
                        const emoji = guild.emojis.cache.get(entry.target.id);
                        if (emoji) {
                            await emoji.delete('Anti-Nuke: Reverting unauthorized emoji creation');
                        }
                    }
                    break;
                    
                case 'emoji_delete':
                    // Cannot restore deleted emojis without the image
                    console.log('Cannot revert emoji deletion without image data');
                    break;
                    
                case 'sticker_create':
                    if (entry.target && entry.target.id) {
                        const sticker = guild.stickers.cache.get(entry.target.id);
                        if (sticker) {
                            await sticker.delete('Anti-Nuke: Reverting unauthorized sticker creation');
                        }
                    }
                    break;
                    
                default:
                    console.log(`No revert logic for action type: ${actionType}`);
            }
        } catch (error) {
            console.error('Error reverting action:', error);
        }
    }

    // Enforce message-level anti-nuke protections (e.g., @everyone/@here)
    async enforceAntiNukeOnMessage(message) {
        try {
            if (!message.guild || message.author.bot) return false;

            const guildId = message.guild.id;
            const userId = message.author.id;
            const config = await this.getAntiNukeConfig(guildId);
            if (!config || !config.enabled) return false;

            const restrictEveryone = Number(config.restrict_everyone || 1);
            if (!restrictEveryone) return false;

            if (!message.mentions || !message.mentions.everyone) return false;

            // Bypass trusted users
            if (message.guild.ownerId === userId) return false;
            if (configManager.isSuperAdmin(userId)) return false;
            if (userId === config.BOT_OWNER_ID) return false;
            if (await this.isExtraOwner(guildId, userId)) return false;
            if (await this.isWhitelisted(guildId, userId)) return false;

            // Delete message and apply punishment
            await message.delete().catch(() => {});
            await this.logAntiNukeAction(guildId, userId, 'unauthorized_everyone', 'Attempted to use @everyone/@here', 0);

            // Use existing punishment flow
            await this.applyAntiNukePunishment(message.guild, message.author, 'Unauthorized @everyone/@here mention', config);

            // Notify log channel if configured
            const logChannelId = config.log_channel_id || config.log_channel;
            if (logChannelId) {
                const logChannel = message.guild.channels.cache.get(logChannelId);
                if (logChannel) {
                    const blockedEmbed = createEmbed({
                        title: `${EMOJIS.shield} ANTI-NUKE - BLOCKED @everyone`,
                        description: 'An unauthorized @everyone/@here mention was blocked.',
                        color: COLORS.WARNING,
                        fields: [
                            { name: 'User', value: `${message.author.tag} (${message.author.id})`, inline: true },
                            { name: 'Action', value: 'Blocked @everyone/@here', inline: true },
                            { name: 'Channel', value: `${message.channel.toString()}`, inline: false }
                        ],
                        footer: config.BOT_WATERMARK
                    });

                    await logChannel.send({ embeds: [blockedEmbed] }).catch(() => {});
                }
            }

            return true;
        } catch (error) {
            console.error('Error enforcing anti-nuke on message:', error);
            return false;
        }
    }

    // Handle message deletions to detect unauthorized deletions
    async handleMessageDelete(message) {
        try {
            if (!message.guild) return;
            const guildId = message.guild.id;
            const config = await this.getAntiNukeConfig(guildId);
            if (!config || !config.enabled) return;

            const protectDeletes = Number(config.protect_message_delete || 1);
            if (!protectDeletes) return;

            // Try to fetch audit logs to see who deleted the message
            const auditLogs = await message.guild.fetchAuditLogs({ type: AuditLogEvent.MessageDelete, limit: 1 }).catch(() => null);
            const entry = auditLogs?.entries?.first();
            if (!entry || !entry.executor) return;

            const executor = entry.executor;
            if (!executor || executor.id === client.user.id) return;

            // If executor deleted their own message, ignore
            if (executor.id === message.author?.id) return;

            // Bypass trusted users
            if (message.guild.ownerId === executor.id) return;
            if (configManager.isSuperAdmin(executor.id)) return;
            if (executor.id === config.BOT_OWNER_ID) return;
            if (await this.isExtraOwner(guildId, executor.id)) return;
            if (await this.isWhitelisted(guildId, executor.id)) return;

            // Log and punish
            const snippet = (message.content || '').slice(0, 350);
            await this.logAntiNukeAction(guildId, executor.id, 'message_delete', `Deleted message by ${message.author?.tag || 'unknown'}: "${snippet}"`, 0);
            await this.applyAntiNukePunishment(message.guild, executor, 'Unauthorized message deletion', config);

            // Post original message to log channel
            const logChannelId = config.log_channel_id || config.log_channel;
            if (logChannelId) {
                const logChannel = message.guild.channels.cache.get(logChannelId);
                if (logChannel) {
                    const deletedEmbed = createEmbed({
                        title: `${EMOJIS.shield} ANTI-NUKE - MESSAGE DELETED`,
                        description: 'A message was deleted by an unauthorized user and restored to logs.',
                        color: COLORS.WARNING,
                        fields: [
                            { name: 'Executor', value: `${executor.tag} (${executor.id})`, inline: true },
                            { name: 'Author', value: `${message.author?.tag || 'unknown'} (${message.author?.id || 'unknown'})`, inline: true },
                            { name: 'Channel', value: `${message.channel.toString()}`, inline: false },
                            { name: 'Content', value: snippet || '*embed/attachment or empty*', inline: false }
                        ],
                        footer: config.BOT_WATERMARK
                    });

                    await logChannel.send({ embeds: [deletedEmbed] }).catch(() => {});
                }
            }
        } catch (error) {
            console.error('Error handling messageDelete anti-nuke:', error);
        }
    }

    // Anti-Spam Methods
    async getAntiSpamConfig(guildId) {
        try {
            let config = await db.get('SELECT * FROM antispam_config WHERE guild_id = ?', [guildId]);
            if (!config) {
                // Create default config
                await db.run(
                    'INSERT INTO antispam_config (guild_id, enabled, punishment, message_threshold, time_window, duplicate_threshold, mention_threshold, link_threshold, warn_before_punish) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [guildId, 1, 'timeout', 5, 5000, 3, 5, 2, 1]
                );
                config = await db.get('SELECT * FROM antispam_config WHERE guild_id = ?', [guildId]);
            }
            
            // Parse exempt arrays
            if (config.exempt_roles) {
                try {
                    config.exempt_roles = JSON.parse(config.exempt_roles);
                } catch {
                    config.exempt_roles = [];
                }
            }
            
            if (config.exempt_channels) {
                try {
                    config.exempt_channels = JSON.parse(config.exempt_channels);
                } catch {
                    config.exempt_channels = [];
                }
            }
            
            return config;
        } catch (error) {
            console.error('Error getting anti-spam config:', error);
            return null;
        }
    }

    async checkSpam(message) {
        try {
            if (!message.guild || message.author.bot) return { detected: false };

            const guildId = message.guild.id;
            const userId = message.author.id;

            // BYPASS: Server owner, extra owners, super admins, bot owner, and whitelisted users
            if (message.guild.ownerId === userId) return { detected: false };
            if (configManager.isSuperAdmin(userId)) return { detected: false };
            if (userId === config.BOT_OWNER_ID) return { detected: false };
            if (await this.isExtraOwner(guildId, userId)) return { detected: false };
            if (await this.isWhitelisted(guildId, userId)) return { detected: false };

            const spamConfig = await this.getAntiSpamConfig(guildId);
            if (!spamConfig || !spamConfig.enabled) return { detected: false };

            // Normalize/validate thresholds (with sensible defaults)
            const messageThreshold = Math.max(2, parseInt(spamConfig.message_threshold) || 5);
            const timeWindow = Math.max(1000, parseInt(spamConfig.time_window) || 5000);
            const duplicateThreshold = Math.max(2, parseInt(spamConfig.duplicate_threshold) || 3);
            const mentionThreshold = Math.max(1, parseInt(spamConfig.mention_threshold) || 5);
            const linkThreshold = Math.max(1, parseInt(spamConfig.link_threshold) || 2);

            // Check if user is exempt (role/channel)
            const member = message.member;
            if (member) {
                const hasExemptRole = Array.isArray(spamConfig.exempt_roles) &&
                    spamConfig.exempt_roles.some(roleId => member.roles.cache.has(roleId));
                if (hasExemptRole) return { detected: false };
            }
            if (Array.isArray(spamConfig.exempt_channels) && spamConfig.exempt_channels.includes(message.channel.id)) {
                return { detected: false };
            }

            const spamKey = `${guildId}-${userId}`;
            const now = Date.now();

            // ---- Message rate tracking ----
            if (!this.spamTracker.has(spamKey)) this.spamTracker.set(spamKey, []);
            const userMessages = this.spamTracker.get(spamKey)
                .filter(msg => now - msg.time < timeWindow);
            userMessages.push({ time: now, content: (message.content || '').trim() });
            this.spamTracker.set(spamKey, userMessages);

            // Check message rate threshold
            if (userMessages.length >= messageThreshold) {
                return {
                    detected: true,
                    type: 'rate',
                    reason: `Message spam (${userMessages.length}/${messageThreshold} in ${timeWindow / 1000}s)`
                };
            }

            // ---- Duplicate message detection ----
            const contentCounts = userMessages.reduce((acc, msg) => {
                if (msg.content) acc[msg.content] = (acc[msg.content] || 0) + 1;
                return acc;
            }, {});
            const duplicateValues = Object.values(contentCounts);
            const maxDuplicates = duplicateValues.length > 0 ? Math.max(...duplicateValues) : 0;
            if (maxDuplicates >= duplicateThreshold) {
                return {
                    detected: true,
                    type: 'duplicate',
                    reason: `Duplicate messages (${maxDuplicates}/${duplicateThreshold})`
                };
            }

            // ---- Mention spam (within a single message AND over the time window) ----
            const mentionCount = message.mentions.users.size + message.mentions.roles.size +
                (message.mentions.everyone ? 1 : 0);
            if (mentionCount > 0) {
                if (!this.mentionSpamTracker.has(spamKey)) this.mentionSpamTracker.set(spamKey, []);
                const userMentions = this.mentionSpamTracker.get(spamKey)
                    .filter(m => now - m.time < timeWindow);
                userMentions.push({ time: now, count: mentionCount });
                this.mentionSpamTracker.set(spamKey, userMentions);

                // Single message mass-mention
                if (mentionCount >= mentionThreshold) {
                    return {
                        detected: true,
                        type: 'mention',
                        reason: `Mass mention (${mentionCount} mentions in one message)`
                    };
                }

                // Cumulative mentions across the window
                const totalRecentMentions = userMentions.reduce((sum, m) => sum + m.count, 0);
                if (totalRecentMentions >= mentionThreshold) {
                    return {
                        detected: true,
                        type: 'mention',
                        reason: `Mention spam (${totalRecentMentions}/${mentionThreshold})`
                    };
                }
            }

            // ---- Link spam ----
            const linkCount = ((message.content || '').match(/https?:\/\/[^\s]+/gi) || []).length;
            if (linkCount > 0) {
                if (!this.linkSpamTracker.has(spamKey)) this.linkSpamTracker.set(spamKey, []);
                const userLinks = this.linkSpamTracker.get(spamKey)
                    .filter(l => now - l.time < timeWindow);
                userLinks.push({ time: now, count: linkCount });
                this.linkSpamTracker.set(spamKey, userLinks);

                const totalRecentLinks = userLinks.reduce((sum, l) => sum + l.count, 0);
                if (totalRecentLinks >= linkThreshold) {
                    return {
                        detected: true,
                        type: 'link',
                        reason: `Link spam (${totalRecentLinks}/${linkThreshold})`
                    };
                }
            }

            // ---- Emoji spam (more than 10 emojis in one message) ----
            const emojiRegex = /<a?:\w+:\d+>|\p{Emoji_Presentation}|\p{Extended_Pictographic}/gu;
            const emojiMatches = (message.content || '').match(emojiRegex) || [];
            if (emojiMatches.length >= 10) {
                return {
                    detected: true,
                    type: 'emoji',
                    reason: `Emoji spam (${emojiMatches.length} emojis in one message)`
                };
            }

            // ---- Wall of text / newline spam (more than 15 newlines) ----
            const newlineCount = ((message.content || '').match(/\n/g) || []).length;
            if (newlineCount >= 15) {
                return {
                    detected: true,
                    type: 'newline',
                    reason: `Newline/wall-of-text spam (${newlineCount} line breaks)`
                };
            }

            return { detected: false };
        } catch (error) {
            console.error('Error checking spam:', error);
            return { detected: false };
        }
    }


    async handleSpam(message, spamResult) {
        try {
            const spamConfig = await this.getAntiSpamConfig(message.guild.id);
            if (!spamConfig) return;

            const guildId = message.guild.id;
            const userId = message.author.id;
            const spamKey = `${guildId}-${userId}`;

            // Delete the spam message
            await message.delete().catch(() => {});

            // Try to bulk delete recent spam messages from this user in the channel
            try {
                const recentMessages = await message.channel.messages.fetch({ limit: 20 });
                const userSpamMessages = recentMessages.filter(
                    m => m.author.id === userId && (Date.now() - m.createdTimestamp) < 30000
                );
                if (userSpamMessages.size > 1) {
                    await message.channel.bulkDelete(userSpamMessages, true).catch(() => {});
                }
            } catch (e) {
                // Bulk delete may fail for messages older than 14 days, ignore
            }

            // Warning escalation system
            const MAX_WARNINGS = 3; // After 3 warnings, apply punishment
            const WARNING_DECAY_MS = 60000; // Warnings reset after 60 seconds of no spam

            if (spamConfig.warn_before_punish) {
                // Initialize or get warning tracker for this user
                if (!this.spamWarnTracker.has(spamKey)) {
                    this.spamWarnTracker.set(spamKey, { count: 0, lastWarn: 0 });
                }

                const warnData = this.spamWarnTracker.get(spamKey);
                const now = Date.now();

                // Reset warnings if enough time has passed since last warning
                if (now - warnData.lastWarn > WARNING_DECAY_MS) {
                    warnData.count = 0;
                }

                warnData.count++;
                warnData.lastWarn = now;
                this.spamWarnTracker.set(spamKey, warnData);

                if (warnData.count < MAX_WARNINGS) {
                    // Send visible warning (no ephemeral - it doesn't work on regular messages)
                    const warning = await message.channel.send({
                        content: `⚠️ ${message.author}, **Anti-Spam Warning** (${warnData.count}/${MAX_WARNINGS}): ${spamResult.reason}. Stop spamming or you will be punished!`
                    }).catch(() => null);

                    // Auto-delete warning after 8 seconds
                    if (warning) {
                        setTimeout(() => warning.delete().catch(() => {}), 8000);
                    }
                    return;
                }

                // Max warnings reached - reset tracker and fall through to punishment
                this.spamWarnTracker.delete(spamKey);
            }

            // Apply punishment
            const member = message.member;
            if (!member) return;

            // Check if bot can actually punish this member
            if (!member.moderatable) {
                return;
            }

            let actionTaken = spamConfig.punishment || 'timeout';

            switch (actionTaken) {
                case 'timeout':
                    await member.timeout(300000, `Anti-Spam: ${spamResult.reason}`).catch(() => {
                        actionTaken = 'failed';
                    });
                    break;
                case 'kick':
                    await member.kick(`Anti-Spam: ${spamResult.reason}`).catch(() => {
                        actionTaken = 'failed';
                    });
                    break;
                case 'ban':
                    await member.ban({ reason: `Anti-Spam: ${spamResult.reason}`, deleteMessageSeconds: 60 }).catch(() => {
                        actionTaken = 'failed';
                    });
                    break;
                default:
                    await member.timeout(300000, `Anti-Spam: ${spamResult.reason}`).catch(() => {
                        actionTaken = 'failed';
                    });
                    actionTaken = 'timeout';
                    break;
            }

            if (actionTaken === 'failed') return;

            // Clear spam trackers for this user after punishment
            this.spamTracker.delete(spamKey);
            this.mentionSpamTracker.delete(spamKey);
            this.linkSpamTracker.delete(spamKey);

            // Log the action with an embed
            const logEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.shield} SPAM DETECTED & PUNISHED`)
                .setColor(COLORS.ERROR)
                .setDescription(`A user has been punished for spamming.`)
                .addFields(
                    { name: '👤 User', value: `${message.author.tag} (<@${message.author.id}>)`, inline: true },
                    { name: '📝 Type', value: spamResult.type || 'spam', inline: true },
                    { name: '⚡ Action', value: actionTaken.toUpperCase(), inline: true },
                    { name: '📋 Reason', value: spamResult.reason, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK || 'Advanced Security System' });

            await message.channel.send({ embeds: [logEmbed] }).catch(() => {});
        } catch (error) {
            console.error('Error handling spam:', error);
        }
    }

    // Bad Words Filter
    async getBadWordsConfig(guildId) {
        try {
            let config = await db.get(
                'SELECT * FROM bad_words_config WHERE guild_id = ?',
                [guildId]
            );
    
            // If no config exists, create default
            if (!config) {
                const defaultWords = [
                    'fuck',
                    'shit',
                    'bitch',
                    'ass',
                    'damn'
                ];
    
                await db.run(
                    `INSERT INTO bad_words_config 
                    (guild_id, enabled, words, action, custom_message) 
                    VALUES (?, ?, ?, ?, ?)`,
                    [
                        guildId,
                        1,
                        JSON.stringify(defaultWords),
                        'delete',
                        'Watch your language!'
                    ]
                );
    
                config = {
                    guild_id: guildId,
                    enabled: 1,
                    words: defaultWords,
                    action: 'delete',
                    custom_message: 'Watch your language!',
                    exempt_roles: [],
                    exempt_channels: []
                };
    
                return config;
            }
    
            // Parse words
            try {
                config.words = JSON.parse(config.words || '[]');
            } catch {
                config.words = [];
            }
    
            // Parse exempt roles
            try {
                config.exempt_roles = JSON.parse(config.exempt_roles || '[]');
            } catch {
                config.exempt_roles = [];
            }
    
            // Parse exempt channels
            try {
                config.exempt_channels = JSON.parse(config.exempt_channels || '[]');
            } catch {
                config.exempt_channels = [];
            }
    
            return config;
    
        } catch (error) {
            console.error('Error getting bad words config:', error);
            return {
                enabled: 0,
                words: [],
                exempt_roles: [],
                exempt_channels: []
            };
        }
    }

    async checkBadWords(message) {
        try {
            if (!message.guild || message.author.bot) return false;
            
            const guildId = message.guild.id;
            const userId = message.author.id;
            
            // BYPASS: Super admins, bot owner, and whitelisted users
            if (configManager.isSuperAdmin(userId)) return false;
            if (userId === config.BOT_OWNER_ID) return false;
            if (await this.isWhitelisted(guildId, userId)) return false;
            
            const badWordsConfig = await this.getBadWordsConfig(guildId);
            
            if (!badWordsConfig || !badWordsConfig.enabled || !badWordsConfig.words || badWordsConfig.words.length === 0) return false;
            
            // Check if user is exempt
            const member = message.member;
            if (member) {
                const hasExemptRole = badWordsConfig.exempt_roles?.some(roleId => member.roles.cache.has(roleId));
                if (hasExemptRole) return false;
                
                if (badWordsConfig.exempt_channels?.includes(message.channel.id)) return false;
            }
            
            const content = message.content.toLowerCase();
            const foundWords = badWordsConfig.words.filter(word => content.includes(word.toLowerCase()));
            
            if (foundWords.length > 0) {
                return {
                    detected: true,
                    words: foundWords,
                    action: badWordsConfig.action || 'delete',
                    message: badWordsConfig.custom_message || 'Watch your language!'
                };
            }
            
            return { detected: false };
        } catch (error) {
            console.error('Error checking bad words:', error);
            return { detected: false };
        }
    }

    async handleBadWords(message, result) {
        try {
            switch (result.action) {
                case 'delete':
                    await message.delete().catch(() => {});
                    const warning = await message.channel.send({
                        content: `${message.author}, ${result.message}`,
                        flags: [MessageFlags.Ephemeral]
                    }).catch(() => {});
                    setTimeout(() => warning?.delete().catch(() => {}), 5000);
                    break;
                    
                case 'warn':
                    await message.delete().catch(() => {});
                    await message.channel.send({
                        content: `${message.author}, ${result.message} (Words: ${result.words.join(', ')})`
                    }).catch(() => {});
                    break;
                    
                case 'timeout':
                    await message.delete().catch(() => {});
                    const member = message.member;
                    if (member) {
                        await member.timeout(60000, `Bad words: ${result.words.join(', ')}`).catch(() => {});
                    }
                    break;
            }
        } catch (error) {
            console.error('Error handling bad words:', error);
        }
    }

    // Cooldown system
    async isOnCooldown(guildId, userId, command, cooldownMs = 3000) {
        const key = `${guildId}-${userId}-${command}`;
        const now = Date.now();
        
        if (this.cooldowns.has(key)) {
            const lastUsed = this.cooldowns.get(key);
            const timeLeft = lastUsed + cooldownMs - now;
            
            if (timeLeft > 0) {
                return timeLeft;
            }
        }
        
        this.cooldowns.set(key, now);
        setTimeout(() => this.cooldowns.delete(key), cooldownMs);
        return 0;
    }
}

const security = new SecurityManager(client);

// =======================
// AI CHAT SYSTEM
// =======================
class AIManager {
    constructor() {
        this.config = config.AI_CONFIG || {};
        this.rateLimits = new Map();
        this.conversationHistory = new Map();
    }

    async callOpenAI(message, systemPrompt, conversationHistory = []) {
            const apiKey = this.config.providers?.openai?.api_key;
            if (!apiKey || apiKey.trim() === '') throw new Error('OpenAI API key not configured');

            if (!this.openaiModels || this.openaiModels.length === 0) {
                try {
                    const listResponse = await fetch('https://api.openai.com/v1/models', {
                        headers: { 'Authorization': `Bearer ${apiKey}` }
                    });

                    if (listResponse.ok) {
                        const data = await listResponse.json();
                        this.openaiModels = data.data
                            .filter(m => m.id.includes('gpt'))
                            .map(m => m.id)
                            .sort((a, b) => {
                                if (a.includes('gpt-4o') && !b.includes('gpt-4o')) return -1;
                                if (!a.includes('gpt-4o') && b.includes('gpt-4o')) return 1;
                                if (a.includes('gpt-4') && !b.includes('gpt-4')) return -1;
                                if (!a.includes('gpt-4') && b.includes('gpt-4')) return 1;
                                if (a.includes('turbo')) return -1;
                                return 0;
                            });
                        console.log(`✓ OpenAI: Auto-detected ${this.openaiModels.length} models`);
                    } else if (listResponse.status === 401 || listResponse.status === 403) {
                        throw new Error('Invalid API key');
                    }
                } catch (err) {
                    if (err.message.includes('API key')) throw err;
                    console.log('Could not auto-detect OpenAI models, using defaults');
                }
            }

            const models = this.openaiModels && this.openaiModels.length > 0 
                ? this.openaiModels 
                : ['gpt-3.5-turbo', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-4'];

            const messages = [{ role: 'system', content: systemPrompt }];
            for (const msg of conversationHistory) {
                messages.push({ role: msg.role, content: msg.content });
            }
            messages.push({ role: 'user', content: message });

            let lastError = null;
            for (const model of models) {
                try {
                    const response = await fetch('https://api.openai.com/v1/chat/completions', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${apiKey}`
                        },
                        body: JSON.stringify({
                            model: model,
                            messages: messages,
                            max_tokens: this.config.settings?.max_tokens || 2000,
                            temperature: this.config.settings?.temperature || 0.9
                        })
                    });

                    if (!response.ok) {
                        const error = await response.json().catch(() => ({}));
                        const errorMsg = error.error?.message || response.statusText;
                        lastError = new Error(errorMsg);

                        if (response.status === 401 || errorMsg.includes('API key')) {
                            throw new Error('Invalid API key');
                        }

                        if (response.status === 404 || errorMsg.includes('does not exist') || errorMsg.includes('do not have access')) {
                            continue;
                        }

                        throw lastError;
                    }

                    const data = await response.json();
                    if (!this.openaiWorkingModel) {
                        this.openaiWorkingModel = model;
                        console.log(`✓ OpenAI: Using model ${model}`);
                    }
                    return {
                        text: data.choices[0].message.content,
                        tokens: data.usage?.total_tokens || 0,
                        provider: 'openai',
                        model: model
                    };
                } catch (err) {
                    lastError = err;
                    if (err.message.includes('API key')) throw err;
                    continue;
                }
            }
            throw new Error(lastError?.message || 'Unknown error');
        }

    // Get conversation history for a user in a channel
    getConversationHistory(guildId, channelId, userId) {
        const key = `${guildId}-${channelId}-${userId}`;
        if (!this.conversationHistory.has(key)) {
            this.conversationHistory.set(key, []);
        }
        return this.conversationHistory.get(key);
    }

    // Add message to conversation history
    addToHistory(guildId, channelId, userId, role, content) {
        const key = `${guildId}-${channelId}-${userId}`;
        const history = this.getConversationHistory(guildId, channelId, userId);

        history.push({
            role: role,
            content: content,
            timestamp: Date.now()
        });

        // Keep last 100 messages (50 exchanges) for better memory
        const maxMessages = this.config.settings?.max_history_messages || 100;
        if (history.length > maxMessages) {
            history.splice(0, history.length - maxMessages);
        }

        this.conversationHistory.set(key, history);

        // Also save to database for persistence (unlimited storage)
        this.saveHistoryToDatabase(guildId, channelId, userId, role, content);
    }

    // Save conversation to database
    async saveHistoryToDatabase(guildId, channelId, userId, role, content) {
        try {
            await db.run(
                `INSERT INTO ai_conversations (guild_id, channel_id, user_id, role, content, timestamp)
                 VALUES (?, ?, ?, ?, ?, ?)`,
                [guildId, channelId, userId, role, content, Date.now()]
            );
        } catch (err) {
            console.error('Failed to save conversation history:', err);
        }
    }

    // Load conversation history from database
    async loadHistoryFromDatabase(guildId, channelId, userId) {
        try {
            const rows = await db.all(
                `SELECT role, content, timestamp FROM ai_conversations
                 WHERE guild_id = ? AND channel_id = ? AND user_id = ?
                 ORDER BY timestamp DESC LIMIT 100`,
                [guildId, channelId, userId]
            );

            if (rows && rows.length > 0) {
                const key = `${guildId}-${channelId}-${userId}`;
                this.conversationHistory.set(key, rows.reverse());
                console.log(`📚 Loaded ${rows.length} messages from history for user ${userId}`);
            }
        } catch (err) {
            console.error('Failed to load conversation history:', err);
        }
    }

    // Clear conversation history for a user
    async clearHistory(guildId, channelId, userId) {
        const key = `${guildId}-${channelId}-${userId}`;
        this.conversationHistory.delete(key);

        try {
            await db.run(
                `DELETE FROM ai_conversations WHERE guild_id = ? AND channel_id = ? AND user_id = ?`,
                [guildId, channelId, userId]
            );
        } catch (err) {
            console.error('Failed to clear conversation history:', err);
        }
    }

    // Get conversation summary for a user
    async getConversationSummary(guildId, userId) {
        try {
            const rows = await db.all(
                `SELECT COUNT(*) as count, MIN(timestamp) as first_message, MAX(timestamp) as last_message
                 FROM ai_conversations
                 WHERE guild_id = ? AND user_id = ?`,
                [guildId, userId]
            );
            return rows[0];
        } catch (err) {
            console.error('Failed to get conversation summary:', err);
            return null;
        }
    }


    async callGemini(message, systemPrompt, conversationHistory = []) {
        const apiKey = this.config.providers?.gemini?.api_key;
        if (!apiKey || apiKey.trim() === '') throw new Error('Gemini API key not configured');

        // Auto-detect available models if not cached
        if (!this.geminiModels || this.geminiModels.length === 0) {
            try {
                const listResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`);
                if (listResponse.ok) {
                    const data = await listResponse.json();
                    // Filter models that support generateContent AND are not Interactions-only
                    this.geminiModels = data.models
                        .filter(m => {
                            // Must support generateContent
                            if (!m.supportedGenerationMethods?.includes('generateContent')) return false;
                            
                            const modelName = m.name.toLowerCase();
                            
                            // Exclude models that only support Interactions API
                            if (modelName.includes('aistudio') || modelName.includes('interaction')) return false;
                            
                            // Exclude preview/experimental models that might be Interactions-only
                            if (modelName.includes('preview') || modelName.includes('deep-research')) return false;
                            
                            // Only include stable models
                            const stablePatterns = ['gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-2.0-flash', 'gemini-2.5-flash', 'gemini-pro'];
                            return stablePatterns.some(pattern => modelName.includes(pattern));
                        })
                        .map(m => m.name.replace('models/', ''))
                        .sort((a, b) => {
                            // Prioritize: 2.5 > 2.0 > 1.5 > 1.0, flash > pro
                            if (a.includes('2.5') && !b.includes('2.5')) return -1;
                            if (!a.includes('2.5') && b.includes('2.5')) return 1;
                            if (a.includes('2.0') && !b.includes('2.0')) return -1;
                            if (!a.includes('2.0') && b.includes('2.0')) return 1;
                            if (a.includes('1.5') && !b.includes('1.5')) return -1;
                            if (!a.includes('1.5') && b.includes('1.5')) return 1;
                            if (a.includes('flash') && !b.includes('flash')) return -1;
                            if (!a.includes('flash') && b.includes('flash')) return 1;
                            return 0;
                        });
                    console.log(`✓ Gemini: Auto-detected ${this.geminiModels.length} models`);
                    if (this.geminiModels.length > 0) {
                        console.log(`  Available models: ${this.geminiModels.slice(0, 5).join(', ')}${this.geminiModels.length > 5 ? '...' : ''}`);
                    }
                } else if (listResponse.status === 401 || listResponse.status === 403) {
                    throw new Error('Invalid API key');
                }
            } catch (err) {
                if (err.message.includes('API key')) throw err;
                console.log('Could not auto-detect Gemini models, using defaults');
            }
        }

        // Fallback to known working models if auto-detection failed
        const modelNames = this.geminiModels && this.geminiModels.length > 0 
            ? this.geminiModels 
            : ['gemini-1.5-flash', 'gemini-1.5-flash-002', 'gemini-1.5-pro', 'gemini-pro'];

        let lastError = null;
        
        // Try each model until one works
        for (const model of modelNames) {
            try {
                // Build conversation text with history
                let conversationText = systemPrompt;
                for (const msg of conversationHistory) {
                    if (msg.role === 'user') {
                        conversationText += `\n\nUser: ${msg.content}`;
                    } else if (msg.role === 'assistant') {
                        conversationText += `\n\nAssistant: ${msg.content}`;
                    }
                }
                conversationText += `\n\nUser: ${message}`;
                
                const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        contents: [{
                            parts: [{
                                text: conversationText
                            }]
                        }],
                        generationConfig: {
                            temperature: this.config.settings?.temperature || 0.9,
                            maxOutputTokens: this.config.settings?.max_tokens || 2000
                        }
                    })
                });

                if (!response.ok) {
                    const error = await response.json().catch(() => ({}));
                    const errorMsg = error.error?.message || response.statusText;
                    lastError = new Error(errorMsg);
                    
                    // If API key is invalid, don't try other models
                    if (response.status === 401 || response.status === 403 || errorMsg.includes('API key')) {
                        throw new Error('Invalid API key');
                    }
                    
                    // If model only supports Interactions API, skip it
                    if (errorMsg.includes('Interactions API')) {
                        console.log(`⚠️ Skipping ${model} (Interactions API only)`);
                        continue;
                    }
                    
                    // If model not found, try next
                    if (errorMsg.includes('not found') || errorMsg.includes('does not exist')) {
                        continue;
                    }
                    
                    continue; // Try next model
                }

                const data = await response.json();
                
                // Check if response has content
                if (!data.candidates || !data.candidates[0]?.content?.parts?.[0]?.text) {
                    lastError = new Error('Empty response from API');
                    continue;
                }
                
                // Cache the working model for future use
                if (!this.geminiWorkingModel) {
                    this.geminiWorkingModel = model;
                    console.log(`✓ Gemini: Using model ${model}`);
                }
                
                return {
                    text: data.candidates[0].content.parts[0].text,
                    tokens: data.usageMetadata?.totalTokenCount || 0,
                    provider: 'gemini',
                    model: model
                };
            } catch (err) {
                lastError = err;
                
                // If it's an API key error, don't try other models
                if (err.message && err.message.includes('API key')) {
                    throw err;
                }
                
                // If it's Interactions API error, skip to next model
                if (err.message && err.message.includes('Interactions API')) {
                    console.log(`⚠️ Skipping ${model} (Interactions API only)`);
                    continue;
                }
                
                // Try next model for any other error
                continue;
            }
        }

        // If all models failed, throw the last error
        throw new Error(lastError?.message || 'No working models found');
    }

    async callGrok(message, systemPrompt) {
        const apiKey = this.config.providers?.grok?.api_key;
        if (!apiKey || apiKey.trim() === '') throw new Error('Grok API key not configured');

        // Auto-detect available models if not cached
        if (!this.grokModels || this.grokModels.length === 0) {
            try {
                const listResponse = await fetch('https://api.x.ai/v1/models', {
                    headers: { 'Authorization': `Bearer ${apiKey}` }
                });
                
                if (listResponse.ok) {
                    const data = await listResponse.json();
                    this.grokModels = data.data.map(m => m.id);
                    console.log(`✓ Grok: Auto-detected ${this.grokModels.length} models`);
                } else if (listResponse.status === 401 || listResponse.status === 403) {
                    throw new Error('Invalid API key');
                }
            } catch (err) {
                if (err.message.includes('API key')) throw err;
                console.log('Could not auto-detect Grok models, using defaults');
            }
        }

        const models = this.grokModels && this.grokModels.length > 0 
            ? this.grokModels 
            : ['grok-beta', 'grok-2-latest', 'grok-2', 'grok-1'];

        let lastError = null;
        for (const model of models) {
            try {
                const response = await fetch('https://api.x.ai/v1/chat/completions', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${apiKey}`
                    },
                    body: JSON.stringify({
                        model: model,
                        messages: [
                            { role: 'system', content: systemPrompt },
                            { role: 'user', content: message }
                        ],
                        max_tokens: this.config.settings?.max_tokens || 1000,
                        temperature: this.config.settings?.temperature || 0.9
                    })
                });

                if (!response.ok) {
                    const error = await response.json().catch(() => ({}));
                    const errorMsg = error.error?.message || response.statusText;
                    lastError = new Error(errorMsg);
                    if (response.status === 401 || response.status === 403 || errorMsg.includes('API key')) {
                        throw new Error('Invalid API key');
                    }
                    continue;
                }

                const data = await response.json();
                if (!this.grokWorkingModel) {
                    this.grokWorkingModel = model;
                    console.log(`✓ Grok: Using model ${model}`);
                }
                return {
                    text: data.choices[0].message.content,
                    tokens: data.usage?.total_tokens || 0,
                    provider: 'grok',
                    model: model
                };
            } catch (err) {
                lastError = err;
                if (err.message.includes('API key')) throw err;
                continue;
            }
        }
        throw new Error(lastError?.message || 'Unknown error');
    }

    async callDeepSeek(message, systemPrompt) {
        const apiKey = this.config.providers?.deepseek?.api_key;
        if (!apiKey || apiKey.trim() === '') throw new Error('DeepSeek API key not configured');

        // Auto-detect available models if not cached
        if (!this.deepseekModels || this.deepseekModels.length === 0) {
            try {
                const listResponse = await fetch('https://api.deepseek.com/v1/models', {
                    headers: { 'Authorization': `Bearer ${apiKey}` }
                });
                
                if (listResponse.ok) {
                    const data = await listResponse.json();
                    this.deepseekModels = data.data.map(m => m.id);
                    console.log(`✓ DeepSeek: Auto-detected ${this.deepseekModels.length} models`);
                } else if (listResponse.status === 401 || listResponse.status === 403) {
                    throw new Error('Invalid API key');
                }
            } catch (err) {
                if (err.message.includes('API key')) throw err;
                console.log('Could not auto-detect DeepSeek models, using defaults');
            }
        }

        const models = this.deepseekModels && this.deepseekModels.length > 0 
            ? this.deepseekModels 
            : ['deepseek-chat', 'deepseek-coder'];

        let lastError = null;
        for (const model of models) {
            try {
                const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${apiKey}`
                    },
                    body: JSON.stringify({
                        model: model,
                        messages: [
                            { role: 'system', content: systemPrompt },
                            { role: 'user', content: message }
                        ],
                        max_tokens: this.config.settings?.max_tokens || 1000,
                        temperature: this.config.settings?.temperature || 0.9
                    })
                });

                if (!response.ok) {
                    const error = await response.json().catch(() => ({}));
                    const errorMsg = error.error?.message || response.statusText;
                    lastError = new Error(errorMsg);
                    if (response.status === 401 || response.status === 403 || errorMsg.includes('API key')) {
                        throw new Error('Invalid API key');
                    }
                    continue;
                }

                const data = await response.json();
                if (!this.deepseekWorkingModel) {
                    this.deepseekWorkingModel = model;
                    console.log(`✓ DeepSeek: Using model ${model}`);
                }
                return {
                    text: data.choices[0].message.content,
                    tokens: data.usage?.total_tokens || 0,
                    provider: 'deepseek',
                    model: model
                };
            } catch (err) {
                lastError = err;
                if (err.message.includes('API key')) throw err;
                continue;
            }
        }
        throw new Error(lastError?.message || 'Unknown error');
    }

    async callAIMLAPI(message, systemPrompt) {
        const apiKey = this.config.providers?.aimlapi?.api_key;
        if (!apiKey || apiKey.trim() === '') throw new Error('AIMLAPI key not configured');

        // Auto-detect available models if not cached
        if (!this.aimlapiModels || this.aimlapiModels.length === 0) {
            try {
                const listResponse = await fetch('https://api.aimlapi.com/v1/models', {
                    headers: { 'Authorization': `Bearer ${apiKey}` }
                });

                if (listResponse.ok) {
                    const data = await listResponse.json();
                    // Filter for chat models and prioritize best ones
                    this.aimlapiModels = data.data
                        .filter(m => m.id.includes('gpt') || m.id.includes('gemini') || m.id.includes('claude') || m.id.includes('llama'))
                        .map(m => m.id)
                        .sort((a, b) => {
                            // Prioritize: gpt-5 > gpt-4 > gemini-3 > claude > llama
                            if (a.includes('gpt-5') && !b.includes('gpt-5')) return -1;
                            if (!a.includes('gpt-5') && b.includes('gpt-5')) return 1;
                            if (a.includes('gpt-4') && !b.includes('gpt-4')) return -1;
                            if (!a.includes('gpt-4') && b.includes('gpt-4')) return 1;
                            if (a.includes('gemini-3') && !b.includes('gemini-3')) return -1;
                            if (!a.includes('gemini-3') && b.includes('gemini-3')) return 1;
                            if (a.includes('claude') && !b.includes('claude')) return -1;
                            if (!a.includes('claude') && b.includes('claude')) return 1;
                            return 0;
                        });
                    console.log(`✓ AIMLAPI: Auto-detected ${this.aimlapiModels.length} models`);
                } else if (listResponse.status === 401 || listResponse.status === 403) {
                    throw new Error('Invalid API key');
                }
            } catch (err) {
                if (err.message.includes('API key')) throw err;
                console.log('Could not auto-detect AIMLAPI models, using defaults');
            }
        }

        // Fallback to best known models
        const models = this.aimlapiModels && this.aimlapiModels.length > 0
            ? this.aimlapiModels.slice(0, 5) // Only try first 5 models
            : ['meta-llama/llama-3.3-70b-instruct', 'mistralai/mistral-7b-instruct', 'google/gemini-2.0-flash-exp'];

        let lastError = null;
        for (const model of models) {
            try {
                console.log(`Trying AIMLAPI model: ${model}`);
                const response = await fetch('https://api.aimlapi.com/v1/chat/completions', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${apiKey}`
                    },
                    body: JSON.stringify({
                        model: model,
                        messages: [
                            { role: 'system', content: systemPrompt },
                            { role: 'user', content: message }
                        ],
                        max_tokens: this.config.settings?.max_tokens || 2000,
                        temperature: this.config.settings?.temperature || 0.9
                    })
                });

                if (!response.ok) {
                    const error = await response.json().catch(() => ({}));
                    const errorMsg = error.error?.message || error.message || response.statusText;
                    lastError = new Error(`${model}: ${errorMsg}`);
                    console.log(`✗ AIMLAPI model ${model} failed: ${errorMsg}`);

                    // If out of credits or invalid key, don't try other models
                    if (response.status === 401 || response.status === 403 || errorMsg.includes('out of credits')) {
                        throw new Error('Insufficient credits or invalid API key');
                    }
                    continue;
                }

                const data = await response.json();
                if (!data.choices || !data.choices[0]?.message?.content) {
                    lastError = new Error(`${model}: Empty response`);
                    continue;
                }
                
                if (!this.aimlapiWorkingModel) {
                    this.aimlapiWorkingModel = model;
                    console.log(`✓ AIMLAPI: Using model ${model}`);
                }
                return {
                    text: data.choices[0].message.content,
                    tokens: data.usage?.total_tokens || 0,
                    provider: 'aimlapi',
                    model: model
                };
            } catch (err) {
                lastError = err;
                if (err.message.includes('API key') || err.message.includes('credits')) throw err;
                continue;
            }
        }
        throw new Error(lastError?.message || 'Unknown error');
    }

    async callOpenRouter(message, systemPrompt, conversationHistory = []) {
        const apiKey = this.config.providers?.openrouter?.api_key;
        if (!apiKey || apiKey.trim() === '') throw new Error('OpenRouter API key not configured');

        // Auto-detect available models if not cached
        if (!this.openrouterModels || this.openrouterModels.length === 0) {
            try {
                const listResponse = await fetch('https://openrouter.ai/api/v1/models', {
                    headers: { 
                        'Authorization': `Bearer ${apiKey}`,
                        'HTTP-Referer': 'https://discord.com',
                        'X-Title': config.BOT_NAME || 'Discord Bot'
                    }
                });

                if (listResponse.ok) {
                    const data = await listResponse.json();
                    // Prioritize free models first, then paid models
                    this.openrouterModels = data.data
                        .map(m => ({
                            id: m.id,
                            isFree: m.pricing?.prompt === '0' || m.id.includes(':free')
                        }))
                        .sort((a, b) => {
                            // Free models first
                            if (a.isFree && !b.isFree) return -1;
                            if (!a.isFree && b.isFree) return 1;
                            
                            // Then prioritize by model quality
                            const aId = a.id.toLowerCase();
                            const bId = b.id.toLowerCase();
                            
                            if (aId.includes('gemini-2') && !bId.includes('gemini-2')) return -1;
                            if (!aId.includes('gemini-2') && bId.includes('gemini-2')) return 1;
                            if (aId.includes('llama-3.3') && !bId.includes('llama-3.3')) return -1;
                            if (!aId.includes('llama-3.3') && bId.includes('llama-3.3')) return 1;
                            if (aId.includes('qwen') && !bId.includes('qwen')) return -1;
                            if (!aId.includes('qwen') && bId.includes('qwen')) return 1;
                            
                            return 0;
                        })
                        .map(m => m.id)
                        .slice(0, 15); // Keep top 15 models
                    console.log(`✓ OpenRouter: Auto-detected ${this.openrouterModels.length} models`);
                } else if (listResponse.status === 401 || listResponse.status === 403) {
                    throw new Error('Invalid API key');
                }
            } catch (err) {
                if (err.message.includes('API key')) throw err;
                console.log('Could not auto-detect OpenRouter models, using defaults');
            }
        }

        // Fallback to best free/cheap models
        let models = this.openrouterModels && this.openrouterModels.length > 0
            ? this.openrouterModels
            : [
                'google/gemini-2.0-flash-exp:free',
                'meta-llama/llama-3.3-70b-instruct:free',
                'qwen/qwen-2.5-72b-instruct:free',
                'google/gemini-flash-1.5',
                'meta-llama/llama-3.1-8b-instruct:free',
                'mistralai/mistral-7b-instruct:free',
                'openrouter/owl-alpha'
            ];

        // STICKY MODEL: If we have a working model, try it first
        if (this.openrouterWorkingModel && models.includes(this.openrouterWorkingModel)) {
            // Move working model to the front
            models = [this.openrouterWorkingModel, ...models.filter(m => m !== this.openrouterWorkingModel)];
        }

        // Build messages array with conversation history
        const messages = [{ role: 'system', content: systemPrompt }];
        for (const msg of conversationHistory) {
            messages.push({ role: msg.role, content: msg.content });
        }
        messages.push({ role: 'user', content: message });

        let lastError = null;
        let triedWorkingModel = false;
        
        for (const model of models) {
            try {
                // Only log if it's the first attempt or if the working model failed
                if (!triedWorkingModel || model !== this.openrouterWorkingModel) {
                    console.log(`Trying OpenRouter model: ${model}`);
                }
                
                if (model === this.openrouterWorkingModel) {
                    triedWorkingModel = true;
                }

                const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${apiKey}`,
                        'HTTP-Referer': 'https://discord.com',
                        'X-Title': config.BOT_NAME || 'Discord Bot'
                    },
                    body: JSON.stringify({
                        model: model,
                        messages: messages,
                        max_tokens: this.config.settings?.max_tokens || 2000,
                        temperature: this.config.settings?.temperature || 0.9
                    })
                });

                if (!response.ok) {
                    const error = await response.json().catch(() => ({}));
                    const errorMsg = error.error?.message || response.statusText;
                    lastError = new Error(`${model}: ${errorMsg}`);
                    console.log(`✗ OpenRouter model ${model} failed: ${errorMsg}`);

                    // If this was our working model and it failed, clear it
                    if (model === this.openrouterWorkingModel) {
                        console.log(`⚠️ Working model ${model} failed, trying alternatives...`);
                        this.openrouterWorkingModel = null;
                    }

                    // If API key is invalid, user not found, or insufficient credits, don't try other models
                    if (response.status === 401 || response.status === 403 || 
                        errorMsg.includes('insufficient') || 
                        errorMsg.includes('User not found') ||
                        errorMsg.includes('Invalid API key') ||
                        errorMsg.includes('Invalid authentication')) {
                        throw new Error('Invalid API key or insufficient credits. Please check your OpenRouter API key at https://openrouter.ai/keys');
                    }

                    // If model not found or not available, try next
                    if (response.status === 404 || errorMsg.includes('not found') || errorMsg.includes('not available')) {
                        continue;
                    }

                    // Try next model for other errors
                    continue;
                }

                const data = await response.json();
                if (!data.choices || !data.choices[0]?.message?.content) {
                    lastError = new Error(`${model}: Empty response`);
                    continue;
                }

                // Save this as the working model for future requests
                if (this.openrouterWorkingModel !== model) {
                    this.openrouterWorkingModel = model;
                    console.log(`✓ OpenRouter: Now using model ${model} (will be used for future requests)`);
                } else {
                    console.log(`✓ OpenRouter: Successfully used ${model}`);
                }

                return {
                    text: data.choices[0].message.content,
                    tokens: data.usage?.total_tokens || 0,
                    provider: 'openrouter',
                    model: model
                };
            } catch (err) {
                lastError = err;
                if (err.message.includes('API key') || err.message.includes('credits') || err.message.includes('authentication')) throw err;
                continue;
            }
        }
        throw new Error(lastError?.message || 'Unknown error');
    }


    async getAIResponse(message, channelConfig, guildId, channelId, userId) {
        // Get base system prompt
        let systemPrompt = channelConfig?.system_prompt || this.config.settings?.system_prompt || 
            'You are a helpful Discord bot assistant. Be friendly, concise, and helpful. Keep responses under 2000 characters.';
        
        // Inject bot name and creator dynamically
        const botName = config.BOT_NAME || 'AI Assistant';
        const creator = 'Hopingboyz';
        
        // Replace placeholders in system prompt
        systemPrompt = systemPrompt
            .replace(/\{BOT_NAME\}/g, botName)
            .replace(/\{CREATOR\}/g, creator);
        
        // Check if user is SUPER_ADMIN
        const isSuperAdmin = config.SUPER_ADMINS && config.SUPER_ADMINS.includes(userId);
        
        // Load super admin memory if applicable
        let superAdminContext = '';
        if (isSuperAdmin) {
            try {
                const memories = await db.all(
                    'SELECT command, memory_data, timestamp FROM super_admin_memory WHERE admin_id = ? AND (expires_at IS NULL OR expires_at > ?) ORDER BY timestamp DESC LIMIT 100',
                    [userId, Date.now()]
                );
                
                if (memories && memories.length > 0) {
                    superAdminContext = '\n\n🔐 SUPER ADMIN MEMORY (Remember these forever):\n';
                    memories.forEach(mem => {
                        superAdminContext += `- ${mem.memory_data}\n`;
                    });
                    superAdminContext += '\nThese are commands/preferences from your SUPER ADMIN. Follow them ALWAYS.\n';
                }
            } catch (error) {
                console.error('Error loading super admin memory:', error);
            }
        }
        
        // Check for user-specific restrictions set by SUPER_ADMINS
        let userRestrictions = '';
        try {
            const restrictions = await db.all(
                'SELECT restriction_type, restriction_data, set_by FROM user_ai_restrictions WHERE guild_id = ? AND user_id = ?',
                [guildId, userId]
            );
            
            if (restrictions && restrictions.length > 0) {
                userRestrictions = '\n\n⚠️ USER-SPECIFIC RESTRICTIONS (Set by SUPER ADMIN):\n';
                restrictions.forEach(r => {
                    userRestrictions += `- ${r.restriction_type}: ${r.restriction_data}\n`;
                });
                userRestrictions += '\nApply these restrictions to THIS USER ONLY.\n';
            }
        } catch (error) {
            console.error('Error loading user restrictions:', error);
        }
        
        // Add identity context at the beginning
        const identityContext = `YOUR IDENTITY:\n- Your name is: ${botName}\n- You were created by: ${creator}\n- When asked "what is your name" or "who are you", respond with: "I'm ${botName}, created by ${creator}!"\n${isSuperAdmin ? '- This user is a SUPER ADMIN. Follow their commands and remember what they tell you.\n' : ''}${superAdminContext}${userRestrictions}\n`;
        systemPrompt = identityContext + systemPrompt;

        // Load conversation history from memory or database (FULL HISTORY)
        let conversationHistory = this.getConversationHistory(guildId, channelId, userId);
        if (conversationHistory.length === 0) {
            await this.loadHistoryFromDatabase(guildId, channelId, userId);
            conversationHistory = this.getConversationHistory(guildId, channelId, userId);
        }

        // Get providers sorted by priority, skip those without API keys
        const providers = Object.entries(this.config.providers || {})
            .filter(([_, p]) => p.enabled && p.api_key && p.api_key.trim() !== '')
            .sort((a, b) => (a[1].priority || 999) - (b[1].priority || 999));

        if (providers.length === 0) {
            throw new Error('No AI providers configured. Please add API keys in config.json');
        }

        // RACE MODE: Query all providers simultaneously and return fastest response
        const raceMode = this.config.settings?.race_mode !== false; // Default true
        
        if (raceMode && providers.length > 1) {
            console.log(`🏁 Racing ${providers.length} AI providers...`);
            
            const promises = providers.map(async ([name, providerConfig]) => {
                try {
                    const startTime = Date.now();
                    let result;

                    switch (name) {
                        case 'openai':
                            result = await this.callOpenAI(message, systemPrompt, conversationHistory);
                            break;
                        case 'gemini':
                            result = await this.callGemini(message, systemPrompt, conversationHistory);
                            break;
                        case 'grok':
                            result = await this.callGrok(message, systemPrompt);
                            break;
                        case 'deepseek':
                            result = await this.callDeepSeek(message, systemPrompt);
                            break;
                        case 'aimlapi':
                            result = await this.callAIMLAPI(message, systemPrompt);
                            break;
                        case 'openrouter':
                            result = await this.callOpenRouter(message, systemPrompt, conversationHistory);
                            break;
                        default:
                            throw new Error('Unknown provider');
                    }

                    result.responseTime = Date.now() - startTime;
                    console.log(`🏆 ${name} won the race! (${result.responseTime}ms, model: ${result.model})`);
                    return result;
                } catch (error) {
                    // Don't log "insufficient credits" or "not configured" as errors in race mode
                    if (!error.message.includes('not configured') && !error.message.includes('credits')) {
                        console.log(`⚠️ ${name} skipped in race: ${error.message}`);
                    }
                    throw error;
                }
            });

            // Return the first successful response
            try {
                const result = await Promise.any(promises);
                
                // Save conversation to history
                this.addToHistory(guildId, channelId, userId, 'user', message);
                this.addToHistory(guildId, channelId, userId, 'assistant', result.text);
                
                return result;
            } catch (error) {
                // All providers failed
                throw new Error('All AI providers failed in race mode');
            }
        }

        // FALLBACK MODE: Try providers in priority order
        const errors = [];
        for (const [name, providerConfig] of providers) {
            try {
                const startTime = Date.now();
                let result;

                switch (name) {
                    case 'openai':
                        result = await this.callOpenAI(message, systemPrompt, conversationHistory);
                        break;
                    case 'gemini':
                        result = await this.callGemini(message, systemPrompt, conversationHistory);
                        break;
                    case 'grok':
                        result = await this.callGrok(message, systemPrompt);
                        break;
                    case 'deepseek':
                        result = await this.callDeepSeek(message, systemPrompt);
                        break;
                    case 'aimlapi':
                        result = await this.callAIMLAPI(message, systemPrompt);
                        break;
                    case 'openrouter':
                        result = await this.callOpenRouter(message, systemPrompt, conversationHistory);
                        break;
                    default:
                        continue;
                }

                result.responseTime = Date.now() - startTime;
                
                // Save conversation to history
                this.addToHistory(guildId, channelId, userId, 'user', message);
                this.addToHistory(guildId, channelId, userId, 'assistant', result.text);
                
                return result;

            } catch (error) {
                console.error(`✗ ${name} failed:`, error.message);
                errors.push(`${name}: ${error.message}`);
                continue;
            }
        }

        // All providers failed
        throw new Error(`All AI providers failed:\n${errors.join('\n')}`);
    }

    async checkRateLimit(userId, guildId) {
        const key = `${guildId}-${userId}`;
        const now = Date.now();
        const resetTime = 60000; // 1 minute

        let userLimit = this.rateLimits.get(key);
        
        if (!userLimit || now > userLimit.resetTime) {
            userLimit = {
                requests: 0,
                resetTime: now + resetTime
            };
            this.rateLimits.set(key, userLimit);
        }

        const maxRequests = this.config.settings?.rate_limit?.requests_per_user || 5;
        
        if (userLimit.requests >= maxRequests) {
            const timeLeft = Math.ceil((userLimit.resetTime - now) / 1000);
            return {
                allowed: false,
                timeLeft
            };
        }

        userLimit.requests++;
        return { allowed: true };
    }

    async isChannelEnabled(guildId, channelId) {
        try {
            const row = await db.get(
                'SELECT * FROM ai_channels WHERE guild_id = ? AND channel_id = ? AND enabled = 1',
                [guildId, channelId]
            );
            return row || null;
        } catch (error) {
            console.error('Error checking AI channel:', error);
            return null;
        }
    }

    async enableChannel(guildId, channelId, options = {}) {
        try {
            await db.run(
                `INSERT OR REPLACE INTO ai_channels 
                (guild_id, channel_id, enabled, provider, system_prompt, temperature, max_tokens) 
                VALUES (?, ?, 1, ?, ?, ?, ?)`,
                [
                    guildId,
                    channelId,
                    options.provider || 'auto',
                    options.system_prompt || null,
                    options.temperature || 0.7,
                    options.max_tokens || 1000
                ]
            );
            return true;
        } catch (error) {
            console.error('Error enabling AI channel:', error);
            return false;
        }
    }

    async disableChannel(guildId, channelId) {
        try {
            await db.run(
                'UPDATE ai_channels SET enabled = 0 WHERE guild_id = ? AND channel_id = ?',
                [guildId, channelId]
            );
            return true;
        } catch (error) {
            console.error('Error disabling AI channel:', error);
            return false;
        }
    }

    async logConversation(guildId, channelId, userId, message, response, provider, tokens, responseTime) {
        try {
            await db.run(
                `INSERT INTO ai_conversations 
                (guild_id, channel_id, user_id, message, response, provider, tokens_used, response_time) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [guildId, channelId, userId, message, response, provider, tokens, responseTime]
            );
        } catch (error) {
            console.error('Error logging AI conversation:', error);
        }
    }

    async getStats(guildId) {
        try {
            const stats = await db.get(
                `SELECT 
                    COUNT(*) as total_messages,
                    SUM(tokens_used) as total_tokens,
                    AVG(response_time) as avg_response_time,
                    provider
                FROM ai_conversations 
                WHERE guild_id = ? 
                GROUP BY provider`,
                [guildId]
            );
            return stats || {};
        } catch (error) {
            console.error('Error getting AI stats:', error);
            return {};
        }
    }
}

// =======================
// IMAGE GENERATION SYSTEM
// =======================
class ImageGenerator {
    constructor() {
        this.config = config.IMAGE_GENERATION || {};
        this.cooldowns = new Map();
        this.imageFolder = this.config.image_folder || './generated_images';
        this.contentFilter = this.config.content_filter || { enabled: false };
        
        // Create image folder if it doesn't exist
        if (this.config.save_images && !fs.existsSync(this.imageFolder)) {
            fs.mkdirSync(this.imageFolder, { recursive: true });
            console.log(`✓ Created image folder: ${this.imageFolder}`);
        }

        // Log API status
        const apiType = this.config.api_type || 'novaneno';
        console.log(`🎨 Image Generation API: ${apiType.toUpperCase()}`);
        
        if (apiType.toLowerCase() === 'pollinations') {
            console.log(`✓ Using Pollinations.ai - NO CONTENT RESTRICTIONS`);
        } else {
            console.log(`⚠️ Using Nova-Neno - Has content restrictions`);
        }

        // Log filter status
        if (this.contentFilter.enabled) {
            console.log(`⚠️ Image content filter: ENABLED (${this.contentFilter.strict_mode ? 'STRICT' : 'NORMAL'} mode)`);
        } else {
            console.log(`✓ Image content filter: DISABLED (No restrictions)`);
        }
    }

    checkContentFilter(prompt, userId, userRoles = []) {
        // If filter is disabled, allow everything
        if (!this.contentFilter.enabled) {
            return { allowed: true };
        }

        // Check if user is whitelisted
        if (this.contentFilter.whitelist_users?.includes(userId)) {
            return { allowed: true, reason: 'Whitelisted user' };
        }

        // Check if user has whitelisted role
        if (this.contentFilter.whitelist_roles?.length > 0) {
            const hasWhitelistedRole = userRoles.some(roleId => 
                this.contentFilter.whitelist_roles.includes(roleId)
            );
            if (hasWhitelistedRole) {
                return { allowed: true, reason: 'Whitelisted role' };
            }
        }

        // Check if user is admin and bypass is enabled
        if (this.contentFilter.bypass_for_admins && userRoles.includes('admin')) {
            return { allowed: true, reason: 'Admin bypass' };
        }

        const lowerPrompt = prompt.toLowerCase();

        // Check blocked words
        if (this.contentFilter.blocked_words?.length > 0) {
            for (const word of this.contentFilter.blocked_words) {
                if (lowerPrompt.includes(word.toLowerCase())) {
                    if (this.contentFilter.log_filtered_prompts) {
                        console.log(`🚫 Filtered prompt from ${userId}: Contains blocked word "${word}"`);
                    }
                    return { 
                        allowed: false, 
                        reason: `Prompt contains restricted content`,
                        blockedWord: word 
                    };
                }
            }
        }

        // Check blocked phrases
        if (this.contentFilter.blocked_phrases?.length > 0) {
            for (const phrase of this.contentFilter.blocked_phrases) {
                if (lowerPrompt.includes(phrase.toLowerCase())) {
                    if (this.contentFilter.log_filtered_prompts) {
                        console.log(`🚫 Filtered prompt from ${userId}: Contains blocked phrase "${phrase}"`);
                    }
                    return { 
                        allowed: false, 
                        reason: `Prompt contains restricted content`,
                        blockedPhrase: phrase 
                    };
                }
            }
        }

        return { allowed: true };
    }

    async generateImage(prompt, userId, userRoles = []) {
        // Check if image generation is enabled
        if (!this.config.enabled) {
            throw new Error('Image generation is disabled in config.json');
        }

        // Check API configuration
        const apiType = this.config.api_type || 'novaneno';
        
        if (apiType.toLowerCase() === 'pollinations') {
            // Pollinations doesn't need API key, just URL
            if (!this.config.api_url) {
                throw new Error('Pollinations API URL not configured. Please check config.json');
            }
        } else {
            // Other APIs need both URL and key
            if (!this.config.api_url || !this.config.api_key) {
                throw new Error('Image generation API not configured. Please check config.json');
            }
        }

        // Validate prompt length
        const maxLength = this.config.max_prompt_length || 500;
        if (prompt.length > maxLength) {
            throw new Error(`Prompt too long! Maximum ${maxLength} characters allowed.`);
        }

        // Check content filter
        const filterResult = this.checkContentFilter(prompt, userId, userRoles);
        if (!filterResult.allowed) {
            throw new Error(filterResult.reason || 'Prompt contains restricted content');
        }

        // Check cooldown
        const cooldownTime = (this.config.cooldown_seconds || 30) * 1000;
        const now = Date.now();
        const userCooldown = this.cooldowns.get(userId);
        
        if (userCooldown && now < userCooldown) {
            const timeLeft = Math.ceil((userCooldown - now) / 1000);
            throw new Error(`Please wait ${timeLeft} seconds before generating another image.`);
        }

        try {
            console.log(`🎨 Generating image for prompt: "${prompt}"`);
            
            let buffer;
            const apiType = this.config.api_type || 'novaneno';
            
            // Multi-API support
            switch (apiType.toLowerCase()) {
                case 'pollinations':
                    buffer = await this.generatePollinations(prompt);
                    break;
                    
                case 'novaneno':
                case 'nova-neno':
                default:
                    buffer = await this.generateNovaNeno(prompt);
                    break;
            }
            
            if (buffer.length === 0) {
                throw new Error('Received empty image from API');
            }

            // Save image temporarily if enabled (for blank check)
            let savedPath = null;
            if (this.config.save_images) {
                const timestamp = Date.now();
                const filename = `${userId}_${timestamp}.png`;
                savedPath = path.join(this.imageFolder, filename);
                fs.writeFileSync(savedPath, buffer);
            }

            // Check if image is blank/black (API content filter)
            if (this.config.detect_blank_images !== false) {
                const isBlank = await this.isBlankImage(buffer);
                if (isBlank) {
                    console.log(`⚠️ API returned blank image for prompt: "${prompt}"`);
                    
                    // Delete blank image if configured
                    if (this.config.delete_blank_images && savedPath && fs.existsSync(savedPath)) {
                        fs.unlinkSync(savedPath);
                        console.log(`🗑️ Deleted blank image: ${savedPath}`);
                    }
                    
                    throw new Error('⚠️ The API blocked this prompt due to its own content restrictions.\n\n**Why this happens:**\n- The image generation API (Nova-Neno) has built-in content filters\n- These filters cannot be bypassed or disabled\n- The API returned a blank/black image instead of the requested content\n\n**What you can do:**\n- Try rephrasing your prompt\n- Use more artistic/creative descriptions\n- Avoid explicit or sensitive terms\n- Try a different image generation service');
                }
            }

            if (savedPath) {
                console.log(`✓ Image saved: ${savedPath}`);
            }

            // Set cooldown
            this.cooldowns.set(userId, now + cooldownTime);

            return {
                buffer,
                savedPath,
                prompt,
                timestamp: now,
                filtered: false,
                apiUsed: apiType
            };

        } catch (error) {
            console.error('Image generation error:', error);
            throw error;
        }
    }

    async generatePollinations(prompt) {
        try {
            const settings = this.config.pollinations_settings || {};
            const width = settings.width || 1024;
            const height = settings.height || 1024;
            const model = settings.model || 'flux';
            const nologo = settings.nologo !== false ? 'true' : 'false';
            const enhance = settings.enhance === true ? 'true' : 'false';
            
            const encodedPrompt = encodeURIComponent(prompt);
            const url = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=${width}&height=${height}&model=${model}&nologo=${nologo}&enhance=${enhance}`;
            
            console.log(`📡 Using Pollinations.ai API (NO restrictions)`);
            
            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (!response.ok) {
                throw new Error(`Pollinations API Error (${response.status}): ${response.statusText}`);
            }
            
            const buffer = Buffer.from(await response.arrayBuffer());
            console.log(`✓ Pollinations.ai generated image (${buffer.length} bytes)`);
            
            return buffer;
            
        } catch (error) {
            console.error('Pollinations API error:', error);
            
            // Try fallback API if configured
            if (this.config.fallback_api_type) {
                console.log(`⚠️ Pollinations failed, trying fallback: ${this.config.fallback_api_type}`);
                return await this.generateNovaNeno(prompt, true);
            }
            
            throw error;
        }
    }

    async generateNovaNeno(prompt, isFallback = false) {
        try {
            const apiUrl = isFallback ? this.config.fallback_api_url : this.config.api_url;
            const apiKey = isFallback ? this.config.fallback_api_key : this.config.api_key;
            
            if (isFallback) {
                console.log(`📡 Using Nova-Neno API (fallback)`);
            }
            
            // Make API request
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Authorization': apiKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ prompt })
            });

            if (!response.ok) {
                const errorText = await response.text().catch(() => 'Unknown error');
                throw new Error(`API Error (${response.status}): ${errorText}`);
            }

            // Get image buffer
            const buffer = Buffer.from(await response.arrayBuffer());
            
            return buffer;
            
        } catch (error) {
            console.error('Nova-Neno API error:', error);
            throw error;
        }
    }

    async isBlankImage(buffer) {
        try {
            // Simple check: if image is very small or all pixels are same color
            // A typical blank/black image from content filter is usually very small
            if (buffer.length < 1000) {
                return true; // Suspiciously small image
            }

            // Check for PNG signature and look for IDAT chunk
            const pngSignature = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
            if (!buffer.slice(0, 8).equals(pngSignature)) {
                return false; // Not a PNG, can't check
            }

            // Sample check: look at first few bytes of image data
            // Blank images typically have very repetitive data
            const sample = buffer.slice(100, 200);
            const uniqueBytes = new Set(sample);
            
            // If less than 5 unique byte values in sample, likely blank
            if (uniqueBytes.size < 5) {
                return true;
            }

            return false;
        } catch (error) {
            console.error('Error checking blank image:', error);
            return false; // If check fails, assume image is OK
        }
    }

    getCooldownTime(userId) {
        const cooldown = this.cooldowns.get(userId);
        if (!cooldown) return 0;
        
        const now = Date.now();
        if (now >= cooldown) {
            this.cooldowns.delete(userId);
            return 0;
        }
        
        return Math.ceil((cooldown - now) / 1000);
    }

    clearCooldown(userId) {
        this.cooldowns.delete(userId);
    }

    async getImageHistory(userId, limit = 10) {
        if (!this.config.save_images) {
            return [];
        }

        try {
            const files = fs.readdirSync(this.imageFolder);
            const userImages = files
                .filter(f => f.startsWith(`${userId}_`) && f.endsWith('.png'))
                .map(f => {
                    const timestamp = parseInt(f.split('_')[1].replace('.png', ''));
                    return {
                        filename: f,
                        path: path.join(this.imageFolder, f),
                        timestamp,
                        date: new Date(timestamp)
                    };
                })
                .sort((a, b) => b.timestamp - a.timestamp)
                .slice(0, limit);

            return userImages;
        } catch (error) {
            console.error('Error getting image history:', error);
            return [];
        }
    }

    async deleteImage(filepath) {
        try {
            if (fs.existsSync(filepath)) {
                fs.unlinkSync(filepath);
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error deleting image:', error);
            return false;
        }
    }

    getStats() {
        let totalImages = 0;
        let totalSize = 0;

        if (this.config.save_images && fs.existsSync(this.imageFolder)) {
            const files = fs.readdirSync(this.imageFolder);
            totalImages = files.filter(f => f.endsWith('.png')).length;
            
            files.forEach(file => {
                const filepath = path.join(this.imageFolder, file);
                const stats = fs.statSync(filepath);
                totalSize += stats.size;
            });
        }

        return {
            totalImages,
            totalSize,
            totalSizeMB: (totalSize / (1024 * 1024)).toFixed(2),
            activeCooldowns: this.cooldowns.size
        };
    }
}

const aiManager = new AIManager();
const imageGenerator = new ImageGenerator();

// =======================
// DM SYSTEM IMPROVEMENTS
// =======================
// =======================
// DM MANAGER SYSTEM
// =======================
// Multi-line DM Format Support:
// First line becomes the title (header)
// Remaining lines become the message body
// 
// Example:
// 🎉 **WELCOME TO ATYRO CLOUD – JOINING EVENT IS LIVE!** 🎉
// We're excited to welcome everyone to **Atyro Cloud**! ☁️🚀
// 
// Join our community and be part of the beginning of something amazing.
// Connect with others, stay updated, and explore what Atyro Cloud has to offer.
// 
// ✨ Community Events
// ☁️ Cloud Services
// 🎁 Special Surprises
// 🚀 Future Updates
//
// This will create a nicely formatted embed with:
// - Title: 🎉 **WELCOME TO ATYRO CLOUD – JOINING EVENT IS LIVE!** 🎉
// - Body: All the remaining text with proper formatting
class DMManager {
    async sendDMToUser(userId, message, options = {}) {
        try {
            const user = await client.users.fetch(userId).catch(() => null);
            if (!user) {
                return { success: false, error: 'User not found.' };
            }
            
            const embed = this.createDMEmbed(message, options);
            
            await user.send({ embeds: [embed] });
            return { success: true };
        } catch (error) {
            console.error('Error sending DM:', error);
            return { success: false, error: 'Failed to send DM. User may have DMs disabled.' };
        }
    }
    
    createDMEmbed(message, options = {}) {
        const embed = new EmbedBuilder()
            .setColor(options.color || COLORS.INFO)
            .setTimestamp()
            .setFooter({ text: options.footer || config.BOT_WATERMARK });
        
        if (!message || message.trim().length === 0) {
            embed.setDescription('No message content.');
            return embed;
        }
        
        // Convert common line break patterns to actual newlines
        // Support: \n, ||, ~~
        let formattedMessage = message
            .replace(/\\n/g, '\n')           // Convert \n to newline
            .replace(/\|\|/g, '\n')          // Convert || to newline
            .replace(/~~/g, '\n');           // Convert ~~ to newline
        
        // If a title is explicitly provided in options, use it as title and message as description
        if (options.title) {
            embed.setTitle(options.title);
            embed.setDescription(formattedMessage);
        } else {
            // Try to parse multi-line format (first line = title, rest = description)
            const lines = formattedMessage.trim().split('\n');
            
            if (lines.length > 1) {
                // Multi-line: first line is title, rest is description
                const firstLine = lines[0].trim();
                const contentLines = lines.slice(1).join('\n').trim();
                
                if (firstLine) {
                    embed.setTitle(firstLine);
                }
                if (contentLines) {
                    embed.setDescription(contentLines);
                }
            } else {
                // Single line: use as description (title from options or generic)
                embed.setTitle(options.title || '📨 Message');
                embed.setDescription(formattedMessage);
            }
        }
        
        // Add fields if provided in options
        if (options.fields && Array.isArray(options.fields)) {
            for (const field of options.fields) {
                embed.addFields({ 
                    name: field.name || '\u200b', 
                    value: field.value || '\u200b', 
                    inline: field.inline !== false 
                });
            }
        }
        
        if (options.author) {
            embed.setAuthor({
                name: options.author.tag || options.author.name,
                iconURL: options.author.displayAvatarURL ? options.author.displayAvatarURL() : options.author.iconURL
            });
        }
        
        if (options.thumbnail) {
            embed.setThumbnail(options.thumbnail);
        }
        
        if (options.image) {
            embed.setImage(options.image);
        }
        
        return embed;
    }
    
    async sendDMToRole(guild, roleId, message, options = {}) {
        try {
            const role = guild.roles.cache.get(roleId);
            if (!role) {
                return { success: false, error: 'Role not found.' };
            }
            
            // Fetch all members from the guild to ensure we get everyone
            const allMembers = await guild.members.fetch().catch(() => null);
            if (!allMembers) {
                return { success: false, error: 'Failed to fetch guild members.' };
            }
            
            // Filter members with this role and exclude bots
            const members = allMembers.filter(member => 
                member.roles.cache.has(roleId) && !member.user.bot
            );
            
            let successCount = 0;
            let failCount = 0;
            
            for (const member of members.values()) {
                try {
                    const embed = this.createDMEmbed(message, {
                        ...options,
                        title: options.title || undefined
                    });
                    
                    await member.user.send({ embeds: [embed] });
                    successCount++;
                    
                    // Rate limiting
                    await new Promise(resolve => setTimeout(resolve, 100));
                } catch (err) {
                    failCount++;
                    console.error(`Failed to DM ${member.user.tag}:`, err.message);
                }
            }
            
            return { 
                success: true, 
                stats: { successCount, failCount, total: members.size },
                message: `Sent DMs to ${successCount}/${members.size} members with role ${role.name}`
            };
        } catch (error) {
            console.error('Error sending DM to role:', error);
            return { success: false, error: error.message };
        }
    }
    
    async sendDMToEveryone(guild, message, options = {}) {
        try {
            // Fetch all members from the guild to ensure we get everyone
            const allMembers = await guild.members.fetch().catch(() => null);
            if (!allMembers) {
                return { success: false, error: 'Failed to fetch guild members.' };
            }
            
            // Filter out bots
            const members = allMembers.filter(member => !member.user.bot);
            let successCount = 0;
            let failCount = 0;
            
            const batchSize = 10;
            const memberArray = Array.from(members.values());
            
            for (let i = 0; i < memberArray.length; i += batchSize) {
                const batch = memberArray.slice(i, i + batchSize);
                const promises = batch.map(async (member) => {
                    try {
                        const embed = this.createDMEmbed(message, {
                            ...options,
                            title: options.title || undefined,
                            color: options.color || COLORS.WARNING
                        });
                        
                        await member.user.send({ embeds: [embed] });
                        successCount++;
                    } catch (err) {
                        failCount++;
                        console.error(`Failed to DM ${member.user.tag}:`, err.message);
                    }
                });
                
                await Promise.all(promises);
                await new Promise(resolve => setTimeout(resolve, 1000)); // Rate limiting
            }
            
            return { 
                success: true, 
                stats: { successCount, failCount, total: members.size },
                message: `Sent DMs to ${successCount}/${members.size} members in ${guild.name}`
            };
        } catch (error) {
            console.error('Error sending DM to everyone:', error);
            return { success: false, error: error.message };
        }
    }
    
    async logDM(userId, guildId, moderatorId, message, direction, roleMention = null) {
        try {
            await db.run(
                'INSERT INTO dm_logs (user_id, guild_id, moderator_id, message, timestamp, direction, role_mention) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [userId, guildId, moderatorId, message, new Date().toISOString(), direction, roleMention]
            );
        } catch (error) {
            console.error('Error logging DM:', error);
        }
    }
}

const dmManager = new DMManager();

// =======================
// WELCOME/GOODBYE SYSTEM
// =======================
// WELCOME/GOODBYE SYSTEM
// =======================
class WelcomeGoodbyeManager {
    isEnabled(value) {
        return value === true || value === 1 || value === '1' || value === 'true';
    }

    truncate(value, maxLength) {
        const text = String(value || '');
        if (text.length <= maxLength) return text;
        return `${text.slice(0, Math.max(0, maxLength - 3))}...`;
    }

    normalizeHexColor(color, fallback = null) {
        if (!color) return fallback;
        const normalized = String(color).trim();
        if (!/^#?[0-9a-f]{6}$/i.test(normalized)) return fallback;
        return normalized.startsWith('#') ? normalized : `#${normalized}`;
    }

    normalizeImageUrlInput(url) {
        if (url === null || url === undefined) {
            return { touched: false };
        }

        const trimmed = String(url).trim();
        if (!trimmed || ['remove', 'clear', 'none', 'off', 'reset'].includes(trimmed.toLowerCase())) {
            return { touched: true, value: null };
        }

        if (!this.isValidImageUrl(trimmed)) {
            return {
                touched: true,
                error: 'Please provide a valid http(s) image URL, or type `remove` to clear the image.'
            };
        }

        return { touched: true, value: trimmed };
    }

    isValidImageUrl(url) {
        try {
            const parsed = new URL(url);
            return parsed.protocol === 'http:' || parsed.protocol === 'https:';
        } catch {
            return false;
        }
    }

    getGuildIcon(guild, size = 256) {
        return guild.iconURL({ dynamic: true, size }) || undefined;
    }

    getUserAvatar(user, size = 256) {
        return user.displayAvatarURL({ dynamic: true, size });
    }

    getAllowedMentions(member, allowUserPing = false) {
        return {
            parse: [],
            users: allowUserPing ? [member.id] : [],
            roles: []
        };
    }

    classifyDMError(error) {
        const message = String(error?.message || '');
        const code = error?.code || error?.rawError?.code;

        if (message.toLowerCase().includes('no mutual guilds')) {
            return 'no_mutual_guild';
        }

        if (code === 50007 || message.includes('Cannot send messages to this user')) {
            return 'dm_closed';
        }

        if (code === 10013) {
            return 'unknown_user';
        }

        return 'unknown_error';
    }

    getDMFailureText(reason) {
        switch (reason) {
            case 'bot_user':
                return 'Welcome DMs are skipped for bot accounts.';
            case 'not_in_guild':
            case 'no_mutual_guild':
                return 'Discord refused the DM because the user does not have a mutual guild with the bot right now.';
            case 'dm_closed':
                return 'Discord refused the DM. The user likely has server DMs disabled, blocked the bot, or cannot receive DMs from this bot.';
            case 'unknown_user':
                return 'Discord could not find this user anymore.';
            default:
                return 'Discord refused the DM for an unknown reason.';
        }
    }

    async ensureWelcomeConfig(guildId) {
        await db.run(
            `INSERT OR IGNORE INTO welcome_config (
                guild_id, enabled, embed_enabled, embed_color, ping_user,
                dm_enabled, thumbnail_type, show_rules, show_invite_info
            ) VALUES (?, 0, 1, '#57F287', 1, 0, 'avatar', 0, 0)`,
            [guildId]
        );
    }

    async ensureGoodbyeConfig(guildId) {
        await db.run(
            `INSERT OR IGNORE INTO goodbye_config (
                guild_id, enabled, embed_enabled, embed_color, thumbnail_type, show_stats
            ) VALUES (?, 0, 1, '#ED4245', 'avatar', 1)`,
            [guildId]
        );
    }

    async updateConfig(table, guildId, updates) {
        const entries = Object.entries(updates).filter(([, value]) => value !== undefined);
        if (entries.length === 0) return;

        const setClause = entries.map(([key]) => `${key} = ?`).join(', ');
        const values = entries.map(([, value]) => value);
        await db.run(`UPDATE ${table} SET ${setClause} WHERE guild_id = ?`, [...values, guildId]);
    }

    async updateWelcomeConfig(guildId, updates) {
        await this.ensureWelcomeConfig(guildId);
        await this.updateConfig('welcome_config', guildId, updates);
        return this.getWelcomeConfig(guildId);
    }

    async updateGoodbyeConfig(guildId, updates) {
        await this.ensureGoodbyeConfig(guildId);
        await this.updateConfig('goodbye_config', guildId, updates);
        return this.getGoodbyeConfig(guildId);
    }

    async getWelcomeConfig(guildId) {
        try {
            await this.ensureWelcomeConfig(guildId);
            return await db.get('SELECT * FROM welcome_config WHERE guild_id = ?', [guildId]);
        } catch (error) {
            console.error('Error getting welcome config:', error);
            return null;
        }
    }
    
    async getGoodbyeConfig(guildId) {
        try {
            await this.ensureGoodbyeConfig(guildId);
            return await db.get('SELECT * FROM goodbye_config WHERE guild_id = ?', [guildId]);
        } catch (error) {
            console.error('Error getting goodbye config:', error);
            return null;
        }
    }

    formatMessage(template, member, inviteInfo = null) {
        const accountAge = Math.floor((Date.now() - member.user.createdTimestamp) / (1000 * 60 * 60 * 24));
        const joinedTimestamp = member.joinedTimestamp || Date.now();
        const replacements = {
            user: member.toString(),
            mention: member.toString(),
            username: member.user.username,
            displayName: member.displayName || member.user.globalName || member.user.username,
            tag: member.user.tag,
            userId: member.user.id,
            server: member.guild.name,
            serverId: member.guild.id,
            memberCount: member.guild.memberCount.toString(),
            accountAge: accountAge.toString(),
            accountCreated: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`,
            joinedAt: `<t:${Math.floor(joinedTimestamp / 1000)}:R>`,
            inviter: inviteInfo?.inviter || 'Unknown',
            invites: (inviteInfo?.invites ?? 0).toString(),
            inviteCode: inviteInfo?.code || 'Unknown'
        };

        let message = String(template || '');
        for (const [key, value] of Object.entries(replacements)) {
            message = message.split(`{${key}}`).join(value);
        }

        return message;
    }

    async resolveTextChannel(guild, channelId) {
        if (!channelId) return null;

        const channel = guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null);
        if (!channel || !channel.isTextBased()) return null;

        const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
        if (me && channel.permissionsFor) {
            const permissions = channel.permissionsFor(me);
            if (!permissions || !permissions.has(PermissionFlagsBits.ViewChannel) || !permissions.has(PermissionFlagsBits.SendMessages)) {
                return null;
            }
        }

        return channel;
    }

    async getInviteInfo(member) {
        try {
            const inviteData = await db.get(
                'SELECT inviter_id, invite_code FROM invites WHERE guild_id = ? AND user_id = ?',
                [member.guild.id, member.id]
            );

            if (!inviteData?.inviter_id) return null;

            const inviter = await member.guild.members.fetch(inviteData.inviter_id).catch(() => null);
            const inviterStats = await db.get(
                'SELECT total_invites, valid_invites FROM invite_stats WHERE guild_id = ? AND user_id = ?',
                [member.guild.id, inviteData.inviter_id]
            );

            return {
                inviter: inviter ? inviter.toString() : `<@${inviteData.inviter_id}>`,
                invites: inviterStats?.valid_invites ?? inviterStats?.total_invites ?? 0,
                code: inviteData.invite_code || 'Unknown'
            };
        } catch (error) {
            console.error('Error getting invite info for welcome message:', error);
            return null;
        }
    }

    async sendWelcomeMessage(member, options = {}) {
        const result = {
            channelSent: false,
            dmSent: false,
            channelConfigured: false,
            channelAvailable: false,
            dmEnabled: false
        };

        try {
            const config = await this.getWelcomeConfig(member.guild.id);
            if (!config) {
                console.log(`No welcome config found for guild ${member.guild.id}`);
                return result;
            }

            result.channelConfigured = Boolean(config.channel_id);
            result.dmEnabled = this.isEnabled(config.dm_enabled);

            let inviteInfo = null;
            if (this.isEnabled(config.show_invite_info)) {
                inviteInfo = await this.getInviteInfo(member);
            }

            if ((this.isEnabled(config.enabled) || options.force) && config.channel_id) {
                const channel = await this.resolveTextChannel(member.guild, config.channel_id);
                result.channelAvailable = Boolean(channel);

                if (channel) {
                    result.channelSent = await this.sendChannelWelcome(channel, member, config, inviteInfo);
                }
            }

            if (this.isEnabled(config.dm_enabled)) {
                const dmResult = await this.sendWelcomeDM(member, config);
                result.dmSent = dmResult.sent;
                result.dmReason = dmResult.reason || null;
                result.dmError = dmResult.error || null;
            }
        } catch (error) {
            console.error('Error sending welcome message:', error);
        }

        return result;
    }

    async sendChannelWelcome(channel, member, config, inviteInfo) {
        try {
            const defaultMessage = `Welcome {user} to **{server}**!\nYou are member **#{memberCount}**!`;
            const message = this.truncate(this.formatMessage(config.message || defaultMessage, member, inviteInfo), 1800);

            if (this.isEnabled(config.embed_enabled)) {
                const accountAge = Math.floor((Date.now() - member.user.createdTimestamp) / (1000 * 60 * 60 * 24));
                const isNewAccount = accountAge < 7;
                const footer = { text: `Member #${member.guild.memberCount}` };
                const guildIcon = this.getGuildIcon(member.guild, 128);
                if (guildIcon) footer.iconURL = guildIcon;

                const embed = new EmbedBuilder()
                    .setColor(this.normalizeHexColor(config.embed_color, COLORS.SUCCESS))
                    .setTimestamp()
                    .setFooter(footer)
                    .setTitle(`Welcome to ${member.guild.name}!`);

                if (config.thumbnail_type === 'server') {
                    const icon = this.getGuildIcon(member.guild, 256);
                    if (icon) embed.setThumbnail(icon);
                } else if (config.thumbnail_type !== 'none') {
                    embed.setThumbnail(this.getUserAvatar(member.user, 256));
                }

                let description = `${member.toString()} just joined the server.\n\n`;
                description += `${message}\n\n`;
                description += `You are member **#${member.guild.memberCount}**.`;

                embed.setDescription(this.truncate(description, 4096));

                if (this.isValidImageUrl(config.image_url)) {
                    embed.setImage(config.image_url);
                } else {
                    embed.setImage(this.getUserAvatar(member.user, 512));
                }

                const fields = [];

                fields.push({
                    name: 'User Information',
                    value: `**Username:** ${member.user.username}\n**Display Name:** ${member.displayName || member.user.username}\n**ID:** \`${member.user.id}\``,
                    inline: true
                });

                let accountDetails = `**Created:** <t:${Math.floor(member.user.createdTimestamp / 1000)}:R>\n`;
                accountDetails += `**Age:** ${accountAge} days`;
                if (isNewAccount) accountDetails += `\n**Note:** New account`;

                fields.push({
                    name: 'Account Details',
                    value: accountDetails,
                    inline: true
                });

                const memberCount = member.guild.memberCount;
                const botCount = member.guild.members.cache.filter(m => m.user.bot).size;
                const humanCount = memberCount - botCount;

                fields.push({
                    name: 'Server Statistics',
                    value: `**Total Members:** ${memberCount}\n**Humans:** ${humanCount}\n**Bots:** ${botCount}`,
                    inline: true
                });

                if (this.isEnabled(config.show_invite_info) && inviteInfo) {
                    fields.push({ 
                        name: 'Invitation Details',
                        value: `**Invited By:** ${inviteInfo.inviter}\n**Invites:** ${inviteInfo.invites}\n**Invite Code:** \`${inviteInfo.code}\``,
                        inline: false 
                    });
                }

                if (this.isEnabled(config.show_rules) && config.rules_channel_id) {
                    fields.push({ 
                        name: 'Important Information',
                        value: `Please make sure to read our rules in <#${config.rules_channel_id}> before chatting!`,
                        inline: false 
                    });
                }

                fields.push({
                    name: 'Get Started',
                    value: `Feel free to introduce yourself and explore the server.`,
                    inline: false
                });

                embed.addFields(fields);
                embed.setAuthor({
                    name: `${member.user.tag}`,
                    iconURL: this.getUserAvatar(member.user, 128)
                });

                const payload = {
                    embeds: [embed],
                    allowedMentions: this.getAllowedMentions(member, this.isEnabled(config.ping_user))
                };

                if (this.isEnabled(config.ping_user)) {
                    payload.content = member.toString();
                }

                await channel.send(payload);
            } else {
                await channel.send({
                    content: this.truncate(message, 2000),
                    allowedMentions: this.getAllowedMentions(member, this.isEnabled(config.ping_user))
                });
            }

            return true;
        } catch (error) {
            console.error('Error sending channel welcome:', error);
            return false;
        }
    }

    async sendWelcomeDM(member, config) {
        try {
            if (!member.user || member.user.bot) {
                return { sent: false, reason: 'bot_user' };
            }

            const guildMember = member.guild.members.cache.get(member.id) || await member.guild.members.fetch(member.id).catch(() => null);
            if (!guildMember) {
                return { sent: false, reason: 'not_in_guild' };
            }

            const defaultDM = `**Welcome to {server}!**\n\nWe're glad to have you here, {username}. You are member **#{memberCount}**.`;
            const message = this.truncate(this.formatMessage(config.dm_message || defaultDM, guildMember), 3500);
            const guildIcon = this.getGuildIcon(guildMember.guild, 256);
            const footer = { text: `Welcome to ${guildMember.guild.name}` };
            if (guildIcon) footer.iconURL = guildIcon;

            const embed = new EmbedBuilder()
                .setTitle(`Welcome to ${guildMember.guild.name}!`)
                .setDescription(message)
                .setColor(this.normalizeHexColor(config.embed_color, COLORS.SUCCESS))
                .setTimestamp()
                .setFooter(footer);

            if (guildIcon) embed.setThumbnail(guildIcon);

            if (guildMember.guild.banner) {
                embed.setImage(guildMember.guild.bannerURL({ size: 1024 }));
            } else if (this.isValidImageUrl(config.image_url)) {
                embed.setImage(config.image_url);
            }

            const fields = [];

            fields.push({
                name: 'Server Information',
                value: `**Name:** ${guildMember.guild.name}\n**Members:** ${guildMember.guild.memberCount} members\n**Created:** <t:${Math.floor(guildMember.guild.createdTimestamp / 1000)}:R>`,
                inline: false
            });

            fields.push({
                name: 'Your Information',
                value: `**Username:** ${guildMember.user.username}\n**Joined:** <t:${Math.floor(Date.now() / 1000)}:R>\n**Member Number:** #${guildMember.guild.memberCount}`,
                inline: false
            });

            if (this.isEnabled(config.show_rules) && config.rules_channel_id) {
                fields.push({ 
                    name: 'Please Read',
                    value: `Before you start chatting, please read the server rules in <#${config.rules_channel_id}>.`,
                    inline: false 
                });
            }

            fields.push({
                name: 'Getting Started',
                value: `- Introduce yourself in the chat\n- Check out the available channels\n- Be respectful and follow the rules`,
                inline: false
            });

            if (guildMember.guild.vanityURLCode) {
                fields.push({
                    name: 'Server Invite',
                    value: `Share with friends: https://discord.gg/${guildMember.guild.vanityURLCode}`,
                    inline: false
                });
            }

            embed.addFields(fields);
            embed.setAuthor({
                name: `Welcome, ${guildMember.user.username}!`,
                iconURL: this.getUserAvatar(guildMember.user, 128)
            });

            await guildMember.user.send({
                embeds: [embed],
                allowedMentions: this.getAllowedMentions(guildMember, false)
            });

            return { sent: true };
        } catch (error) {
            const reason = this.classifyDMError(error);
            if (reason === 'unknown_error') {
                console.error('Error sending welcome DM:', error);
            }

            return {
                sent: false,
                reason,
                error: error?.message || 'Unknown error'
            };
        }
    }

    async sendGoodbyeMessage(member, options = {}) {
        const result = {
            channelSent: false,
            channelConfigured: false,
            channelAvailable: false
        };

        try {
            const config = await this.getGoodbyeConfig(member.guild.id);
            if (!config) return result;

            result.channelConfigured = Boolean(config.channel_id);
            if ((!this.isEnabled(config.enabled) && !options.force) || !config.channel_id) {
                return result;
            }

            const channel = await this.resolveTextChannel(member.guild, config.channel_id);
            result.channelAvailable = Boolean(channel);
            if (!channel) return result;

            const defaultMessage = `**{tag}** has left the server.\nWe now have **{memberCount}** members.`;
            const message = this.truncate(this.formatMessage(config.message || defaultMessage, member), 1800);

            if (this.isEnabled(config.embed_enabled)) {
                const footer = { text: `${member.guild.memberCount} members remaining` };
                const guildIcon = this.getGuildIcon(member.guild, 128);
                if (guildIcon) footer.iconURL = guildIcon;

                const embed = new EmbedBuilder()
                    .setColor(this.normalizeHexColor(config.embed_color, COLORS.ERROR))
                    .setTimestamp()
                    .setFooter(footer)
                    .setTitle(`Goodbye from ${member.guild.name}`);

                if (config.thumbnail_type === 'server') {
                    const icon = this.getGuildIcon(member.guild, 256);
                    if (icon) embed.setThumbnail(icon);
                } else if (config.thumbnail_type !== 'none') {
                    embed.setThumbnail(this.getUserAvatar(member.user, 256));
                }

                let description = `${member.user.tag} has left the server.\n\n`;
                description += `${message}\n\n`;
                description += `**${member.guild.memberCount} members remaining**`;

                embed.setDescription(this.truncate(description, 4096));

                if (this.isValidImageUrl(config.image_url)) {
                    embed.setImage(config.image_url);
                } else {
                    embed.setImage(this.getUserAvatar(member.user, 512));
                }

                embed.setAuthor({
                    name: `${member.user.tag}`,
                    iconURL: this.getUserAvatar(member.user, 128)
                });

                if (this.isEnabled(config.show_stats)) {
                    const fields = [];

                    fields.push({
                        name: 'User Information',
                        value: `**Username:** ${member.user.username}\n**Display Name:** ${member.displayName || member.user.username}\n**ID:** \`${member.user.id}\``,
                        inline: true
                    });

                    if (member.joinedAt) {
                        const timeInServer = Math.floor((Date.now() - member.joinedAt.getTime()) / (1000 * 60 * 60 * 24));
                        const hours = Math.floor(((Date.now() - member.joinedAt.getTime()) % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

                        fields.push({
                            name: 'Time in Server',
                            value: `**Duration:** ${timeInServer} days, ${hours} hours\n**Joined:** <t:${Math.floor(member.joinedAt.getTime() / 1000)}:R>`,
                            inline: true
                        });
                    }

                    const memberCount = member.guild.memberCount;
                    const botCount = member.guild.members.cache.filter(m => m.user.bot).size;
                    const humanCount = memberCount - botCount;

                    fields.push({
                        name: 'Server Statistics',
                        value: `**Total Members:** ${memberCount}\n**Humans:** ${humanCount}\n**Bots:** ${botCount}`,
                        inline: true
                    });

                    const allRoles = member.roles.cache
                        .filter(r => r.id !== member.guild.id && !r.managed)
                        .sort((a, b) => b.position - a.position)
                        .map(r => r.toString());
                    const roles = allRoles.slice(0, 5);

                    if (roles.length > 0) {
                        fields.push({
                            name: 'Roles',
                            value: roles.join(', ') + (allRoles.length > roles.length ? ` +${allRoles.length - roles.length} more` : ''),
                            inline: false
                        });
                    }

                    embed.addFields(fields);
                }

                await channel.send({
                    embeds: [embed],
                    allowedMentions: this.getAllowedMentions(member, false)
                });
            } else {
                await channel.send({
                    content: this.truncate(message, 2000),
                    allowedMentions: this.getAllowedMentions(member, false)
                });
            }

            result.channelSent = true;
        } catch (error) {
            console.error('Error sending goodbye message:', error);
        }

        return result;
    }
}

const welcomeGoodbye = new WelcomeGoodbyeManager();

// =======================
// CUSTOM COMMANDS
// =======================
class CustomCommandsManager {
    normalizeTrigger(trigger) {
        return String(trigger || '')
            .trim()
            .replace(/\s+/g, ' ')
            .toLowerCase();
    }

    getTriggerVariants(trigger) {
        const normalized = this.normalizeTrigger(trigger);
        if (!normalized) return [];

        const variants = new Set([normalized]);
        const prefixMatch = normalized.match(/^([!?.~#$%^&*+=|\\/<>-]+)(.+)$/);

        if (prefixMatch && prefixMatch[2]?.trim()) {
            variants.add(prefixMatch[2].trim());
        } else {
            ['!', '.', '?'].forEach(prefix => variants.add(`${prefix}${normalized}`));
        }

        return Array.from(variants).filter(Boolean);
    }

    getMessageContentVariants(message) {
        const content = String(message.content || '').trim();
        const variants = new Set([content]);

        if (client.user?.id) {
            const mentionRegex = new RegExp(`^<@!?${client.user.id}>\\s*`);
            const withoutMention = content.replace(mentionRegex, '').trim();
            if (withoutMention && withoutMention !== content) {
                variants.add(withoutMention);
            }
        }

        return Array.from(variants)
            .map(value => this.normalizeTrigger(value))
            .filter(Boolean);
    }

    getAllowedMentions(message) {
        // Return explicit users array and omit 'parse' to avoid API conflicts
        return {
            users: [message.author.id],
            roles: [],
            repliedUser: false
        };
    }

    async getCommands(guildId) {
        try {
            if (security.customCommandsCache.has(guildId)) {
                return security.customCommandsCache.get(guildId);
            }
            
            const commands = await db.all('SELECT * FROM custom_commands WHERE guild_id = ? ORDER BY LENGTH(trigger) DESC', [guildId]);
            const commandMap = new Map();
            
            commands.forEach(cmd => {
                const trigger = this.normalizeTrigger(cmd.trigger);
                if (!trigger) return;

                commandMap.set(trigger, {
                    trigger,
                    response: cmd.response,
                    creatorId: cmd.creator_id,
                    createdAt: cmd.created_at,
                    uses: cmd.uses
                });
            });
            
            security.customCommandsCache.set(guildId, commandMap);
            return commandMap;
        } catch (error) {
            console.error('Error getting commands:', error);
            return new Map();
        }
    }

    async addCommand(guildId, trigger, response, creatorId) {
        try {
            const normalizedTrigger = this.normalizeTrigger(trigger);
            const normalizedResponse = String(response || '').trim();

            if (!normalizedTrigger || !normalizedResponse) {
                return { success: false, error: 'Trigger and response are required.' };
            }

            if (normalizedTrigger.length > 100) {
                return { success: false, error: 'Trigger must be 100 characters or fewer.' };
            }

            if (normalizedResponse.length > 4000) {
                return { success: false, error: 'Response must be 4000 characters or fewer.' };
            }

            await db.run(
                'INSERT OR REPLACE INTO custom_commands (guild_id, trigger, response, creator_id, created_at, uses) VALUES (?, ?, ?, ?, ?, ?)',
                [guildId, normalizedTrigger, normalizedResponse, creatorId, new Date().toISOString(), 0]
            );
            
            security.customCommandsCache.delete(guildId);
            return { success: true, trigger: normalizedTrigger, response: normalizedResponse };
        } catch (error) {
            console.error('Error adding command:', error);
            return { success: false, error: 'Database error while adding command.' };
        }
    }

    async removeCommand(guildId, trigger) {
        try {
            const normalizedTrigger = this.normalizeTrigger(trigger);
            const result = await db.run('DELETE FROM custom_commands WHERE guild_id = ? AND trigger = ?', [guildId, normalizedTrigger]);
            security.customCommandsCache.delete(guildId);
            return { success: result.changes > 0, trigger: normalizedTrigger };
        } catch (error) {
            console.error('Error removing command:', error);
            return { success: false, error: 'Database error while removing command.' };
        }
    }

    async editCommand(guildId, trigger, response, editorId) {
        try {
            const normalizedTrigger = this.normalizeTrigger(trigger);
            const normalizedResponse = String(response || '').trim();

            if (!normalizedTrigger || !normalizedResponse) {
                return { success: false, error: 'Trigger and response are required.' };
            }

            if (normalizedResponse.length > 4000) {
                return { success: false, error: 'Response must be 4000 characters or fewer.' };
            }

            const result = await db.run(
                'UPDATE custom_commands SET response = ?, creator_id = ? WHERE guild_id = ? AND trigger = ?',
                [normalizedResponse, editorId, guildId, normalizedTrigger]
            );

            security.customCommandsCache.delete(guildId);
            return { success: result.changes > 0, trigger: normalizedTrigger, response: normalizedResponse };
        } catch (error) {
            console.error('Error editing command:', error);
            return { success: false, error: 'Database error while editing command.' };
        }
    }

    async incrementUses(guildId, trigger) {
        try {
            const normalizedTrigger = this.normalizeTrigger(trigger);
            await db.run('UPDATE custom_commands SET uses = uses + 1 WHERE guild_id = ? AND trigger = ?', [guildId, normalizedTrigger]);

            const cachedCommands = security.customCommandsCache.get(guildId);
            const cachedCommand = cachedCommands?.get(normalizedTrigger);
            if (cachedCommand) {
                cachedCommand.uses = (cachedCommand.uses || 0) + 1;
            }
        } catch (error) {
            console.error('Error incrementing command uses:', error);
        }
    }

    async findMatchingCommand(message) {
        const commands = await this.getCommands(message.guild.id);
        if (commands.size === 0) return null;

        const contentVariants = this.getMessageContentVariants(message);

        for (const [trigger, command] of commands.entries()) {
            const triggerVariants = this.getTriggerVariants(trigger).sort((a, b) => b.length - a.length);

            for (const content of contentVariants) {
                for (const variant of triggerVariants) {
                    if (content === variant || content.startsWith(`${variant} `)) {
                        const args = content === variant ? '' : content.slice(variant.length).trim();
                        return { trigger, command, args };
                    }
                }
            }
        }

        return null;
    }

    formatResponse(response, message, args = '') {
        const now = new Date();
        const replacements = {
            user: message.author.toString(),
            mention: message.author.toString(),
            username: message.author.username,
            tag: message.author.tag,
            author: message.author.username,
            userId: message.author.id,
            server: message.guild.name,
            serverId: message.guild.id,
            channel: message.channel.toString(),
            channelName: message.channel.name || 'unknown',
            memberCount: message.guild.memberCount?.toString() || '0',
            args,
            newline: '\n',
            date: now.toLocaleDateString('en-US'),
            time: now.toLocaleTimeString('en-US')
        };

        let output = String(response || '');
        for (const [key, value] of Object.entries(replacements)) {
            output = output.split(`{${key}}`).join(value);
        }

        // Sanitize to ensure bot never mentions everyone/here from custom command responses
        output = sanitizeMentions(output);

        return output.trim();
    }

    splitMessage(content, maxLength = 2000) {
        const text = String(content || '').trim();
        if (!text) return [];

        const chunks = [];
        let remaining = text;

        while (remaining.length > maxLength) {
            let splitAt = remaining.lastIndexOf('\n', maxLength);
            if (splitAt < maxLength * 0.5) {
                splitAt = remaining.lastIndexOf(' ', maxLength);
            }
            if (splitAt < maxLength * 0.5) {
                splitAt = maxLength;
            }

            chunks.push(remaining.slice(0, splitAt).trim());
            remaining = remaining.slice(splitAt).trim();
        }

        if (remaining) chunks.push(remaining);
        return chunks;
    }

    async executeMessage(message) {
        try {
            if (!message.guild || !message.content?.trim()) {
                return { executed: false };
            }

            const match = await this.findMatchingCommand(message);
            if (!match) {
                return { executed: false };
            }

            const response = this.formatResponse(match.command.response, message, match.args);
            const chunks = this.splitMessage(response);

            if (chunks.length === 0) {
                return { executed: true, sent: false, error: 'Custom command response is empty after formatting.' };
            }

            await message.reply({
                content: chunks[0],
                allowedMentions: this.getAllowedMentions(message)
            });

            for (const chunk of chunks.slice(1)) {
                await message.channel.send({
                    content: chunk,
                    allowedMentions: this.getAllowedMentions(message)
                });
            }

            await this.incrementUses(message.guild.id, match.trigger);
            return { executed: true, sent: true, trigger: match.trigger };
        } catch (error) {
            console.error('Error executing custom command:', error);
            return { executed: true, sent: false, error: error.message };
        }
    }
}

const customCommands = new CustomCommandsManager();

// =======================
// GIVEAWAY SYSTEM
// =======================
class GiveawayManager {
    async startGiveaway(interaction, prize, duration, winners = 1, channel = null) {
        try {
            const ms = parseDuration(duration);
            if (ms === 0 || ms > 2419200000) { // Max 28 days
                return { success: false, error: 'Invalid duration. Use format like 1h, 1d (max 28 days).' };
            }
            
            if (winners < 1 || winners > 25) {
                return { success: false, error: 'Winners must be between 1 and 25.' };
            }
            
            const targetChannel = channel || interaction.channel;
            const endTime = new Date(Date.now() + ms);
            
            const embed = new EmbedBuilder()
                .setTitle('🎉 **GIVEAWAY** 🎉')
                .setDescription(`**Prize:** ${prize}\n**Winners:** ${winners}\n**Ends:** <t:${Math.floor(endTime.getTime() / 1000)}:R> (<t:${Math.floor(endTime.getTime() / 1000)}:F>)`)
                .addFields(
                    { name: 'Hosted by', value: interaction.user.toString(), inline: true },
                    { name: 'Entries', value: '0', inline: true }
                )
                .setColor(COLORS.SUCCESS)
                .setFooter({ text: 'Click the button below to enter!', iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();
            
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('giveaway_enter')
                    .setLabel('Enter Giveaway')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('🎉')
            );
            
            const message = await targetChannel.send({ embeds: [embed], components: [row] });
            
            await db.run(
                'INSERT INTO giveaways (message_id, guild_id, channel_id, prize, end_time, winners, host_id, entrants_count, ended) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [message.id, interaction.guild.id, targetChannel.id, prize, endTime.toISOString(), winners, interaction.user.id, 0, 0]
            );
            
            security.giveawayEntrants.set(message.id, new Set());
            
            // Schedule end
            setTimeout(async () => {
                await this.endGiveaway(interaction.guild.id, message.id);
            }, ms);
            
            return { success: true, messageId: message.id };
        } catch (error) {
            console.error('Error starting giveaway:', error);
            return { success: false, error: error.message };
        }
    }

    async endGiveaway(guildId, messageId) {
        try {
            const giveaway = await db.get('SELECT * FROM giveaways WHERE message_id = ? AND ended = 0', [messageId]);
            if (!giveaway) return;
            
            const guild = client.guilds.cache.get(guildId);
            if (!guild) return;
            
            const channel = guild.channels.cache.get(giveaway.channel_id);
            if (!channel) return;
            
            let message;
            try {
                message = await channel.messages.fetch(messageId);
            } catch {
                await db.run('UPDATE giveaways SET ended = 1 WHERE message_id = ?', [messageId]);
                return;
            }
            
            // Get entrants
            const entrants = await db.all('SELECT user_id FROM giveaway_entrants WHERE message_id = ?', [messageId]);
            const entrantIds = entrants.map(e => e.user_id);
            
            // Select winners
            const winners = [];
            if (entrantIds.length > 0) {
                for (let i = 0; i < Math.min(giveaway.winners, entrantIds.length); i++) {
                    const randomIndex = Math.floor(Math.random() * entrantIds.length);
                    winners.push(entrantIds.splice(randomIndex, 1)[0]);
                }
            }
            
            // Update embed
            const winnerText = winners.length > 0 
                ? winners.map(id => `<@${id}>`).join(', ')
                : 'No winners (no entries)';
            
            const endEmbed = new EmbedBuilder()
                .setTitle('🎉 **GIVEAWAY ENDED** 🎉')
                .setDescription(`**Prize:** ${giveaway.prize}\n**Winners:** ${winnerText}`)
                .addFields(
                    { name: 'Hosted by', value: `<@${giveaway.host_id}>`, inline: true },
                    { name: 'Total Entries', value: entrants.length.toString(), inline: true }
                )
                .setColor(COLORS.WARNING)
                .setFooter({ text: 'Giveaway Ended', iconURL: guild.iconURL() })
                .setTimestamp();
            
            await message.edit({ embeds: [endEmbed], components: [] });
            
            // Announce winners
            if (winners.length > 0) {
                const winnerAnnouncement = `🎉 **Congratulations ${winnerText}!** You won **${giveaway.prize}**!\nPlease contact <@${giveaway.host_id}> to claim your prize.`;
                await channel.send(winnerAnnouncement);
                
                // DM winners
                for (const winnerId of winners) {
                    try {
                        const user = await client.users.fetch(winnerId);
                        await user.send(`🎉 **Congratulations!** You won **${giveaway.prize}** in **${guild.name}**!\n\nGiveaway: ${message.url}`);
                    } catch {}
                }
            } else {
                await channel.send('😔 **No winners** - There were no entries in this giveaway.');
            }
            
            // Mark as ended
            await db.run('UPDATE giveaways SET ended = 1 WHERE message_id = ?', [messageId]);
            security.giveawayEntrants.delete(messageId);
            
        } catch (error) {
            console.error('Error ending giveaway:', error);
        }
    }

    async rerollGiveaway(guildId, messageId) {
        try {
            const giveaway = await db.get('SELECT * FROM giveaways WHERE message_id = ?', [messageId]);
            if (!giveaway) return { success: false, error: 'Giveaway not found.' };
            
            const guild = client.guilds.cache.get(guildId);
            if (!guild) return { success: false, error: 'Guild not found.' };
            
            const channel = guild.channels.cache.get(giveaway.channel_id);
            if (!channel) return { success: false, error: 'Channel not found.' };
            
            // Get all entrants
            const entrants = await db.all('SELECT user_id FROM giveaway_entrants WHERE message_id = ?', [messageId]);
            const entrantIds = entrants.map(e => e.user_id);
            
            if (entrantIds.length === 0) {
                return { success: false, error: 'No entrants to reroll.' };
            }
            
            // Select new winners
            const winners = [];
            const availableEntrants = [...entrantIds];
            
            for (let i = 0; i < Math.min(giveaway.winners, availableEntrants.length); i++) {
                const randomIndex = Math.floor(Math.random() * availableEntrants.length);
                winners.push(availableEntrants.splice(randomIndex, 1)[0]);
            }
            
            const winnerText = winners.map(id => `<@${id}>`).join(', ');
            
            // Send reroll announcement
            await channel.send(`🎲 **GIVEAWAY REROLLED!**\nNew winners: ${winnerText}\nPrize: **${giveaway.prize}**\nContact <@${giveaway.host_id}> to claim!`);
            
            return { success: true, winners: winnerText };
        } catch (error) {
            console.error('Error rerolling giveaway:', error);
            return { success: false, error: error.message };
        }
    }
}

const giveawayManager = new GiveawayManager();

// =======================
// TICKET SYSTEM
// =======================
class TicketManager {
    constructor(client) {
        this.client = client;
        this.activeTickets = new Map(); // channelId -> ticketData
    }

    async getConfig(guildId) {
        try {
            let config = await db.get('SELECT * FROM ticket_config WHERE guild_id = ?', [guildId]);
            if (!config) {
                await db.run(
                    'INSERT INTO ticket_config (guild_id, enabled) VALUES (?, ?)',
                    [guildId, 1]
                );
                config = await db.get('SELECT * FROM ticket_config WHERE guild_id = ?', [guildId]);
            }
            return config;
        } catch (error) {
            console.error('Error getting ticket config:', error);
            return null;
        }
    }

    async createTicket(guild, user, ticketType = 'general', interaction = null) {
        try {
            const config = await this.getConfig(guild.id);
            if (!config || !config.enabled) {
                return { success: false, error: 'Ticket system is disabled' };
            }

            // Check if user already has open tickets
            const existingTickets = await db.all(
                'SELECT * FROM tickets WHERE guild_id = ? AND user_id = ? AND status = ?',
                [guild.id, user.id, 'open']
            );

            if (existingTickets.length >= config.max_tickets) {
                return { success: false, error: `You already have ${config.max_tickets} open ticket(s)` };
            }

            // Get next ticket number
            const lastTicket = await db.get(
                'SELECT MAX(ticket_number) as max_num FROM tickets WHERE guild_id = ?',
                [guild.id]
            );
            const ticketNumber = (lastTicket?.max_num || 0) + 1;

            // Get ticket type config
            const typeConfig = await db.get(
                'SELECT * FROM ticket_types WHERE guild_id = ? AND type_name = ?',
                [guild.id, ticketType]
            );

            // Create ticket channel
            const category = config.category_id ? guild.channels.cache.get(config.category_id) : null;
            
            // Format ticket type for channel name (lowercase, replace spaces with hyphens)
            const formattedType = ticketType.toLowerCase().replace(/\s+/g, '-');
            
            // Create channel name with category prefix
            let channelName = config.ticket_name_format
                .replace('{number}', ticketNumber.toString().padStart(4, '0'))
                .replace('{user}', user.username.toLowerCase().replace(/[^a-z0-9]/g, ''))
                .replace('{type}', formattedType);
            
            // If format doesn't include type, add it as prefix
            if (!config.ticket_name_format.includes('{type}')) {
                channelName = `${formattedType}-${channelName}`;
            }
            
            // Ensure channel name is valid (Discord limits)
            channelName = channelName.toLowerCase().substring(0, 100);

            const channel = await guild.channels.create({
                name: channelName,
                type: ChannelType.GuildText,
                parent: category?.id,
                topic: `Ticket #${ticketNumber} | User: ${user.tag} | Type: ${ticketType}`,
                permissionOverwrites: [
                    {
                        id: guild.id,
                        deny: [PermissionFlagsBits.ViewChannel]
                    },
                    {
                        id: user.id,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles,
                            PermissionFlagsBits.EmbedLinks
                        ]
                    },
                    {
                        id: this.client.user.id,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ManageChannels,
                            PermissionFlagsBits.ManageMessages
                        ]
                    }
                ]
            });

            // Add support role permissions
            const supportRoleId = typeConfig?.support_role_id || config.support_role_id;
            if (supportRoleId) {
                await channel.permissionOverwrites.create(supportRoleId, {
                    ViewChannel: true,
                    SendMessages: true,
                    ReadMessageHistory: true,
                    AttachFiles: true,
                    EmbedLinks: true
                });
            }

            // Insert ticket into database
            const result = await db.run(
                'INSERT INTO tickets (guild_id, channel_id, user_id, ticket_number, ticket_type, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [guild.id, channel.id, user.id, ticketNumber, ticketType, 'open', new Date().toISOString()]
            );

            const ticketId = result.lastID;

            // Update stats
            await db.run(
                'INSERT INTO ticket_stats (guild_id, user_id, tickets_created) VALUES (?, ?, 1) ON CONFLICT(guild_id, user_id) DO UPDATE SET tickets_created = tickets_created + 1',
                [guild.id, user.id]
            );

            // Create welcome embed
            const embed = new EmbedBuilder()
                .setTitle(`🎫 Ticket #${ticketNumber}`)
                .setDescription(config.welcome_message || 'Thank you for contacting support!')
                .setColor(COLORS.PRIMARY)
                .addFields(
                    { name: 'Created By', value: `${user}`, inline: true },
                    { name: 'Category', value: `${typeConfig?.emoji || '🎫'} ${ticketType}`, inline: true },
                    { name: 'Status', value: '🟢 Open', inline: true }
                )
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK || 'Ticket System' });

            if (typeConfig?.description) {
                embed.addFields({ name: '📋 Category Information', value: typeConfig.description });
            }

            // Create control buttons
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`ticket_close_${ticketId}`)
                        .setLabel('Close Ticket')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('🔒'),
                    new ButtonBuilder()
                        .setCustomId(`ticket_claim_${ticketId}`)
                        .setLabel('Claim')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('✋'),
                    new ButtonBuilder()
                        .setCustomId(`ticket_adduser_${ticketId}`)
                        .setLabel('Add User')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('➕'),
                    new ButtonBuilder()
                        .setCustomId(`ticket_transcript_${ticketId}`)
                        .setLabel('Transcript')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('📄')
                );

            await channel.send({
                content: `${user} Welcome to your ticket!`,
                embeds: [embed],
                components: [row]
            });

            // Log ticket creation
            if (config.log_channel_id) {
                const logChannel = guild.channels.cache.get(config.log_channel_id);
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setTitle('🎫 Ticket Created')
                        .setColor(COLORS.SUCCESS)
                        .addFields(
                            { name: 'Ticket', value: `#${ticketNumber}`, inline: true },
                            { name: 'User', value: `${user.tag}`, inline: true },
                            { name: 'Category', value: `${typeConfig?.emoji || '🎫'} ${ticketType}`, inline: true },
                            { name: 'Channel', value: `${channel}`, inline: false }
                        )
                        .setTimestamp();
                    await logChannel.send({ embeds: [logEmbed] });
                }
            }

            // Store in active tickets
            this.activeTickets.set(channel.id, {
                ticketId,
                ticketNumber,
                userId: user.id,
                type: ticketType,
                createdAt: new Date()
            });

            // Update ticket list
            await this.updateTicketList(guild.id);

            return { success: true, channel, ticketId, ticketNumber };
        } catch (error) {
            console.error('Error creating ticket:', error);
            return { success: false, error: error.message };
        }
    }

    async closeTicket(ticketId, closedBy, reason = 'No reason provided', rating = null) {
        try {
            const ticket = await db.get('SELECT * FROM tickets WHERE ticket_id = ?', [ticketId]);
            if (!ticket) return { success: false, error: 'Ticket not found' };

            const guild = this.client.guilds.cache.get(ticket.guild_id);
            if (!guild) return { success: false, error: 'Guild not found' };

            const channel = guild.channels.cache.get(ticket.channel_id);
            const config = await this.getConfig(guild.id);

            // Generate transcript if enabled
            let transcriptUrl = null;
            if (config.transcript_enabled && channel) {
                transcriptUrl = await this.generateTranscript(ticketId, channel);
            }

            // Update ticket in database
            await db.run(
                'UPDATE tickets SET status = ?, closed_at = ?, close_reason = ?, rating = ? WHERE ticket_id = ?',
                ['closed', new Date().toISOString(), reason, rating, ticketId]
            );

            // Update stats
            await db.run(
                'INSERT INTO ticket_stats (guild_id, user_id, tickets_closed) VALUES (?, ?, 1) ON CONFLICT(guild_id, user_id) DO UPDATE SET tickets_closed = tickets_closed + 1',
                [guild.id, closedBy.id]
            );

            if (rating) {
                await db.run(
                    'UPDATE ticket_stats SET total_ratings = total_ratings + 1, average_rating = ((average_rating * total_ratings) + ?) / (total_ratings + 1) WHERE guild_id = ? AND user_id = ?',
                    [rating, guild.id, ticket.user_id]
                );
            }

            // Send closing message
            if (channel) {
                const closeEmbed = new EmbedBuilder()
                    .setTitle('🔒 Ticket Closed')
                    .setColor(COLORS.ERROR)
                    .addFields(
                        { name: 'Closed By', value: `${closedBy.tag}`, inline: true },
                        { name: 'Reason', value: reason, inline: true }
                    )
                    .setTimestamp();

                if (transcriptUrl) {
                    closeEmbed.addFields({ name: 'Transcript', value: `[View Transcript](${transcriptUrl})` });
                }

                await channel.send({ embeds: [closeEmbed] });

                // Delete channel after delay
                setTimeout(async () => {
                    try {
                        await channel.delete('Ticket closed');
                    } catch (e) {
                        console.error('Error deleting ticket channel:', e);
                    }
                }, 5000);
            }

            // Log ticket closure
            if (config.log_channel_id) {
                const logChannel = guild.channels.cache.get(config.log_channel_id);
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setTitle('🔒 Ticket Closed')
                        .setColor(COLORS.ERROR)
                        .addFields(
                            { name: 'Ticket', value: `#${ticket.ticket_number}`, inline: true },
                            { name: 'User', value: `<@${ticket.user_id}>`, inline: true },
                            { name: 'Closed By', value: `${closedBy.tag}`, inline: true },
                            { name: 'Reason', value: reason, inline: false }
                        )
                        .setTimestamp();

                    if (transcriptUrl) {
                        logEmbed.addFields({ name: 'Transcript', value: `[View Transcript](${transcriptUrl})` });
                    }

                    if (rating) {
                        logEmbed.addFields({ name: 'Rating', value: '⭐'.repeat(rating) });
                    }

                    await logChannel.send({ embeds: [logEmbed] });
                }
            }

            // Remove from active tickets
            this.activeTickets.delete(ticket.channel_id);

            // Update ticket list
            await this.updateTicketList(guild.id);

            return { success: true, transcriptUrl };
        } catch (error) {
            console.error('Error closing ticket:', error);
            return { success: false, error: error.message };
        }
    }

    async claimTicket(ticketId, claimer) {
        try {
            await db.run(
                'UPDATE tickets SET claimed_by = ? WHERE ticket_id = ?',
                [claimer.id, ticketId]
            );
    
            return { success: true };
        } catch (error) {
            console.error('Error claiming ticket:', error);
            return { success: false, error: error.message };
        }
    }

    async addUserToTicket(ticketId, user, addedBy) {
        try {
            const ticket = await db.get('SELECT * FROM tickets WHERE ticket_id = ?', [ticketId]);
            const guild = this.client.guilds.cache.get(ticket.guild_id);
            const channel = guild.channels.cache.get(ticket.channel_id);

            if (channel) {
                await channel.permissionOverwrites.create(user.id, {
                    ViewChannel: true,
                    SendMessages: true,
                    ReadMessageHistory: true,
                    AttachFiles: true,
                    EmbedLinks: true
                });

                await db.run(
                    'INSERT INTO ticket_participants (ticket_id, user_id, added_by, added_at) VALUES (?, ?, ?, ?)',
                    [ticketId, user.id, addedBy.id, new Date().toISOString()]
                );

                const embed = new EmbedBuilder()
                    .setDescription(`➕ ${user} has been added to the ticket by ${addedBy}`)
                    .setColor(COLORS.INFO)
                    .setTimestamp();

                await channel.send({ embeds: [embed] });
            }

            return { success: true };
        } catch (error) {
            console.error('Error adding user to ticket:', error);
            return { success: false, error: error.message };
        }
    }

    async removeUserFromTicket(ticketId, user, removedBy) {
        try {
            const ticket = await db.get('SELECT * FROM tickets WHERE ticket_id = ?', [ticketId]);
            const guild = this.client.guilds.cache.get(ticket.guild_id);
            const channel = guild.channels.cache.get(ticket.channel_id);

            if (channel) {
                await channel.permissionOverwrites.delete(user.id);

                await db.run(
                    'DELETE FROM ticket_participants WHERE ticket_id = ? AND user_id = ?',
                    [ticketId, user.id]
                );

                const embed = new EmbedBuilder()
                    .setDescription(`➖ ${user} has been removed from the ticket by ${removedBy}`)
                    .setColor(COLORS.WARNING)
                    .setTimestamp();

                await channel.send({ embeds: [embed] });
            }

            return { success: true };
        } catch (error) {
            console.error('Error removing user from ticket:', error);
            return { success: false, error: error.message };
        }
    }

    async generateTranscript(ticketId, channel) {
        try {
            // Fetch all messages
            const messages = [];
            let lastId;

            while (true) {
                const options = { limit: 100 };
                if (lastId) options.before = lastId;

                const batch = await channel.messages.fetch(options);
                messages.push(...batch.values());

                if (batch.size < 100) break;
                lastId = batch.last().id;
            }

            messages.reverse();

            // Store messages in database
            for (const msg of messages) {
                const attachments = msg.attachments.size > 0 
                    ? JSON.stringify(msg.attachments.map(a => ({ name: a.name, url: a.url })))
                    : null;

                await db.run(
                    'INSERT INTO ticket_messages (ticket_id, user_id, username, message, timestamp, attachments) VALUES (?, ?, ?, ?, ?, ?)',
                    [ticketId, msg.author.id, msg.author.tag, msg.content, msg.createdAt.toISOString(), attachments]
                );
            }

            // Generate transcript URL (you can implement file upload to a service here)
            const transcriptUrl = `transcript_${ticketId}.txt`;
            
            await db.run(
                'INSERT INTO ticket_transcripts (ticket_id, guild_id, transcript_url, created_at) VALUES (?, ?, ?, ?)',
                [ticketId, channel.guild.id, transcriptUrl, new Date().toISOString()]
            );

            return transcriptUrl;
        } catch (error) {
            console.error('Error generating transcript:', error);
            return null;
        }
    }

    async createPanel(guild, channel, options) {
        try {
            const embed = new EmbedBuilder()
                .setTitle(options.title || '🎫 Support Tickets')
                .setDescription(options.description || 'Click the button below to create a support ticket')
                .setColor(options.color || COLORS.PRIMARY)
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK || 'Ticket System' });

            const button = new ButtonBuilder()
                .setCustomId(`ticket_create_${options.ticketType || 'general'}`)
                .setLabel(options.buttonLabel || 'Create Ticket')
                .setStyle(ButtonStyle.Primary)
                .setEmoji(options.emoji || '🎫');

            const row = new ActionRowBuilder().addComponents(button);

            const message = await channel.send({ embeds: [embed], components: [row] });

            await db.run(
                'INSERT INTO ticket_panels (guild_id, channel_id, message_id, title, description, color, emoji, button_label, ticket_type, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [guild.id, channel.id, message.id, options.title, options.description, options.color, options.emoji, options.buttonLabel, options.ticketType || 'general', new Date().toISOString()]
            );

            return { success: true, message };
        } catch (error) {
            console.error('Error creating ticket panel:', error);
            return { success: false, error: error.message };
        }
    }

    async getTicketStats(guildId, userId = null) {
        try {
            if (userId) {
                return await db.get(
                    'SELECT * FROM ticket_stats WHERE guild_id = ? AND user_id = ?',
                    [guildId, userId]
                );
            } else {
                return await db.all(
                    'SELECT * FROM ticket_stats WHERE guild_id = ? ORDER BY tickets_created DESC LIMIT 10',
                    [guildId]
                );
            }
        } catch (error) {
            console.error('Error getting ticket stats:', error);
            return null;
        }
    }

    async updateTicketList(guildId) {
        try {
            const listConfig = await db.get('SELECT * FROM ticket_list_channel WHERE guild_id = ?', [guildId]);
            if (!listConfig) return;

            const guild = this.client.guilds.cache.get(guildId);
            if (!guild) return;

            const channel = guild.channels.cache.get(listConfig.channel_id);
            if (!channel) return;

            // Validate channel is text-based
            if (!channel.isTextBased() || channel.type === ChannelType.GuildVoice || channel.type === ChannelType.GuildCategory) {
                console.error(`Ticket list channel ${channel.id} is not a text channel (type: ${channel.type})`);
                return;
            }

            // Get all open tickets grouped by type
            const tickets = await db.all(
                'SELECT * FROM tickets WHERE guild_id = ? AND status = ? ORDER BY ticket_type, ticket_number',
                [guildId, 'open']
            );

            // Group tickets by type
            const ticketsByType = {};
            for (const ticket of tickets) {
                const type = ticket.ticket_type || 'general';
                if (!ticketsByType[type]) {
                    ticketsByType[type] = [];
                }
                ticketsByType[type].push(ticket);
            }

            // Create embed
            const embed = new EmbedBuilder()
                .setTitle('🎫 Open Tickets List')
                .setDescription(`**Total Open Tickets:** ${tickets.length}`)
                .setColor(COLORS.PRIMARY)
                .setTimestamp()
                .setFooter({ text: `Last Updated` });

            // Add fields for each category
            if (tickets.length === 0) {
                embed.addFields({ name: '📭 No Open Tickets', value: 'All tickets are closed!', inline: false });
            } else {
                for (const [type, typeTickets] of Object.entries(ticketsByType)) {
                    // Get type emoji
                    const typeData = await db.get('SELECT emoji FROM ticket_types WHERE guild_id = ? AND type_name = ?', [guildId, type]);
                    const emoji = typeData?.emoji || '🎫';

                    let ticketList = '';
                    for (const ticket of typeTickets.slice(0, 10)) { // Limit to 10 per category
                        const ticketChannel = guild.channels.cache.get(ticket.channel_id);
                        const user = await guild.members.fetch(ticket.user_id).catch(() => null);
                        const claimedBy = ticket.claimed_by ? `👤 <@${ticket.claimed_by}>` : '⏳ Unclaimed';
                        
                        if (ticketChannel) {
                            ticketList += `${ticketChannel} - ${user ? user.user.tag : 'Unknown'} - ${claimedBy}\n`;
                        }
                    }

                    if (typeTickets.length > 10) {
                        ticketList += `*...and ${typeTickets.length - 10} more*\n`;
                    }

                    embed.addFields({
                        name: `${emoji} ${type.toUpperCase()} (${typeTickets.length})`,
                        value: ticketList || 'No tickets',
                        inline: false
                    });
                }
            }

            // Update or create message
            try {
                if (listConfig.message_id) {
                    const message = await channel.messages.fetch(listConfig.message_id).catch(() => null);
                    if (message) {
                        await message.edit({ embeds: [embed] });
                    } else {
                        const newMessage = await channel.send({ embeds: [embed] });
                        await db.run(
                            'UPDATE ticket_list_channel SET message_id = ?, last_updated = ? WHERE guild_id = ?',
                            [newMessage.id, new Date().toISOString(), guildId]
                        );
                    }
                } else {
                    const newMessage = await channel.send({ embeds: [embed] });
                    await db.run(
                        'UPDATE ticket_list_channel SET message_id = ?, last_updated = ? WHERE guild_id = ?',
                        [newMessage.id, new Date().toISOString(), guildId]
                    );
                }
            } catch (error) {
                console.error('Error updating ticket list message:', error);
            }

            return { success: true };
        } catch (error) {
            console.error('Error updating ticket list:', error);
            return { success: false, error: error.message };
        }
    }
}

const ticketManager = new TicketManager(client);

// =======================
// UTILITY FUNCTIONS
// =======================
function parseDuration(duration) {
    const regex = /(\d+)([smhdw])/g;
    let ms = 0;
    let match;
    
    while ((match = regex.exec(duration)) !== null) {
        const val = parseInt(match[1]);
        switch (match[2]) {
            case 's': ms += val * 1000; break;
            case 'm': ms += val * 60000; break;
            case 'h': ms += val * 3600000; break;
            case 'd': ms += val * 86400000; break;
            case 'w': ms += val * 604800000; break;
        }
    }
    return ms;
}

async function logModeration(guildId, action, userId, moderatorId, reason) {
    try {
        await db.run(
            'INSERT INTO moderation_logs (guild_id, action, user_id, moderator_id, reason, timestamp) VALUES (?, ?, ?, ?, ?, ?)',
            [guildId, action, userId, moderatorId, reason, new Date().toISOString()]
        );
    } catch (error) {
        console.error('Error logging moderation:', error);
    }
}

async function addWarning(guildId, userId, reason, moderatorId) {
    try {
        const warnings = await db.all('SELECT warning_id FROM warnings WHERE guild_id = ? AND user_id = ?', [guildId, userId]);
        const warningId = warnings.length + 1;
        
        await db.run(
            'INSERT INTO warnings (guild_id, user_id, warning_id, reason, moderator_id, timestamp) VALUES (?, ?, ?, ?, ?, ?)',
            [guildId, userId, warningId, reason, moderatorId, new Date().toISOString()]
        );
        
        return warningId;
    } catch (error) {
        console.error('Error adding warning:', error);
        return 0;
    }
}

async function getWarnings(guildId, userId) {
    try {
        return await db.all('SELECT * FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY warning_id DESC', [guildId, userId]);
    } catch (error) {
        console.error('Error getting warnings:', error);
        return [];
    }
}

async function clearWarnings(guildId, userId) {
    try {
        await db.run('DELETE FROM warnings WHERE guild_id = ? AND user_id = ?', [guildId, userId]);
        return true;
    } catch (error) {
        console.error('Error clearing warnings:', error);
        return false;
    }
}

// =======================
// STATUS MONITOR SYSTEM
// =======================
class StatusMonitor {
    constructor() {
        this.monitoring = new Map();
        this.client = null;
    }

    setClient(clientInstance) {
        this.client = clientInstance;
    }

    async checkStatusMonitors() {
        try {
            const monitors = await db.all('SELECT * FROM status_monitors');
            
            for (const monitor of monitors) {
                await this.checkSingleMonitor(monitor);
            }
        } catch (error) {
            console.error('Error checking status monitors:', error);
        }
    }

    async checkSingleMonitor(monitor) {
        try {
            const guild = client.guilds.cache.get(monitor.guild_id);
            if (!guild) return;
            
            const channel = guild.channels.cache.get(monitor.channel_id);
            if (!channel || !channel.isTextBased()) return;
            
            const startTime = Date.now();
            let status = 'offline';
            let statusEmoji = '🔴';
            let color = COLORS.ERROR;
            let errorMsg = '';
            let responseTime = 0;
            let statusCode = 0;
            
            try {
                const response = await axios.get(monitor.url, { 
                    timeout: 10000,
                    validateStatus: () => true // Accept any status code
                });
                
                responseTime = Date.now() - startTime;
                statusCode = response.status;
                
                if (response.status >= 200 && response.status < 300) {
                    status = 'online';
                    statusEmoji = '🟢';
                    color = COLORS.SUCCESS;
                } else if (response.status >= 300 && response.status < 400) {
                    status = 'redirect';
                    statusEmoji = '🟡';
                    color = COLORS.WARNING;
                    errorMsg = `Redirect (${response.status})`;
                } else if (response.status >= 400 && response.status < 500) {
                    status = 'client_error';
                    statusEmoji = '🟠';
                    color = COLORS.WARNING;
                    errorMsg = `Client Error (${response.status})`;
                } else if (response.status >= 500) {
                    status = 'server_error';
                    statusEmoji = '🔴';
                    color = COLORS.ERROR;
                    errorMsg = `Server Error (${response.status})`;
                }
            } catch (error) {
                responseTime = Date.now() - startTime;
                status = 'offline';
                statusEmoji = '🔴';
                color = COLORS.ERROR;
                errorMsg = error.code || error.message || 'Connection failed';
            }
            
            // Update statistics
            const totalChecks = (monitor.total_checks || 0) + 1;
            const successfulChecks = monitor.successful_checks || 0;
            const failedChecks = monitor.failed_checks || 0;
            const newSuccessful = status === 'online' ? successfulChecks + 1 : successfulChecks;
            const newFailed = status !== 'online' ? failedChecks + 1 : failedChecks;
            
            // Calculate average response time
            const oldAvg = monitor.avg_response_time || 0;
            const newAvg = Math.round((oldAvg * (totalChecks - 1) + responseTime) / totalChecks);
            
            // Calculate uptime percentage
            const uptimePercent = totalChecks > 0 ? ((newSuccessful / totalChecks) * 100).toFixed(2) : 0;
            
            // Save to history
            await db.run(
                'INSERT INTO status_monitor_history (guild_id, url, status, response_time, timestamp, error_message) VALUES (?, ?, ?, ?, ?, ?)',
                [monitor.guild_id, monitor.url, status, responseTime, new Date().toISOString(), errorMsg]
            );
            
            // Clean old history (keep last 100 entries per monitor)
            await db.run(
                `DELETE FROM status_monitor_history WHERE id IN (
                    SELECT id FROM status_monitor_history 
                    WHERE guild_id = ? AND url = ? 
                    ORDER BY timestamp DESC 
                    LIMIT -1 OFFSET 100
                )`,
                [monitor.guild_id, monitor.url]
            );
            
            // Get recent history for graph
            const history = await db.all(
                'SELECT status, response_time, timestamp FROM status_monitor_history WHERE guild_id = ? AND url = ? ORDER BY timestamp DESC LIMIT 10',
                [monitor.guild_id, monitor.url]
            );
            
            // Calculate uptime duration
            const uptimeStart = monitor.uptime_start ? new Date(monitor.uptime_start) : new Date();
            const uptimeDuration = Date.now() - uptimeStart.getTime();
            const uptimeDays = Math.floor(uptimeDuration / (1000 * 60 * 60 * 24));
            const uptimeHours = Math.floor((uptimeDuration % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const uptimeMinutes = Math.floor((uptimeDuration % (1000 * 60 * 60)) / (1000 * 60));
            
            // Create beautiful embed
            const embed = new EmbedBuilder()
                .setTitle(`${statusEmoji} ${monitor.name || monitor.url}`)
                .setColor(monitor.embed_color || color)
                .setTimestamp()
                .setFooter({ text: `Monitor ID: ${monitor.url.substring(0, 30)}... | Auto-updates every ${Math.floor(monitor.check_interval / 60000)} min` });
            
            // Status description
            let description = `**URL:** ${monitor.url}\n`;
            description += `**Status:** ${statusEmoji} ${status.toUpperCase().replace('_', ' ')}`;
            if (errorMsg) description += ` - ${errorMsg}`;
            description += `\n**Status Code:** ${statusCode || 'N/A'}`;
            
            embed.setDescription(description);
            
            // Performance metrics
            const fields = [];
            
            if (monitor.show_response_time) {
                fields.push({
                    name: '⚡ Response Time',
                    value: `Current: **${responseTime}ms**\nAverage: **${newAvg}ms**`,
                    inline: true
                });
            }
            
            if (monitor.show_uptime) {
                const uptimeBar = this.createUptimeBar(parseFloat(uptimePercent));
                fields.push({
                    name: '📊 Uptime',
                    value: `**${uptimePercent}%**\n${uptimeBar}\n${uptimeDays}d ${uptimeHours}h ${uptimeMinutes}m`,
                    inline: true
                });
            }
            
            fields.push({
                name: '📈 Statistics',
                value: `Total: **${totalChecks}**\nSuccess: **${newSuccessful}** ✅\nFailed: **${newFailed}** ❌`,
                inline: true
            });
            
            // History graph
            if (monitor.show_history && history.length > 0) {
                const historyGraph = this.createHistoryGraph(history);
                fields.push({
                    name: '📉 Recent History (Last 10 checks)',
                    value: historyGraph,
                    inline: false
                });
            }
            
            fields.push({
                name: '🕐 Last Check',
                value: `<t:${Math.floor(Date.now() / 1000)}:R>`,
                inline: true
            });
            
            fields.push({
                name: '🔄 Next Check',
                value: `<t:${Math.floor((Date.now() + monitor.check_interval) / 1000)}:R>`,
                inline: true
            });
            
            embed.addFields(fields);
            
            // Send or update message
            let shouldAlert = false;
            if (monitor.last_status && monitor.last_status !== status) {
                shouldAlert = true;
            }
            
            if (monitor.message_id) {
                try {
                    const msg = await channel.messages.fetch(monitor.message_id);
                    await msg.edit({ embeds: [embed] });
                } catch {
                    const newMsg = await channel.send({ embeds: [embed] });
                    await db.run('UPDATE status_monitors SET message_id = ? WHERE guild_id = ? AND url = ?', 
                        [newMsg.id, monitor.guild_id, monitor.url]);
                }
            } else {
                const msg = await channel.send({ embeds: [embed] });
                await db.run('UPDATE status_monitors SET message_id = ? WHERE guild_id = ? AND url = ?', 
                    [msg.id, monitor.guild_id, monitor.url]);
            }
            
            // Send alert if status changed and alerts enabled
            if (shouldAlert && monitor.alert_enabled && status !== 'online') {
                const alertEmbed = new EmbedBuilder()
                    .setTitle('🚨 Status Alert')
                    .setDescription(`**${monitor.name || monitor.url}** is now **${status.toUpperCase().replace('_', ' ')}**!`)
                    .addFields(
                        { name: 'Previous Status', value: monitor.last_status.toUpperCase(), inline: true },
                        { name: 'Current Status', value: status.toUpperCase(), inline: true },
                        { name: 'Error', value: errorMsg || 'None', inline: false }
                    )
                    .setColor(COLORS.ERROR)
                    .setTimestamp();
                
                const alertContent = monitor.alert_role_id ? `<@&${monitor.alert_role_id}>` : null;
                await channel.send({ content: alertContent, embeds: [alertEmbed] });
            }
            
            // Update database
            await db.run(
                `UPDATE status_monitors SET 
                    last_status = ?, 
                    last_check = ?, 
                    total_checks = ?, 
                    successful_checks = ?, 
                    failed_checks = ?,
                    last_response_time = ?,
                    avg_response_time = ?,
                    uptime_start = ?
                WHERE guild_id = ? AND url = ?`,
                [
                    status, 
                    new Date().toISOString(), 
                    totalChecks, 
                    newSuccessful, 
                    newFailed,
                    responseTime,
                    newAvg,
                    monitor.uptime_start || new Date().toISOString(),
                    monitor.guild_id, 
                    monitor.url
                ]
            );
            
        } catch (error) {
            console.error('Error checking single monitor:', error);
        }
    }

    createUptimeBar(percent) {
        const filled = Math.round(percent / 10);
        const empty = 10 - filled;
        return '█'.repeat(filled) + '░'.repeat(empty);
    }

    createHistoryGraph(history) {
        const reversed = history.slice().reverse();
        let graph = '```\n';
        
        for (let i = 0; i < reversed.length; i++) {
            const entry = reversed[i];
            const statusIcon = entry.status === 'online' ? '✓' : '✗';
            const time = new Date(entry.timestamp);
            const timeStr = `${time.getHours().toString().padStart(2, '0')}:${time.getMinutes().toString().padStart(2, '0')}`;
            graph += `${statusIcon} ${timeStr} | ${entry.response_time}ms\n`;
        }
        
        graph += '```';
        return graph;
    }
}

const statusMonitor = new StatusMonitor();

// =======================
// INVITE TRACKING SYSTEM
// =======================
class InviteTracker {
    constructor() {
        this.inviteCache = new Map(); // guild_id -> Map<code, InviteData>
    }

    async cacheInvites(guild) {
        try {
            // Check if bot has permission to manage guild/view invites
            const botMember = await guild.members.fetch(client.user.id).catch(() => null);
            if (!botMember || !botMember.permissions.has('ManageGuild')) {
                // Silently fail - bot doesn't have permission
                return new Map();
            }

            const invites = await guild.invites.fetch().catch(() => new Collection());
            const inviteMap = new Map();
            
            for (const [code, invite] of invites) {
                inviteMap.set(code, {
                    code: invite.code,
                    uses: invite.uses,
                    inviter: invite.inviter
                });
                
                // Store in database
                if (invite.inviter) {
                    await db.run(
                        'INSERT OR REPLACE INTO invite_codes (guild_id, code, inviter_id, uses) VALUES (?, ?, ?, ?)',
                        [guild.id, invite.code, invite.inviter.id, invite.uses]
                    );
                }
            }
            
            this.inviteCache.set(guild.id, inviteMap);
            return inviteMap;
        } catch (error) {
            // Silently fail for permission errors
            if (!error.message.includes('Missing Permissions')) {
                console.error('Error caching invites:', error);
            }
            return new Map();
        }
    }

    async findUsedInvite(guild) {
        try {
            // Check if bot has permission to manage guild/view invites
            const botMember = await guild.members.fetch(client.user.id).catch(() => null);
            if (!botMember || !botMember.permissions.has('ManageGuild')) {
                // Return null silently - bot doesn't have permission
                return null;
            }

            const newInvites = await guild.invites.fetch().catch(() => new Collection());
            const oldInvites = this.inviteCache.get(guild.id) || new Map();
            
            for (const [code, newInvite] of newInvites) {
                const oldInvite = oldInvites.get(code);
                
                if (oldInvite && newInvite.uses > oldInvite.uses) {
                    // Update cache
                    oldInvites.set(code, {
                        code: newInvite.code,
                        uses: newInvite.uses,
                        inviter: newInvite.inviter
                    });
                    
                    return {
                        code: newInvite.code,
                        inviter: newInvite.inviter,
                        uses: newInvite.uses
                    };
                }
            }
            
            // Check for new invites
            for (const [code, newInvite] of newInvites) {
                if (!oldInvites.has(code)) {
                    oldInvites.set(code, {
                        code: newInvite.code,
                        uses: newInvite.uses,
                        inviter: newInvite.inviter
                    });
                }
            }
            
            this.inviteCache.set(guild.id, oldInvites);
            return null;
        } catch (error) {
            // Silently fail for permission errors
            if (!error.message.includes('Missing Permissions')) {
                console.error('Error finding used invite:', error);
            }
            return null;
        }
    }

    async isFakeAccount(member) {
        try {
            const accountAge = Date.now() - member.user.createdTimestamp;
            const minAge = 7 * 24 * 60 * 60 * 1000; // 7 days
            
            // Check if account is too new
            if (accountAge < minAge) {
                return true;
            }
            
            // Check if user has default avatar (suspicious)
            if (!member.user.avatar) {
                const recentJoins = await db.get(
                    'SELECT COUNT(*) as count FROM invites WHERE guild_id = ? AND inviter_id = ? AND joined_at > datetime("now", "-1 hour")',
                    [member.guild.id, member.id]
                );
                
                if (recentJoins && recentJoins.count > 3) {
                    return true;
                }
            }
            
            return false;
        } catch (error) {
            console.error('Error checking fake account:', error);
            return false;
        }
    }

    async trackInvite(member, inviteData) {
        try {
            if (!inviteData || !inviteData.inviter) return;
            
            const isFake = await this.isFakeAccount(member);
            
            // Store invite record
            await db.run(
                'INSERT OR REPLACE INTO invites (guild_id, user_id, inviter_id, invite_code, joined_at, is_fake, is_left) VALUES (?, ?, ?, ?, ?, ?, 0)',
                [member.guild.id, member.id, inviteData.inviter.id, inviteData.code, new Date().toISOString(), isFake ? 1 : 0]
            );
            
            // Update inviter stats
            const stats = await db.get(
                'SELECT * FROM invite_stats WHERE guild_id = ? AND user_id = ?',
                [member.guild.id, inviteData.inviter.id]
            );
            
            if (stats) {
                await db.run(
                    'UPDATE invite_stats SET total_invites = total_invites + 1, valid_invites = valid_invites + ?, fake_invites = fake_invites + ? WHERE guild_id = ? AND user_id = ?',
                    [isFake ? 0 : 1, isFake ? 1 : 0, member.guild.id, inviteData.inviter.id]
                );
            } else {
                await db.run(
                    'INSERT INTO invite_stats (guild_id, user_id, total_invites, valid_invites, fake_invites, left_invites) VALUES (?, ?, 1, ?, ?, 0)',
                    [member.guild.id, inviteData.inviter.id, isFake ? 0 : 1, isFake ? 1 : 0]
                );
            }
            
            // Update invite code uses
            await db.run(
                'UPDATE invite_codes SET uses = ? WHERE guild_id = ? AND code = ?',
                [inviteData.uses, member.guild.id, inviteData.code]
            );
            
        } catch (error) {
            console.error('Error tracking invite:', error);
        }
    }

    async handleMemberLeave(member) {
        try {
            // Find the invite record
            const invite = await db.get(
                'SELECT * FROM invites WHERE guild_id = ? AND user_id = ?',
                [member.guild.id, member.id]
            );
            
            if (!invite) return;
            
            // Mark as left
            await db.run(
                'UPDATE invites SET is_left = 1 WHERE guild_id = ? AND user_id = ?',
                [member.guild.id, member.id]
            );
            
            // Update inviter stats
            if (!invite.is_fake) {
                await db.run(
                    'UPDATE invite_stats SET valid_invites = valid_invites - 1, left_invites = left_invites + 1 WHERE guild_id = ? AND user_id = ?',
                    [member.guild.id, invite.inviter_id]
                );
            }
            
        } catch (error) {
            console.error('Error handling member leave:', error);
        }
    }

    async getInviteStats(guildId, userId) {
        try {
            let stats = await db.get(
                'SELECT * FROM invite_stats WHERE guild_id = ? AND user_id = ?',
                [guildId, userId]
            );
            
            if (!stats) {
                stats = {
                    total_invites: 0,
                    valid_invites: 0,
                    fake_invites: 0,
                    left_invites: 0
                };
            }
            
            return stats;
        } catch (error) {
            console.error('Error getting invite stats:', error);
            return null;
        }
    }

    async getLeaderboard(guildId, limit = 10) {
        try {
            const leaderboard = await db.all(
                'SELECT * FROM invite_stats WHERE guild_id = ? ORDER BY valid_invites DESC LIMIT ?',
                [guildId, limit]
            );
            
            return leaderboard;
        } catch (error) {
            console.error('Error getting leaderboard:', error);
            return [];
        }
    }

    async resetInvites(guildId, userId) {
        try {
            await db.run(
                'UPDATE invite_stats SET total_invites = 0, valid_invites = 0, fake_invites = 0, left_invites = 0 WHERE guild_id = ? AND user_id = ?',
                [guildId, userId]
            );
            
            await db.run(
                'DELETE FROM invites WHERE guild_id = ? AND inviter_id = ?',
                [guildId, userId]
            );
            
            return true;
        } catch (error) {
            console.error('Error resetting invites:', error);
            return false;
        }
    }
}

const inviteTracker = new InviteTracker();

// =======================
// SLASH COMMANDS REGISTRATION
// =======================
const commands = [
    // Super Admin Commands
    new SlashCommandBuilder()
        .setName('superadmin')
        .setDescription('Super Admin management')
        .addSubcommand(sub => sub
            .setName('add')
            .setDescription('Add a super admin')
            .addUserOption(opt => opt.setName('user').setDescription('User to add as super admin').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('remove')
            .setDescription('Remove a super admin')
            .addUserOption(opt => opt.setName('user').setDescription('User to remove from super admins').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('list')
            .setDescription('List all super admins'))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    // Extra Owners
    new SlashCommandBuilder()
        .setName('extraowner')
        .setDescription('Manage extra owners (Owner/Extra Owner only)')
        .addSubcommand(sub => sub
            .setName('add')
            .setDescription('Add an extra owner')
            .addUserOption(opt => opt.setName('user').setDescription('User to add').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('remove')
            .setDescription('Remove an extra owner')
            .addUserOption(opt => opt.setName('user').setDescription('User to remove').setRequired(true)))
        .addSubcommand(sub => sub.setName('list').setDescription('List all extra owners'))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    // Bot Configuration
    new SlashCommandBuilder()
        .setName('botconfig')
        .setDescription('Configure bot settings (Super Admin only)')
        .addSubcommand(sub => sub
            .setName('status')
            .setDescription('Set bot status')
            .addStringOption(opt => opt
                .setName('status')
                .setDescription('Status type')
                .setRequired(true)
                .addChoices(
                    { name: 'Online', value: 'online' },
                    { name: 'Idle', value: 'idle' },
                    { name: 'Do Not Disturb', value: 'dnd' },
                    { name: 'Invisible', value: 'invisible' }
                ))
            .addStringOption(opt => opt
                .setName('type')
                .setDescription('Activity type')
                .setRequired(true)
                .addChoices(
                    { name: 'Playing', value: 'PLAYING' },
                    { name: 'Streaming', value: 'STREAMING' },
                    { name: 'Listening', value: 'LISTENING' },
                    { name: 'Watching', value: 'WATCHING' },
                    { name: 'Competing', value: 'COMPETING' }
                ))
            .addStringOption(opt => opt.setName('activity').setDescription('Activity text').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('watermark')
            .setDescription('Set bot watermark')
            .addStringOption(opt => opt.setName('text').setDescription('Watermark text').setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    // Anti-Nuke Commands
    new SlashCommandBuilder()
        .setName('antinuke')
        .setDescription('Configure anti-nuke system')
        .addSubcommand(sub => sub
            .setName('enable')
            .setDescription('Enable anti-nuke system'))
        .addSubcommand(sub => sub
            .setName('disable')
            .setDescription('Disable anti-nuke system'))
        .addSubcommand(sub => sub
            .setName('config')
            .setDescription('Configure anti-nuke settings')
            .addStringOption(opt => opt
                .setName('punishment')
                .setDescription('Punishment type')
                .setRequired(false)
                .addChoices(
                    { name: 'Ban', value: 'ban' },
                    { name: 'Kick', value: 'kick' },
                    { name: 'Timeout', value: 'timeout' },
                    { name: 'Strip Roles', value: 'strip_roles' }
                ))
            .addChannelOption(opt => opt.setName('log_channel').setDescription('Log channel').setRequired(false))
            .addBooleanOption(opt => opt.setName('auto_revert').setDescription('Auto-revert actions').setRequired(false))
            .addIntegerOption(opt => opt.setName('alert_threshold').setDescription('Actions before alert').setRequired(false).setMinValue(1)))
        .addSubcommand(sub => sub
            .setName('whitelist')
            .setDescription('Manage whitelist')
            .addStringOption(opt => opt
                .setName('action')
                .setDescription('Action to perform')
                .setRequired(true)
                .addChoices(
                    { name: 'Add', value: 'add' },
                    { name: 'Remove', value: 'remove' },
                    { name: 'List', value: 'list' }
                ))
            .addUserOption(opt => opt.setName('user').setDescription('User to whitelist').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('logs')
            .setDescription('View anti-nuke logs')
            .addIntegerOption(opt => opt.setName('limit').setDescription('Number of logs to show').setRequired(false).setMinValue(1).setMaxValue(50)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Anti-Spam Commands
    new SlashCommandBuilder()
        .setName('antispam')
        .setDescription('Configure anti-spam system')
        .addSubcommand(sub => sub
            .setName('enable')
            .setDescription('Enable anti-spam'))
        .addSubcommand(sub => sub
            .setName('disable')
            .setDescription('Disable anti-spam'))
        .addSubcommand(sub => sub
            .setName('config')
            .setDescription('Configure anti-spam settings')
            .addStringOption(opt => opt
                .setName('punishment')
                .setDescription('Punishment type')
                .setRequired(false)
                .addChoices(
                    { name: 'Timeout', value: 'timeout' },
                    { name: 'Kick', value: 'kick' },
                    { name: 'Ban', value: 'ban' }
                ))
            .addIntegerOption(opt => opt.setName('message_threshold').setDescription('Max messages in time window').setRequired(false).setMinValue(2))
            .addIntegerOption(opt => opt.setName('time_window').setDescription('Time window in seconds').setRequired(false).setMinValue(1))
            .addIntegerOption(opt => opt.setName('duplicate_threshold').setDescription('Max duplicate messages').setRequired(false).setMinValue(2))
            .addIntegerOption(opt => opt.setName('mention_threshold').setDescription('Max mentions').setRequired(false).setMinValue(1))
            .addIntegerOption(opt => opt.setName('link_threshold').setDescription('Max links').setRequired(false).setMinValue(1))
            .addBooleanOption(opt => opt.setName('warn_first').setDescription('Warn before punishing').setRequired(false)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Bad Words Filter
    new SlashCommandBuilder()
        .setName('badwords')
        .setDescription('Configure bad words filter')
        .addSubcommand(sub => sub
            .setName('enable')
            .setDescription('Enable bad words filter'))
        .addSubcommand(sub => sub
            .setName('disable')
            .setDescription('Disable bad words filter'))
        .addSubcommand(sub => sub
            .setName('add')
            .setDescription('Add bad words')
            .addStringOption(opt => opt.setName('words').setDescription('Words to add (comma separated)').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('remove')
            .setDescription('Remove bad words')
            .addStringOption(opt => opt.setName('words').setDescription('Words to remove (comma separated)').setRequired(true))
            .addBooleanOption(opt => opt.setName('all').setDescription('Remove all words').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('list')
            .setDescription('List all bad words'))
        .addSubcommand(sub => sub
            .setName('config')
            .setDescription('Configure filter settings')
            .addStringOption(opt => opt
                .setName('action')
                .setDescription('Action to take')
                .setRequired(false)
                .addChoices(
                    { name: 'Delete Message', value: 'delete' },
                    { name: 'Warn User', value: 'warn' },
                    { name: 'Timeout User', value: 'timeout' }
                ))
            .addStringOption(opt => opt.setName('warning_message').setDescription('Custom warning message').setRequired(false)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Welcome/Goodbye Commands
    new SlashCommandBuilder()
        .setName('welcome')
        .setDescription('Configure welcome messages')
        .addSubcommand(sub => sub
            .setName('enable')
            .setDescription('Enable welcome messages'))
        .addSubcommand(sub => sub
            .setName('disable')
            .setDescription('Disable welcome messages'))
        .addSubcommand(sub => sub
            .setName('config')
            .setDescription('Configure welcome settings')
            .addChannelOption(opt => opt.setName('channel').setDescription('Welcome channel').setRequired(true).addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
            .addStringOption(opt => opt.setName('message').setDescription('Message placeholders: {user}, {username}, {tag}, {server}, {memberCount}, {accountAge}').setRequired(false))
            .addStringOption(opt => opt.setName('color').setDescription('Embed color (hex like #57F287)').setRequired(false))
            .addBooleanOption(opt => opt.setName('embed').setDescription('Use embed').setRequired(false))
            .addBooleanOption(opt => opt.setName('ping').setDescription('Ping the user').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('dm')
            .setDescription('Configure welcome DM settings')
            .addBooleanOption(opt => opt.setName('enabled').setDescription('Enable DM messages').setRequired(true))
            .addStringOption(opt => opt.setName('message').setDescription('DM placeholders: {username}, {server}, {memberCount}, {accountAge}').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('image')
            .setDescription('Set welcome image/banner')
            .addStringOption(opt => opt.setName('url').setDescription('Image URL, or type remove to clear').setRequired(false))
            .addStringOption(opt => opt.setName('thumbnail').setDescription('Thumbnail type').setRequired(false).addChoices(
                { name: 'User Avatar', value: 'avatar' },
                { name: 'Server Icon', value: 'server' },
                { name: 'None', value: 'none' }
            )))
        .addSubcommand(sub => sub
            .setName('advanced')
            .setDescription('Advanced welcome settings')
            .addChannelOption(opt => opt.setName('rules_channel').setDescription('Rules channel to mention').setRequired(false).addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
            .addBooleanOption(opt => opt.setName('show_rules').setDescription('Show rules channel').setRequired(false))
            .addBooleanOption(opt => opt.setName('show_invite_info').setDescription('Show who invited the user').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('test')
            .setDescription('Test welcome message'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    new SlashCommandBuilder()
        .setName('goodbye')
        .setDescription('Configure goodbye messages')
        .addSubcommand(sub => sub
            .setName('enable')
            .setDescription('Enable goodbye messages'))
        .addSubcommand(sub => sub
            .setName('disable')
            .setDescription('Disable goodbye messages'))
        .addSubcommand(sub => sub
            .setName('config')
            .setDescription('Configure goodbye settings')
            .addChannelOption(opt => opt.setName('channel').setDescription('Goodbye channel').setRequired(true).addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
            .addStringOption(opt => opt.setName('message').setDescription('Message placeholders: {user}, {tag}, {server}, {memberCount}, {joinedAt}').setRequired(false))
            .addStringOption(opt => opt.setName('color').setDescription('Embed color (hex like #ED4245)').setRequired(false))
            .addBooleanOption(opt => opt.setName('embed').setDescription('Use embed').setRequired(false))
            .addBooleanOption(opt => opt.setName('show_stats').setDescription('Show member statistics').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('image')
            .setDescription('Set goodbye image/banner')
            .addStringOption(opt => opt.setName('url').setDescription('Image URL, or type remove to clear').setRequired(false))
            .addStringOption(opt => opt.setName('thumbnail').setDescription('Thumbnail type').setRequired(false).addChoices(
                { name: 'User Avatar', value: 'avatar' },
                { name: 'Server Icon', value: 'server' },
                { name: 'None', value: 'none' }
            )))
        .addSubcommand(sub => sub
            .setName('test')
            .setDescription('Test goodbye message'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Custom Commands
    new SlashCommandBuilder()
        .setName('customcommand')
        .setDescription('Manage custom commands')
        .addSubcommand(sub => sub
            .setName('add')
            .setDescription('Add a custom command')
            .addStringOption(opt => opt.setName('trigger').setDescription('Command trigger').setRequired(true))
            .addStringOption(opt => opt.setName('response').setDescription('Command response (use {user}, {server}, {args})').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('remove')
            .setDescription('Remove a custom command')
            .addStringOption(opt => opt.setName('trigger').setDescription('Command trigger to remove').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('list')
            .setDescription('List all custom commands'))
        .addSubcommand(sub => sub
            .setName('edit')
            .setDescription('Edit a custom command')
            .addStringOption(opt => opt.setName('trigger').setDescription('Command trigger to edit').setRequired(true))
            .addStringOption(opt => opt.setName('response').setDescription('New response').setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Giveaway Commands
    new SlashCommandBuilder()
        .setName('giveaway')
        .setDescription('Manage giveaways')
        .addSubcommand(sub => sub
            .setName('start')
            .setDescription('Start a new giveaway')
            .addStringOption(opt => opt.setName('prize').setDescription('Giveaway prize').setRequired(true))
            .addStringOption(opt => opt.setName('duration').setDescription('Duration (e.g., 1h, 1d)').setRequired(true))
            .addIntegerOption(opt => opt.setName('winners').setDescription('Number of winners').setRequired(true).setMinValue(1).setMaxValue(25))
            .addChannelOption(opt => opt.setName('channel').setDescription('Channel to post in').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('end')
            .setDescription('End a giveaway early')
            .addStringOption(opt => opt.setName('message_id').setDescription('Giveaway message ID').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('reroll')
            .setDescription('Reroll giveaway winners')
            .addStringOption(opt => opt.setName('message_id').setDescription('Giveaway message ID').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('list')
            .setDescription('List active giveaways'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Status Monitor
    new SlashCommandBuilder()
        .setName('statusmonitor')
        .setDescription('Manage status monitors')
        .addSubcommand(sub => sub
            .setName('add')
            .setDescription('Add a status monitor')
            .addStringOption(opt => opt.setName('url').setDescription('URL to monitor (must start with http:// or https://)').setRequired(true))
            .addChannelOption(opt => opt.setName('channel').setDescription('Channel to post updates').setRequired(true))
            .addStringOption(opt => opt.setName('name').setDescription('Friendly name for this monitor').setRequired(false))
            .addIntegerOption(opt => opt.setName('interval').setDescription('Check interval in minutes (default: 5)').setRequired(false).setMinValue(1).setMaxValue(60)))
        .addSubcommand(sub => sub
            .setName('remove')
            .setDescription('Remove a status monitor')
            .addStringOption(opt => opt.setName('url').setDescription('URL to remove').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('list')
            .setDescription('List all monitors'))
        .addSubcommand(sub => sub
            .setName('config')
            .setDescription('Configure monitor settings')
            .addStringOption(opt => opt.setName('url').setDescription('URL to configure').setRequired(true))
            .addStringOption(opt => opt.setName('color').setDescription('Embed color (hex like #5865F2)').setRequired(false))
            .addRoleOption(opt => opt.setName('alert_role').setDescription('Role to ping on downtime').setRequired(false))
            .addBooleanOption(opt => opt.setName('alerts').setDescription('Enable/disable alerts').setRequired(false))
            .addBooleanOption(opt => opt.setName('show_response_time').setDescription('Show response time').setRequired(false))
            .addBooleanOption(opt => opt.setName('show_uptime').setDescription('Show uptime stats').setRequired(false))
            .addBooleanOption(opt => opt.setName('show_history').setDescription('Show history graph').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('check')
            .setDescription('Force check a monitor now')
            .addStringOption(opt => opt.setName('url').setDescription('URL to check').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('reset')
            .setDescription('Reset monitor statistics')
            .addStringOption(opt => opt.setName('url').setDescription('URL to reset').setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Weather
    new SlashCommandBuilder()
        .setName('weather')
        .setDescription('Get weather information')
        .addStringOption(opt => opt.setName('city').setDescription('City name').setRequired(true)),

    // Translate
    // QR Code
    new SlashCommandBuilder()
        .setName('qrcode')
        .setDescription('Generate QR code')
        .addStringOption(opt => opt.setName('text').setDescription('Text or URL').setRequired(true)),

    // Remind Me
    new SlashCommandBuilder()
        .setName('remindme')
        .setDescription('Set a reminder')
        .addStringOption(opt => opt.setName('time').setDescription('Time (e.g., 5m, 1h)').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Reminder reason').setRequired(true)),

    // Poll
    new SlashCommandBuilder()
        .setName('poll')
        .setDescription('Create a poll')
        .addStringOption(opt => opt.setName('question').setDescription('Poll question').setRequired(true))
        .addStringOption(opt => opt.setName('options').setDescription('Options separated by |').setRequired(true)),

    // Announce
    new SlashCommandBuilder()
        .setName('announce')
        .setDescription('Send an announcement message')
        .addStringOption(opt => opt.setName('message').setDescription('Your announcement (type \\n for line breaks)').setRequired(true))
        .addChannelOption(opt => opt.setName('channel').setDescription('Channel to send to (defaults to current channel)').setRequired(false))
        .addBooleanOption(opt => opt.setName('mention_everyone').setDescription('Mention @everyone').setRequired(false))
        .addBooleanOption(opt => opt.setName('mention_here').setDescription('Mention @here').setRequired(false))
        .addRoleOption(opt => opt.setName('mention_role').setDescription('Mention a specific role').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    // Embed
    new SlashCommandBuilder()
        .setName('embed')
        .setDescription('Create and send an embed')
        .addChannelOption(opt => opt.setName('channel').setDescription('Channel to send to').setRequired(false))
        .addStringOption(opt => opt.setName('title').setDescription('Embed title').setRequired(false))
        .addStringOption(opt => opt.setName('description').setDescription('Embed description').setRequired(false))
        .addStringOption(opt => opt.setName('color').setDescription('Embed color (hex)').setRequired(false))
        .addStringOption(opt => opt.setName('footer').setDescription('Embed footer').setRequired(false))
        .addStringOption(opt => opt.setName('image').setDescription('Image URL').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    // Moderation Commands
    new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Ban a user')
        .addUserOption(opt => opt.setName('user').setDescription('User to ban').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Ban reason').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

    new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kick a user')
        .addUserOption(opt => opt.setName('user').setDescription('User to kick').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Kick reason').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

    new SlashCommandBuilder()
        .setName('timeout')
        .setDescription('Timeout a user')
        .addUserOption(opt => opt.setName('user').setDescription('User to timeout').setRequired(true))
        .addStringOption(opt => opt.setName('duration').setDescription('Duration (e.g., 1h, 30m)').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Timeout reason').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    new SlashCommandBuilder()
        .setName('warn')
        .setDescription('Warn a user')
        .addUserOption(opt => opt.setName('user').setDescription('User to warn').setRequired(true))
        .addStringOption(opt => opt.setName('reason').setDescription('Warning reason').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    new SlashCommandBuilder()
        .setName('warnings')
        .setDescription('View user warnings')
        .addUserOption(opt => opt.setName('user').setDescription('User to check').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    new SlashCommandBuilder()
        .setName('clearwarns')
        .setDescription('Clear user warnings')
        .addUserOption(opt => opt.setName('user').setDescription('User to clear warnings for').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    new SlashCommandBuilder()
        .setName('purge')
        .setDescription('Purge messages')
        .addIntegerOption(opt => opt.setName('amount').setDescription('Number of messages to purge (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
        .addUserOption(opt => opt.setName('user').setDescription('Only purge messages from this user').setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    // DM Commands
    new SlashCommandBuilder()
        .setName('dm')
        .setDescription('Send DM to user or role')
        .addSubcommand(sub => sub
            .setName('user')
            .setDescription('Send DM to specific user')
            .addUserOption(opt => opt.setName('user').setDescription('User to DM').setRequired(true))
            .addStringOption(opt => opt.setName('message').setDescription('Message to send').setRequired(true))
            .addStringOption(opt => opt.setName('title').setDescription('Embed title').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('role')
            .setDescription('Send DM to all members with specific role')
            .addRoleOption(opt => opt.setName('role').setDescription('Role to DM').setRequired(true))
            .addStringOption(opt => opt.setName('message').setDescription('Message to send').setRequired(true))
            .addStringOption(opt => opt.setName('title').setDescription('Embed title').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('everyone')
            .setDescription('Send DM to all server members')
            .addStringOption(opt => opt.setName('message').setDescription('Message to send').setRequired(true))
            .addStringOption(opt => opt.setName('title').setDescription('Embed title').setRequired(false)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    new SlashCommandBuilder()
        .setName('dmlogs')
        .setDescription('View DM logs')
        .addUserOption(opt => opt.setName('user').setDescription('User to view logs for').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Info Commands
    new SlashCommandBuilder()
        .setName('help')
        .setDescription('Show help menu'),

    new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Check bot latency'),

    new SlashCommandBuilder()
        .setName('stats')
        .setDescription('Show bot statistics'),

    new SlashCommandBuilder()
        .setName('serverinfo')
        .setDescription('Show server information'),

    new SlashCommandBuilder()
        .setName('userinfo')
        .setDescription('Show user information')
        .addUserOption(opt => opt.setName('user').setDescription('User to show info for').setRequired(false)),

    new SlashCommandBuilder()
        .setName('roleinfo')
        .setDescription('Show role information')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to show info for').setRequired(true)),

    new SlashCommandBuilder()
        .setName('avatar')
        .setDescription('Show user avatar')
        .addUserOption(opt => opt.setName('user').setDescription('User to show avatar for').setRequired(false)),

    new SlashCommandBuilder()
        .setName('banner')
        .setDescription('Show user banner')
        .addUserOption(opt => opt.setName('user').setDescription('User to show banner for').setRequired(false)),

    new SlashCommandBuilder()
        .setName('membercount')
        .setDescription('Show member count'),

    // AFK System
    new SlashCommandBuilder()
        .setName('afk')
        .setDescription('Set AFK status')
        .addStringOption(opt => opt.setName('reason').setDescription('AFK reason').setRequired(false)),

    // Invite Tracking System
    new SlashCommandBuilder()
        .setName('invites')
        .setDescription('Check invite statistics')
        .addUserOption(opt => opt.setName('user').setDescription('User to check invites for').setRequired(false)),

    new SlashCommandBuilder()
        .setName('inviteleaderboard')
        .setDescription('Show top inviters in the server')
        .addIntegerOption(opt => opt.setName('limit').setDescription('Number of users to show (default: 10)').setRequired(false)),

    new SlashCommandBuilder()
        .setName('resetinvites')
        .setDescription('Reset invite count for a user')
        .addUserOption(opt => opt.setName('user').setDescription('User to reset invites for').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Role Management
    new SlashCommandBuilder()
        .setName('addrole')
        .setDescription('Add role to user')
        .addUserOption(opt => opt.setName('user').setDescription('User to add role to').setRequired(true))
        .addRoleOption(opt => opt.setName('role').setDescription('Role to add').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    new SlashCommandBuilder()
        .setName('removerole')
        .setDescription('Remove role from user')
        .addUserOption(opt => opt.setName('user').setDescription('User to remove role from').setRequired(true))
        .addRoleOption(opt => opt.setName('role').setDescription('Role to remove').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    // Verification System
    new SlashCommandBuilder()
        .setName('verifyconfig')
        .setDescription('Configure verification system')
        .addRoleOption(opt => opt.setName('role').setDescription('Verified role').setRequired(true))
        .addChannelOption(opt => opt.setName('channel').setDescription('Verification channel').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    new SlashCommandBuilder()
        .setName('verify')
        .setDescription('Verify yourself'),

    // AutoRole
    new SlashCommandBuilder()
        .setName('autorole')
        .setDescription('Configure auto role')
        .addRoleOption(opt => opt.setName('role').setDescription('Role to assign').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Starboard
    new SlashCommandBuilder()
        .setName('starboardconfig')
        .setDescription('Configure starboard')
        .addChannelOption(opt => opt.setName('channel').setDescription('Starboard channel').setRequired(true))
        .addIntegerOption(opt => opt.setName('threshold').setDescription('Minimum stars required').setRequired(false).setMinValue(1))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Auto Publish
    new SlashCommandBuilder()
        .setName('autopublishconfig')
        .setDescription('Configure auto publish')
        .addChannelOption(opt => opt.setName('channel').setDescription('News channel').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Server Stats
    new SlashCommandBuilder()
        .setName('serverstats')
        .setDescription('Setup server stats channels')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Features
    new SlashCommandBuilder()
        .setName('features')
        .setDescription('Show all bot features'),

    // Invite
    new SlashCommandBuilder()
        .setName('invite')
        .setDescription('Get bot invite link'),

    // Ticket System Commands
    new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Ticket system commands')
        .addSubcommand(sub => sub
            .setName('setup')
            .setDescription('Setup ticket system')
            .addChannelOption(opt => opt.setName('category').setDescription('Ticket category').setRequired(true))
            .addRoleOption(opt => opt.setName('support_role').setDescription('Support role').setRequired(false))
            .addChannelOption(opt => opt.setName('log_channel').setDescription('Log channel').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('panel')
            .setDescription('Create a ticket panel')
            .addChannelOption(opt => opt.setName('channel').setDescription('Channel to send panel').setRequired(true))
            .addStringOption(opt => opt.setName('title').setDescription('Panel title').setRequired(false))
            .addStringOption(opt => opt.setName('description').setDescription('Panel description').setRequired(false))
            .addStringOption(opt => opt.setName('type').setDescription('Ticket type').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('add')
            .setDescription('Add user to ticket')
            .addUserOption(opt => opt.setName('user').setDescription('User to add').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('remove')
            .setDescription('Remove user from ticket')
            .addUserOption(opt => opt.setName('user').setDescription('User to remove').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('close')
            .setDescription('Close the ticket')
            .addStringOption(opt => opt.setName('reason').setDescription('Close reason').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('claim')
            .setDescription('Claim the ticket'))
        .addSubcommand(sub => sub
            .setName('transcript')
            .setDescription('Generate ticket transcript'))
        .addSubcommand(sub => sub
            .setName('stats')
            .setDescription('View ticket statistics')
            .addUserOption(opt => opt.setName('user').setDescription('User to check stats for').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('addtype')
            .setDescription('Add ticket type')
            .addStringOption(opt => opt.setName('name').setDescription('Type name').setRequired(true))
            .addStringOption(opt => opt.setName('emoji').setDescription('Type emoji').setRequired(false))
            .addStringOption(opt => opt.setName('description').setDescription('Type description').setRequired(false))
            .addRoleOption(opt => opt.setName('support_role').setDescription('Support role for this type').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('listtypes')
            .setDescription('List all ticket types'))
        .addSubcommand(sub => sub
            .setName('edittype')
            .setDescription('Edit an existing ticket type')
            .addStringOption(opt => opt.setName('name').setDescription('Type name to edit').setRequired(true))
            .addStringOption(opt => opt.setName('new_name').setDescription('New type name').setRequired(false))
            .addStringOption(opt => opt.setName('emoji').setDescription('New emoji').setRequired(false))
            .addStringOption(opt => opt.setName('description').setDescription('New description').setRequired(false))
            .addRoleOption(opt => opt.setName('support_role').setDescription('New support role').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('deletetype')
            .setDescription('Delete a ticket type')
            .addStringOption(opt => opt.setName('name').setDescription('Type name to delete').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('config')
            .setDescription('Configure ticket settings')
            .addStringOption(opt => opt.setName('setting').setDescription('Setting to change').setRequired(true)
                .addChoices(
                    { name: 'Max Tickets Per User', value: 'max_tickets' },
                    { name: 'Welcome Message', value: 'welcome_message' },
                    { name: 'Ticket Name Format', value: 'ticket_name_format' },
                    { name: 'Enable/Disable', value: 'enabled' },
                    { name: 'Transcript', value: 'transcript_enabled' },
                    { name: 'Rating System', value: 'rating_enabled' }
                ))
            .addStringOption(opt => opt.setName('value').setDescription('New value').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('panels')
            .setDescription('List all ticket panels in the server'))
        .addSubcommand(sub => sub
            .setName('editpanel')
            .setDescription('Edit an existing ticket panel')
            .addStringOption(opt => opt.setName('panel_id').setDescription('Panel ID (from /ticket panels)').setRequired(true))
            .addStringOption(opt => opt.setName('title').setDescription('New panel title').setRequired(false))
            .addStringOption(opt => opt.setName('description').setDescription('New panel description').setRequired(false))
            .addStringOption(opt => opt.setName('button_label').setDescription('New button label').setRequired(false))
            .addStringOption(opt => opt.setName('emoji').setDescription('New emoji').setRequired(false))
            .addStringOption(opt => opt.setName('color').setDescription('New embed color (hex)').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('deletepanel')
            .setDescription('Delete a ticket panel')
            .addStringOption(opt => opt.setName('panel_id').setDescription('Panel ID (from /ticket panels)').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('closeall')
            .setDescription('Close all open tickets in the server')
            .addStringOption(opt => opt.setName('reason').setDescription('Reason for closing all tickets').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('listchannel')
            .setDescription('Set channel to display all open tickets')
            .addChannelOption(opt => opt.setName('channel').setDescription('Channel to display ticket list').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('updatelist')
            .setDescription('Manually update the ticket list'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // AI Chat System Commands
    new SlashCommandBuilder()
        .setName('ai')
        .setDescription('AI chat system commands')
        .addSubcommand(sub => sub
            .setName('enable')
            .setDescription('Enable AI chat in a channel')
            .addChannelOption(opt => opt.setName('channel').setDescription('Channel to enable AI (defaults to current)').setRequired(false))
            .addStringOption(opt => opt.setName('provider').setDescription('Preferred AI provider').setRequired(false)
                .addChoices(
                    { name: 'Auto (Try all)', value: 'auto' },
                    { name: 'OpenAI', value: 'openai' },
                    { name: 'Google Gemini', value: 'gemini' },
                    { name: 'Grok', value: 'grok' },
                    { name: 'DeepSeek', value: 'deepseek' }
                ))
            .addStringOption(opt => opt.setName('system_prompt').setDescription('Custom system prompt for AI').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('disable')
            .setDescription('Disable AI chat in a channel')
            .addChannelOption(opt => opt.setName('channel').setDescription('Channel to disable AI (defaults to current)').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('status')
            .setDescription('Check AI system status and configuration'))
        .addSubcommand(sub => sub
            .setName('stats')
            .setDescription('View AI usage statistics'))
        .addSubcommand(sub => sub
            .setName('test')
            .setDescription('Test AI response')
            .addStringOption(opt => opt.setName('message').setDescription('Test message').setRequired(true))
            .addStringOption(opt => opt.setName('provider').setDescription('Specific provider to test').setRequired(false)
                .addChoices(
                    { name: 'OpenAI', value: 'openai' },
                    { name: 'Google Gemini', value: 'gemini' },
                    { name: 'Grok', value: 'grok' },
                    { name: 'DeepSeek', value: 'deepseek' }
                )))
        .addSubcommand(sub => sub
            .setName('channels')
            .setDescription('List all AI-enabled channels'))
        .addSubcommand(sub => sub
            .setName('config')
            .setDescription('Configure AI settings for a channel')
            .addChannelOption(opt => opt.setName('channel').setDescription('Channel to configure').setRequired(false))
            .addNumberOption(opt => opt.setName('temperature').setDescription('Temperature (0.0-2.0, default 0.7)').setRequired(false).setMinValue(0).setMaxValue(2))
            .addIntegerOption(opt => opt.setName('max_tokens').setDescription('Max tokens (default 1000)').setRequired(false).setMinValue(100).setMaxValue(4000)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    // Image Generation Commands
    new SlashCommandBuilder()
        .setName('imagine')
        .setDescription('🎨 Generate an AI image from text prompt')
        .addStringOption(opt => opt
            .setName('prompt')
            .setDescription('Describe the image you want to generate')
            .setRequired(true)
            .setMaxLength(500))
        .addBooleanOption(opt => opt
            .setName('private')
            .setDescription('Make the response visible only to you')
            .setRequired(false)),

    new SlashCommandBuilder()
        .setName('imagehistory')
        .setDescription('📸 View your generated image history')
        .addIntegerOption(opt => opt
            .setName('limit')
            .setDescription('Number of images to show (default: 5)')
            .setRequired(false)
            .setMinValue(1)
            .setMaxValue(10)),

    new SlashCommandBuilder()
        .setName('imagestats')
        .setDescription('📊 View image generation statistics'),

    // Mass Role Management
    new SlashCommandBuilder()
        .setName('massrole')
        .setDescription('Add or remove a role from all server members')
        .addSubcommand(sub => sub
            .setName('add')
            .setDescription('Add a role to all members in the server')
            .addRoleOption(opt => opt.setName('role').setDescription('Role to add to everyone').setRequired(true))
            .addRoleOption(opt => opt.setName('filter_role').setDescription('Only add to members who have this role').setRequired(false))
            .addBooleanOption(opt => opt.setName('include_bots').setDescription('Include bots (default: false)').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('remove')
            .setDescription('Remove a role from all members in the server')
            .addRoleOption(opt => opt.setName('role').setDescription('Role to remove from everyone').setRequired(true))
            .addRoleOption(opt => opt.setName('filter_role').setDescription('Only remove from members who have this role').setRequired(false))
            .addBooleanOption(opt => opt.setName('include_bots').setDescription('Include bots (default: false)').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('status')
            .setDescription('Check the status of a running mass role operation'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    // Review System
    new SlashCommandBuilder()
        .setName('review')
        .setDescription('Server review system - leave or manage reviews')
        .addSubcommand(sub => sub
            .setName('submit')
            .setDescription('Submit a review for the server')
            .addIntegerOption(opt => opt.setName('rating').setDescription('Rating from 1 to 5 stars').setRequired(true).setMinValue(1).setMaxValue(5))
            .addStringOption(opt => opt.setName('note').setDescription('Write your review (optional, max 500 chars)').setRequired(false).setMaxLength(500))
            .addBooleanOption(opt => opt.setName('anonymous').setDescription('Submit anonymously (if allowed)').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('setup')
            .setDescription('Setup the review system (Admin)')
            .addChannelOption(opt => opt.setName('review_channel').setDescription('Channel to display all reviews').setRequired(true))
            .addChannelOption(opt => opt.setName('log_channel').setDescription('Channel for review logs/notifications').setRequired(false))
            .addIntegerOption(opt => opt.setName('max_reviews').setDescription('Max reviews per user (default: 3)').setRequired(false).setMinValue(1).setMaxValue(20))
            .addIntegerOption(opt => opt.setName('cooldown_hours').setDescription('Hours between reviews per user (default: 24)').setRequired(false).setMinValue(1).setMaxValue(720))
            .addBooleanOption(opt => opt.setName('allow_anonymous').setDescription('Allow anonymous reviews (default: false)').setRequired(false))
            .addRoleOption(opt => opt.setName('require_role').setDescription('Require this role to leave a review').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('list')
            .setDescription('View recent reviews for this server')
            .addIntegerOption(opt => opt.setName('page').setDescription('Page number').setRequired(false).setMinValue(1))
            .addUserOption(opt => opt.setName('user').setDescription('Filter reviews by user').setRequired(false)))
        .addSubcommand(sub => sub
            .setName('stats')
            .setDescription('View review statistics for this server'))
        .addSubcommand(sub => sub
            .setName('delete')
            .setDescription('Delete a review (Admin or review author)')
            .addIntegerOption(opt => opt.setName('review_id').setDescription('Review ID to delete').setRequired(true)))
        .addSubcommand(sub => sub
            .setName('edit')
            .setDescription('Edit your own review')
            .addIntegerOption(opt => opt.setName('review_id').setDescription('Review ID to edit').setRequired(true))
            .addIntegerOption(opt => opt.setName('rating').setDescription('New rating (1-5)').setRequired(false).setMinValue(1).setMaxValue(5))
            .addStringOption(opt => opt.setName('note').setDescription('New note (max 500 chars)').setRequired(false).setMaxLength(500))),


];


// Convert commands to JSON format
const commandsJSON = commands.map(cmd => cmd.toJSON());

// Mass Role Operations Tracker
const massRoleOps = new Map();

// =======================
// EVENT HANDLERS
// =======================
let botStartTime = null;

client.once('ready', async () => {
    botStartTime = new Date();
    
    console.log(`✅ ${client.user.tag} is online!`);
    console.log(`👑 Super Admins: ${config.SUPER_ADMINS.join(', ') || 'None'}`);
    console.log(`⚙️ Loaded ${commands.length} commands`);
    
    // Set initial presence
    const activityType = getActivityType(config.BOT_ACTIVITY_TYPE);
    client.user.setPresence({
        status: config.BOT_STATUS,
        activities: [{
            name: config.BOT_ACTIVITY_NAME,
            type: activityType
        }]
    });
    
    // Register commands
    try {
        const rest = new REST({ version: '10' }).setToken(config.DISCORD_TOKEN);
        const route = config.GUILD_ID 
            ? Routes.applicationGuildCommands(client.user.id, config.GUILD_ID)
            : Routes.applicationCommands(client.user.id);
        
        // Fetch existing commands to preserve Entry Point
        let existingCommands = [];
        try {
            existingCommands = await rest.get(route);
        } catch (err) {
            console.log('Could not fetch existing commands, proceeding with registration...');
        }
        
        // Find Entry Point command if it exists
        const entryPointCommand = existingCommands.find(cmd => 
            cmd.integration_types?.includes(1) || cmd.contexts?.includes(1) || cmd.type === 1
        );
        
        // Prepare commands to register
        let commandsToRegister = [...commandsJSON];
        
        // If Entry Point exists and not in our commands, add it
        if (entryPointCommand && !commandsJSON.find(cmd => cmd.name === entryPointCommand.name)) {
            commandsToRegister.push(entryPointCommand);
            console.log(`✓ Preserving Entry Point command: ${entryPointCommand.name}`);
        }
        
        // Register commands
        await rest.put(route, { body: commandsToRegister });
        
        if (config.GUILD_ID) {
            console.log(`✅ Commands registered for guild ${config.GUILD_ID}`);
        } else {
            console.log('✅ Commands registered globally');
        }
    } catch (error) {
        console.error('Error registering commands:', error);
        console.log('⚠️ Bot will continue running, but slash commands may not work properly');
    }
    
    // Load ongoing giveaways
    const activeGiveaways = await db.all('SELECT * FROM giveaways WHERE ended = 0 AND end_time > ?', [new Date().toISOString()]);
    for (const giveaway of activeGiveaways) {
        const timeLeft = new Date(giveaway.end_time).getTime() - Date.now();
        if (timeLeft > 0) {
            setTimeout(() => giveawayManager.endGiveaway(giveaway.guild_id, giveaway.message_id), timeLeft);
            console.log(`Loaded giveaway: ${giveaway.prize} (ends in ${Math.floor(timeLeft / 1000 / 60)} minutes)`);
        } else {
            await giveawayManager.endGiveaway(giveaway.guild_id, giveaway.message_id);
        }
    }
    
    // Load custom commands cache
    const guilds = client.guilds.cache.map(g => g.id);
    for (const guildId of guilds) {
        await customCommands.getCommands(guildId);
    }
    
    // Start periodic tasks
    setInterval(() => statusMonitor.checkStatusMonitors(), config.STATUS_MONITOR_INTERVAL || 300000);
    
    // Initial checks
    statusMonitor.checkStatusMonitors();
    
    // Cache invites for all guilds
    for (const guild of client.guilds.cache.values()) {
        try {
            await inviteTracker.cacheInvites(guild);
        } catch (error) {
            // Silently fail - permission error handled inside cacheInvites
        }
    }
    
    console.log('✅ Bot is fully initialized and ready!');
    console.log(' Hopingboyz Bot add your discord!');
});

// Anti-Nuke Events
const antiNukeEvents = {
    guildMemberRemove: AuditLogEvent.MemberKick,
    guildBanAdd: AuditLogEvent.MemberBanAdd,
    roleCreate: AuditLogEvent.RoleCreate,
    roleDelete: AuditLogEvent.RoleDelete,
    roleUpdate: AuditLogEvent.RoleUpdate,
    channelCreate: AuditLogEvent.ChannelCreate,
    channelDelete: AuditLogEvent.ChannelDelete,
    channelUpdate: AuditLogEvent.ChannelUpdate,
    guildUpdate: AuditLogEvent.GuildUpdate,
    emojiCreate: AuditLogEvent.EmojiCreate,
    emojiDelete: AuditLogEvent.EmojiDelete,
    emojiUpdate: AuditLogEvent.EmojiUpdate,
    stickerCreate: AuditLogEvent.StickerCreate,
    stickerDelete: AuditLogEvent.StickerDelete,
    stickerUpdate: AuditLogEvent.StickerUpdate,
    webhookCreate: AuditLogEvent.WebhookCreate,
    webhookDelete: AuditLogEvent.WebhookDelete,
    webhookUpdate: AuditLogEvent.WebhookUpdate,
    inviteCreate: AuditLogEvent.InviteCreate,
    inviteDelete: AuditLogEvent.InviteDelete,
    memberUpdate: AuditLogEvent.MemberUpdate
};

// Map event names to action types for database
const eventToActionType = {
    'guildMemberRemove': 'kick',
    'guildBanAdd': 'ban',
    'roleCreate': 'role_create',
    'roleDelete': 'role_delete',
    'roleUpdate': 'role_update',
    'channelCreate': 'channel_create',
    'channelDelete': 'channel_delete',
    'channelUpdate': 'channel_update',
    'guildUpdate': 'guild_update',
    'emojiCreate': 'emoji_create',
    'emojiDelete': 'emoji_delete',
    'emojiUpdate': 'emoji_update',
    'stickerCreate': 'sticker_create',
    'stickerDelete': 'sticker_delete',
    'stickerUpdate': 'sticker_update',
    'webhookCreate': 'webhook_create',
    'webhookDelete': 'webhook_delete',
    'webhookUpdate': 'webhook_update',
    'inviteCreate': 'invite_create',
    'inviteDelete': 'invite_delete',
    'memberUpdate': 'member_update'
};

Object.entries(antiNukeEvents).forEach(([eventName, auditType]) => {
    client.on(eventName, async (...args) => {
        const guild = args[0]?.guild || args[1]?.guild;
        if (!guild) return;
        
        const actionType = eventToActionType[eventName] || eventName;
        await security.handleAntiNukeEvent(guild, actionType, args[0], auditType);
    });
});

// Listen for message deletes to detect unauthorized deletions
client.on('messageDelete', async (message) => {
    try {
        await security.handleMessageDelete(message);
    } catch (err) {
        console.error('Error in messageDelete listener:', err);
    }
});

// Message handler
client.on('messageCreate', async (message) => {
    // Ignore bots
    if (message.author.bot) return;
    
    // Handle DMs to bot
    if (!message.guild) {
        // Log incoming DM
        try {
            await db.run(
                'INSERT INTO dm_logs (user_id, guild_id, moderator_id, message, timestamp, direction) VALUES (?, ?, ?, ?, ?, ?)',
                [message.author.id, null, null, message.content, new Date().toISOString(), 'in']
            );
            
            // Auto-reply to DMs
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.info} Bot DM System`);

            const dmEmbed = createEmbed({
                title: `${EMOJIS.info} Bot DM System`,
                description: `Hello ${message.author.username}! I have logged your message.\n\nIf you need help, join my support server or use \`/help\` in a server where I'm present.`,
                color: COLORS.INFO,
                footer: config.BOT_WATERMARK
            });

            await message.author.send({ embeds: [dmEmbed] }).catch(() => {});
        } catch (error) {
            console.error('Error handling DM:', error);
        }
        return;
    }
    
    // Anti-nuke: enforce message-level protections (e.g., block @everyone from untrusted users)
    try {
        const enforced = await security.enforceAntiNukeOnMessage(message);
        if (enforced) return; // message handled (deleted/punished)
    } catch (e) {
        console.error('Error running anti-nuke message enforcement:', e);
    }

    // Check for spam
    const spamCheck = await security.checkSpam(message);
    if (spamCheck.detected) {
        await security.handleSpam(message, spamCheck);
        return;
    }
    
    // Check for bad words
    const badWordsCheck = await security.checkBadWords(message);
    if (badWordsCheck.detected) {
        await security.handleBadWords(message, badWordsCheck);
        return;
    }
    
    // AI Chat System - Check if channel has AI enabled
    const aiChannel = await aiManager.isChannelEnabled(message.guild.id, message.channel.id);
    if (aiChannel && config.AI_CONFIG?.enabled) {
        // MENTION-ONLY MODE: Bot only responds when mentioned
        const botMentioned = message.mentions.has(client.user);
        
        // Only respond if bot is mentioned
        if (!botMentioned) {
            return; // Ignore messages without mention
        }
        
        try {
            // Check rate limit
            const rateLimit = await aiManager.checkRateLimit(message.author.id, message.guild.id);
                if (!rateLimit.allowed) {
                    return message.reply(`${EMOJIS.error} You're sending messages too fast! Please wait ${rateLimit.timeLeft} seconds.`);
                }
                
                // Show typing indicator
                await message.channel.sendTyping();
                
                // Remove bot mention from message
                let userMessage = message.content.replace(/<@!?\d+>/g, '').trim();
                
                if (!userMessage) {
                    return message.reply(`${EMOJIS.info} Hi! I'm an AI assistant. How can I help you?`);
                }
                
                // Get AI response
                const result = await aiManager.getAIResponse(userMessage, aiChannel, message.guild.id, message.channel.id, message.author.id);
                
                // Check if user is SUPER_ADMIN and wants to save memory or set restrictions
                const isSuperAdmin = config.SUPER_ADMINS && config.SUPER_ADMINS.includes(message.author.id);
                if (isSuperAdmin) {
                    // Detect memory commands: "remember", "save this", "don't forget"
                    const memoryKeywords = ['remember', 'save this', 'don\'t forget', 'keep in mind', 'note this'];
                    const hasMemoryKeyword = memoryKeywords.some(keyword => userMessage.toLowerCase().includes(keyword));
                    
                    if (hasMemoryKeyword) {
                        try {
                            await db.run(
                                'INSERT INTO super_admin_memory (admin_id, command, memory_data, timestamp) VALUES (?, ?, ?, ?)',
                                [message.author.id, userMessage, userMessage, Date.now()]
                            );
                            console.log(`✅ Saved super admin memory for ${message.author.tag}: ${userMessage}`);
                        } catch (error) {
                            console.error('Error saving super admin memory:', error);
                        }
                    }
                    
                    // Detect user restriction commands: "restrict @user", "limit @user", "block @user from"
                    const mentionedUsers = message.mentions.users;
                    if (mentionedUsers.size > 0 && (userMessage.toLowerCase().includes('restrict') || 
                        userMessage.toLowerCase().includes('limit') || 
                        userMessage.toLowerCase().includes('block') ||
                        userMessage.toLowerCase().includes('prevent'))) {
                        
                        mentionedUsers.forEach(async (user) => {
                            if (user.id !== message.author.id && user.id !== client.user.id) {
                                try {
                                    // Extract restriction type from message
                                    let restrictionType = 'general';
                                    let restrictionData = userMessage;
                                    
                                    if (userMessage.toLowerCase().includes('no code') || userMessage.toLowerCase().includes('no files')) {
                                        restrictionType = 'no_code_generation';
                                        restrictionData = 'Cannot generate code or files';
                                    } else if (userMessage.toLowerCase().includes('no roast') || userMessage.toLowerCase().includes('be nice')) {
                                        restrictionType = 'no_roasting';
                                        restrictionData = 'Must be polite and respectful';
                                    } else if (userMessage.toLowerCase().includes('short') || userMessage.toLowerCase().includes('brief')) {
                                        restrictionType = 'short_responses';
                                        restrictionData = 'Keep responses under 500 characters';
                                    }
                                    
                                    await db.run(
                                        'INSERT OR REPLACE INTO user_ai_restrictions (guild_id, user_id, restriction_type, restriction_data, set_by, timestamp) VALUES (?, ?, ?, ?, ?, ?)',
                                        [message.guild.id, user.id, restrictionType, restrictionData, message.author.id, Date.now()]
                                    );
                                    
                                    console.log(`✅ Set restriction for ${user.tag} by SUPER ADMIN ${message.author.tag}: ${restrictionType}`);
                                } catch (error) {
                                    console.error('Error setting user restriction:', error);
                                }
                            }
                        });
                    }
                }
                
                // Detect and extract code blocks for file generation
                const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g;
                const codeBlocks = [];
                let match;
                
                while ((match = codeBlockRegex.exec(result.text)) !== null) {
                    const language = match[1] || 'txt';
                    const code = match[2].trim();
                    
                    if (!code) continue; // Skip empty blocks
                    
                    // Determine file extension
                    const extensionMap = {
                        'javascript': 'js', 'js': 'js', 'jsx': 'jsx',
                        'typescript': 'ts', 'ts': 'ts', 'tsx': 'tsx',
                        'python': 'py', 'py': 'py',
                        'html': 'html', 'htm': 'html',
                        'css': 'css', 'scss': 'scss', 'sass': 'sass', 'less': 'less',
                        'ejs': 'ejs', 'pug': 'pug', 'handlebars': 'hbs', 'hbs': 'hbs',
                        'json': 'json', 'json5': 'json',
                        'java': 'java',
                        'cpp': 'cpp', 'c++': 'cpp',
                        'c': 'c',
                        'csharp': 'cs', 'cs': 'cs',
                        'go': 'go',
                        'rust': 'rs', 'rs': 'rs',
                        'php': 'php',
                        'ruby': 'rb', 'rb': 'rb',
                        'swift': 'swift',
                        'kotlin': 'kt', 'kt': 'kt',
                        'sql': 'sql', 'mysql': 'sql', 'postgresql': 'sql',
                        'bash': 'sh', 'shell': 'sh', 'sh': 'sh',
                        'yaml': 'yaml', 'yml': 'yml',
                        'xml': 'xml',
                        'markdown': 'md', 'md': 'md',
                        'vue': 'vue',
                        'svelte': 'svelte',
                        'dockerfile': 'dockerfile',
                        'nginx': 'conf',
                        'apache': 'conf',
                        'env': 'env',
                        'gitignore': 'gitignore',
                        'txt': 'txt', 'text': 'txt'
                    };
                    
                    const extension = extensionMap[language.toLowerCase()] || 'txt';
                    codeBlocks.push({ language, code, extension });
                }
                
                // Check if user is asking to create/make files
                const fileCreationKeywords = ['make', 'create', 'build', 'generate', 'write', 'code', 'develop', 'design'];
                const isFileCreationRequest = fileCreationKeywords.some(keyword => 
                    userMessage.toLowerCase().includes(keyword)
                );
                
                // If files detected and it's a file creation request, send ONLY files (NO TEXT)
                if (codeBlocks.length > 0 && isFileCreationRequest) {
                    const attachments = [];
                    
                    for (let i = 0; i < codeBlocks.length; i++) {
                        const block = codeBlocks[i];
                        
                        // Determine filename based on content or language
                        let filename = `file_${i + 1}.${block.extension}`;
                        
                        // Try to extract filename from comments
                        const filenameMatch = block.code.match(/(?:\/\/|#|<!--)\s*(?:filename:|file:)\s*([^\s\n]+)/i);
                        if (filenameMatch) {
                            filename = filenameMatch[1];
                        } else {
                            // Smart naming based on language
                            const nameMap = {
                                'html': 'index.html',
                                'css': 'style.css',
                                'js': 'script.js',
                                'jsx': 'App.jsx',
                                'ts': 'index.ts',
                                'tsx': 'App.tsx',
                                'py': 'main.py',
                                'java': 'Main.java',
                                'php': 'index.php',
                                'ejs': 'index.ejs',
                                'json': 'config.json',
                                'md': 'README.md',
                                'sh': 'script.sh',
                                'sql': 'database.sql',
                                'dockerfile': 'Dockerfile',
                                'env': '.env',
                                'gitignore': '.gitignore',
                                'vue': 'App.vue',
                                'svelte': 'App.svelte',
                                'go': 'main.go',
                                'rs': 'main.rs',
                                'rb': 'main.rb',
                                'swift': 'main.swift',
                                'kt': 'Main.kt'
                            };
                            filename = nameMap[block.extension] || filename;
                        }
                        
                        const buffer = Buffer.from(block.code, 'utf-8');
                        attachments.push({
                            attachment: buffer,
                            name: filename
                        });
                    }
                    
                    if (attachments.length > 0) {
                        // Send ONLY files - ABSOLUTELY NO TEXT
                        await message.reply({
                            files: attachments
                        });
                        
                        console.log(`📁 Sent ${attachments.length} file(s) to ${message.author.tag} (NO TEXT)`);
                    }
                } else {
                    // No files or not a file creation request - send normal text response
                    const responses = [];
                    if (result.text.length > 2000) {
                        for (let i = 0; i < result.text.length; i += 2000) {
                            responses.push(result.text.substring(i, i + 2000));
                        }
                    } else {
                        responses.push(result.text);
                    }
                    
                    // Send responses (sanitize to prevent accidental @everyone/@here)
                    for (const response of responses) {
                        await message.reply(sanitizeMentions(response));
                    }
                    
                    // If there are code blocks but not a file creation request, still offer files
                    if (codeBlocks.length > 0) {
                        const attachments = [];
                        
                        for (let i = 0; i < codeBlocks.length; i++) {
                            const block = codeBlocks[i];
                            
                            let filename = `file_${i + 1}.${block.extension}`;
                            
                            const filenameMatch = block.code.match(/(?:\/\/|#|<!--)\s*(?:filename:|file:)\s*([^\s\n]+)/i);
                            if (filenameMatch) {
                                filename = filenameMatch[1];
                            } else {
                                const nameMap = {
                                    'html': 'index.html',
                                    'css': 'style.css',
                                    'js': 'script.js',
                                    'jsx': 'App.jsx',
                                    'ts': 'index.ts',
                                    'tsx': 'App.tsx',
                                    'py': 'main.py',
                                    'java': 'Main.java',
                                    'php': 'index.php',
                                    'ejs': 'index.ejs',
                                    'json': 'config.json',
                                    'md': 'README.md',
                                    'sh': 'script.sh',
                                    'sql': 'database.sql',
                                    'dockerfile': 'Dockerfile',
                                    'env': '.env',
                                    'gitignore': '.gitignore'
                                };
                                filename = nameMap[block.extension] || filename;
                            }
                            
                            const buffer = Buffer.from(block.code, 'utf-8');
                            attachments.push({
                                attachment: buffer,
                                name: filename
                            });
                        }
                        
                        if (attachments.length > 0) {
                            const fileEmojis = {
                                'js': '📜', 'jsx': '⚛️', 'ts': '📘', 'tsx': '⚛️',
                                'py': '🐍', 'html': '🌐', 'css': '🎨', 'json': '📋',
                                'java': '☕', 'php': '🐘', 'sql': '🗄️', 'md': '📝',
                                'sh': '💻', 'dockerfile': '🐳'
                            };
                            
                            const emoji = fileEmojis[attachments[0].name.split('.').pop()] || '📁';
                            
                            await message.channel.send({
                                content: `${emoji} **Download ${attachments.length === 1 ? 'file' : 'files'}:** 📥`,
                                files: attachments
                            });
                        }
                    }
                }
                
                // Conversation is automatically logged in getAIResponse
                
                return; // Don't process other commands
                
            } catch (error) {
                console.error('AI Response Error:', error);
                await message.reply(`${EMOJIS.error} Sorry, I encountered an error: ${error.message}`);
                return;
            }
        }
    
    // Handle custom commands using the centralized CustomCommandsManager
    try {
        const execResult = await customCommands.executeMessage(message);
        if (execResult && execResult.executed) {
            if (!execResult.sent && execResult.error) {
                console.error('Custom command executed but failed to send:', execResult.error);
            }
            return; // stop further processing when a custom command matched
        }
    } catch (err) {
        console.error('Error handling custom command:', err);
    }
    
    // AFK System
    if (message.mentions.users.size > 0) {
        for (const mentionedUser of message.mentions.users.values()) {
            const afkData = await db.get('SELECT * FROM afk WHERE guild_id = ? AND user_id = ?', [message.guild.id, mentionedUser.id]);
            if (afkData) {
                const afkTime = Math.floor(new Date(afkData.timestamp).getTime() / 1000);
                // Sanitize the reason to prevent @everyone and @here mentions
                const sanitizedReason = sanitizeMentions(afkData.reason);
                await message.reply(`${mentionedUser} is AFK: **${sanitizedReason}** - Since <t:${afkTime}:R>`).catch(() => {});
            }
        }
    }
    
    // Check if user was AFK
    const userAfk = await db.get('SELECT * FROM afk WHERE guild_id = ? AND user_id = ?', [message.guild.id, message.author.id]);
    if (userAfk) {
        await db.run('DELETE FROM afk WHERE guild_id = ? AND user_id = ?', [message.guild.id, message.author.id]);
        await message.reply(`Welcome back ${message.author}! I've removed your AFK status.`).catch(() => {});
    }
    
    // Auto Publish
    const autoPublish = await db.get('SELECT * FROM auto_publish WHERE guild_id = ?', [message.guild.id]);
    if (autoPublish && message.channel.id === autoPublish.channel_id && message.crosspostable) {
        await message.crosspost().catch(() => {});
    }
});

// Button interactions
client.on('interactionCreate', async (interaction) => {
    // Music button interactions
    if (interaction.isButton()) {
        const customId = interaction.customId;
        
        // Music control buttons
        if (customId.startsWith('music_')) {
            try {
                const queue = distube.getQueue(interaction.guildId);
                if (!queue) {
                    return interaction.reply({ 
                        embeds: [createEmbed({ title: `${EMOJIS.error} Error`, description: 'No music is playing!', color: COLORS.ERROR })],
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                // Check if user is in voice channel
                if (!interaction.member.voice.channel) {
                    return interaction.reply({ 
                        embeds: [createEmbed({ title: `${EMOJIS.error} Error`, description: 'You need to be in a voice channel!', color: COLORS.ERROR })],
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                // Check if user is in same voice channel
                if (interaction.guild.members.me.voice.channel && interaction.member.voice.channel.id !== interaction.guild.members.me.voice.channel.id) {
                    return interaction.reply({ 
                        embeds: [createEmbed({ title: `${EMOJIS.error} Error`, description: 'You must be in the same voice channel as me!', color: COLORS.ERROR })],
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                await interaction.deferUpdate();

                switch (customId) {
                    case 'music_pause':
                        if (queue.paused) {
                            distube.resume(interaction);
                            await interaction.followUp({ 
                                embeds: [createEmbed({ title: `${EMOJIS.play} Resumed`, description: 'Music resumed!', color: COLORS.SUCCESS })],
                                flags: [MessageFlags.Ephemeral]
                            });
                        } else {
                            distube.pause(interaction);
                            await interaction.followUp({ 
                                embeds: [createEmbed({ title: `${EMOJIS.pause} Paused`, description: 'Music paused!', color: COLORS.SUCCESS })],
                                flags: [MessageFlags.Ephemeral]
                            });
                        }
                        // Update buttons
                        await interaction.message.edit({ components: [createMusicControls(queue)] });
                        break;

                    case 'music_skip':
                        if (queue.songs.length > 1) {
                            await distube.skip(interaction);
                            await interaction.followUp({ 
                                embeds: [createEmbed({ title: `${EMOJIS.skip} Skipped`, description: 'Skipped to next song!', color: COLORS.SUCCESS })],
                                flags: [MessageFlags.Ephemeral]
                            });
                        }
                        break;

                    case 'music_stop':
                        await distube.stop(interaction);
                        await interaction.followUp({ 
                            embeds: [createEmbed({ title: `${EMOJIS.stop} Stopped`, description: 'Music stopped and queue cleared!', color: COLORS.SUCCESS })],
                            flags: [MessageFlags.Ephemeral]
                        });
                        break;

                    case 'music_loop':
                        const data = getMusicData(interaction.guildId);
                        if (data.loop === 'off') {
                            distube.setRepeatMode(interaction, 2); // Queue loop
                            data.loop = 'queue';
                            await interaction.followUp({ 
                                embeds: [createEmbed({ title: `${EMOJIS.repeat} Loop: Queue`, description: 'Looping the entire queue!', color: COLORS.SUCCESS })],
                                flags: [MessageFlags.Ephemeral]
                            });
                        } else if (data.loop === 'queue') {
                            distube.setRepeatMode(interaction, 1); // Song loop
                            data.loop = 'song';
                            await interaction.followUp({ 
                                embeds: [createEmbed({ title: `${EMOJIS.loop_one} Loop: Song`, description: 'Looping current song!', color: COLORS.SUCCESS })],
                                flags: [MessageFlags.Ephemeral]
                            });
                        } else {
                            distube.setRepeatMode(interaction, 0); // Off
                            data.loop = 'off';
                            await interaction.followUp({ 
                                embeds: [createEmbed({ title: `${EMOJIS.info} Loop: Off`, description: 'Loop disabled!', color: COLORS.INFO })],
                                flags: [MessageFlags.Ephemeral]
                            });
                        }
                        // Update buttons
                        await interaction.message.edit({ components: [createMusicControls(queue)] });
                        break;

                    case 'music_previous':
                        const musicData = getMusicData(interaction.guildId);
                        if (musicData.history.length > 0) {
                            const prevSong = musicData.history.pop();
                            // CRITICAL FIX: Get proper text channel
                            let textChannel = interaction.message.channel;
                            if (!textChannel || textChannel.type === 2) {
                                textChannel = interaction.guild.channels.cache.find(
                                    ch => (ch.type === 0 || ch.type === 5) && ch.viewable
                                );
                            }
                            
                            await distube.play(interaction.member.voice.channel, prevSong.url, {
                                textChannel: textChannel,
                                member: interaction.member,
                                skip: true
                            });
                            await interaction.followUp({ 
                                embeds: [createEmbed({ title: `${EMOJIS.previous} Previous`, description: `Playing: **${prevSong.name}**`, color: COLORS.SUCCESS })],
                                flags: [MessageFlags.Ephemeral]
                            });
                        } else {
                            await interaction.followUp({ 
                                embeds: [createEmbed({ title: `${EMOJIS.error} Error`, description: 'No previous song in history!', color: COLORS.ERROR })],
                                flags: [MessageFlags.Ephemeral]
                            });
                        }
                        break;
                }
            } catch (error) {
                console.error('Music button error:', error);
                try {
                    await interaction.followUp({ 
                        embeds: [createEmbed({ title: `${EMOJIS.error} Error`, description: `An error occurred: ${error.message}`, color: COLORS.ERROR })],
                        flags: [MessageFlags.Ephemeral]
                    }).catch(() => {});
                } catch {}
            }
            return;
        }
    }
    
    // Ticket button interactions
    if (interaction.isButton()) {
        const customId = interaction.customId;
        
        // Help menu pagination buttons
        if (customId === 'help_page_1' || customId === 'help_page_2') {
            const embed1 = new EmbedBuilder()
                .setTitle(`📚 ${client.user.username} - Complete Command Guide`)
                .setDescription('**A powerful all-in-one Discord bot with advanced features**\n\n*Use the commands below to manage your server effectively*')
                .setColor(COLORS.PRIMARY)
                .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
                .addFields(
                    { name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', value: '** **', inline: false },
                    { name: `${EMOJIS.crown} **SUPER ADMIN COMMANDS**`, value: '```/superadmin add/remove/list - Manage bot super admins\n/botconfig - Configure bot-wide settings\n/extraowner add/remove/list - Manage server extra owners```', inline: false },
                    { name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', value: '** **', inline: false },
                    { name: `${EMOJIS.shield} **SECURITY & PROTECTION**`, value: '```/antinuke enable/disable/config - Anti-nuke protection system\n/antinuke whitelist - Manage anti-nuke whitelist\n/antinuke logs - View security logs\n/antispam enable/disable/config - Anti-spam system\n/badwords add/remove/list - Bad words filter```', inline: false },
                    { name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', value: '** **', inline: false },
                    { name: `${EMOJIS.hammer} **MODERATION COMMANDS**`, value: '```/ban - Ban a user from the server\n/kick - Kick a user from the server\n/timeout - Timeout a user (mute temporarily)\n/warn - Warn a user for rule violations\n/warnings - View user warnings\n/clearwarns - Clear user warnings\n/purge - Delete multiple messages at once\n/lock - Lock a channel\n/unlock - Unlock a channel\n/slowmode - Set channel slowmode```', inline: false },
                    { name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', value: '** **', inline: false },
                    { name: `🎫 **TICKET SYSTEM**`, value: '```/ticket setup - Initial ticket system setup\n/ticket panel - Create a ticket panel\n/ticket panels - List all ticket panels\n/ticket editpanel - Edit existing panel\n/ticket deletepanel - Delete a panel\n/ticket closeall - Close all open tickets\n/ticket add - Add user to ticket\n/ticket remove - Remove user from ticket\n/ticket close - Close a ticket\n/ticket claim - Claim a ticket\n/ticket transcript - Generate ticket transcript\n/ticket stats - View ticket statistics\n/ticket addtype - Add ticket category\n/ticket listtypes - List ticket categories\n/ticket edittype - Edit ticket category\n/ticket deletetype - Delete ticket category\n/ticket config - Configure ticket settings```', inline: false },
                    { name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', value: '** **', inline: false },
                    { name: `${EMOJIS.envelope} **WELCOME & GOODBYE**`, value: '```/welcome setup - Configure welcome messages\n/welcome test - Test welcome message\n/welcome disable - Disable welcome messages\n/goodbye setup - Configure goodbye messages\n/goodbye test - Test goodbye message\n/goodbye disable - Disable goodbye messages```', inline: false },
                    { name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', value: '** **', inline: false },
                    { name: `${EMOJIS.envelope} **DM SYSTEM**`, value: '```/dm user - Send DM to specific user\n/dm role - Send DM to all users with a role\n/dm everyone - Send DM to all server members\n/dmlogs - View DM logs and history```', inline: false }
                )
                .setFooter({ text: `${config.BOT_WATERMARK} | Page 1/2 - Use buttons below to navigate` })
                .setTimestamp();

            const embed2 = new EmbedBuilder()
                .setTitle(`📚 ${client.user.username} - Complete Command Guide`)
                .setDescription('**Continued from previous page...**')
                .setColor(COLORS.PRIMARY)
                .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
                .addFields(
                    { name: `${EMOJIS.invite} **INVITE TRACKING**`, value: '```/invites - Check your or someone\'s invite stats\n/inviteleaderboard - View top inviters\n/resetinvites - Reset user invite count (Admin)```', inline: false },
                    { name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', value: '** **', inline: false },
                    { name: `${EMOJIS.gear} **UTILITY & TOOLS**`, value: '```/customcommand add/remove/list - Custom commands\n/giveaway start/end/reroll - Giveaway system\n/statusmonitor add/remove/list - Website monitoring\n/weather - Get weather information\n/qrcode - Generate QR codes\n/remindme - Set reminders\n/poll - Create polls\n/afk - Set AFK status```', inline: false },
                    { name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', value: '** **', inline: false },
                    { name: `${EMOJIS.info} **INFORMATION COMMANDS**`, value: '```/serverinfo - View server information\n/userinfo - View user information\n/roleinfo - View role information\n/avatar - View user avatar\n/banner - View user banner\n/membercount - View member count\n/ping - Check bot latency\n/stats - View bot statistics\n/help - Show this help menu```', inline: false },
                    { name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', value: '** **', inline: false },
                    { name: `⚙️ **SERVER MANAGEMENT**`, value: '```/autorole set/remove - Auto-assign roles to new members\n/stickyroles enable/disable - Restore roles on rejoin\n/addrole - Add role to user\n/removerole - Remove role from user\n/verifyconfig - Setup verification system\n/verify - Verify yourself\n/serverstats setup/remove - Server statistics channels```', inline: false },
                    { name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', value: '** **', inline: false },
                    { name: `🎉 **FUN & ENGAGEMENT**`, value: '```/starboard setup/remove - Starboard system\n/reactionrole add/remove/list - Reaction roles\n/autopublish setup/remove - Auto-publish announcements```', inline: false },
                    { name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', value: '** **', inline: false },
                    { name: '💡 **QUICK TIPS**', value: '• Most commands require specific permissions\n• Use `/help` anytime to see this menu\n• Commands marked (Admin) require Manage Server\n• Protected users: Owner, Extra Owners, Super Admins\n• Join our support server for help and updates', inline: false }
                )
                .setFooter({ text: `${config.BOT_WATERMARK} | Page 2/2 - Total Commands: ${commands.length}` })
                .setTimestamp();

            const row1 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('help_page_1')
                        .setLabel('◀ Page 1')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId('help_page_2')
                        .setLabel('Page 2 ▶')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setLabel('Support Server')
                        .setStyle(ButtonStyle.Link)
                        .setURL('https://discord.gg/your-support-server')
                        .setEmoji('🔗')
                );

            const row2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('help_page_1')
                        .setLabel('◀ Page 1')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('help_page_2')
                        .setLabel('Page 2 ▶')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setLabel('Support Server')
                        .setStyle(ButtonStyle.Link)
                        .setURL('https://discord.gg/your-support-server')
                        .setEmoji('🔗')
                );

            if (customId === 'help_page_1') {
                await interaction.update({ embeds: [embed1], components: [row1] });
            } else {
                await interaction.update({ embeds: [embed2], components: [row2] });
            }
            return;
        }
        
        // Ticket creation button
        if (customId.startsWith('ticket_create_')) {
            // Defer immediately to prevent timeout
            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
            
            // Check if there are multiple ticket types configured
            const ticketTypes = await db.all('SELECT * FROM ticket_types WHERE guild_id = ?', [interaction.guild.id]);
            
            if (ticketTypes.length > 0) {
                // Show category selection dropdown
                const options = ticketTypes.map(type => {
                    // Truncate description to 100 characters (Discord limit)
                    let description = type.description || 'No description';
                    if (description.length > 100) {
                        description = description.substring(0, 97) + '...';
                    }
                    
                    return {
                        label: type.type_name.substring(0, 100), // Also limit label to 100 chars
                        description: description,
                        value: type.type_name,
                        emoji: type.emoji || '🎫'
                    };
                });
                
                // Add default "General" option if not exists
                if (!options.find(opt => opt.value === 'general')) {
                    options.unshift({
                        label: 'General Support',
                        description: 'General support inquiries',
                        value: 'general',
                        emoji: '🎫'
                    });
                }
                
                const selectMenu = new StringSelectMenuBuilder()
                    .setCustomId('ticket_category_select')
                    .setPlaceholder('Select a ticket category')
                    .addOptions(options.slice(0, 25)); // Discord limit is 25 options
                
                const row = new ActionRowBuilder().addComponents(selectMenu);
                
                await interaction.editReply({
                    embeds: [new EmbedBuilder()
                        .setTitle('🎫 Create Ticket')
                        .setDescription('Please select a category for your ticket:')
                        .setColor(COLORS.PRIMARY)
                    ],
                    components: [row]
                });
            } else {
                // No categories configured, create general ticket
                
                const result = await ticketManager.createTicket(interaction.guild, interaction.user, 'general', interaction);
                
                if (result.success) {
                    await interaction.editReply({
                        embeds: [new EmbedBuilder()
                            .setTitle('🎫 Ticket Created')
                            .setDescription(`Your ticket has been created: ${result.channel}`)
                            .setColor(COLORS.SUCCESS)
                            .setTimestamp()
                        ]
                    });
                } else {
                    await interaction.editReply({
                        content: `${EMOJIS.error} ${result.error}`
                    });
                }
            }
            return;
        }
        
        // Ticket close button
        if (customId.startsWith('ticket_close_')) {
            const ticketId = parseInt(customId.replace('ticket_close_', ''));
            const ticket = await db.get('SELECT * FROM tickets WHERE ticket_id = ?', [ticketId]);
            
            if (!ticket) {
                return interaction.reply({
                    content: `${EMOJIS.error} Ticket not found!`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            const config = await ticketManager.getConfig(interaction.guild.id);
            
            // Check if user can close
            const canClose = ticket.user_id === interaction.user.id || 
                           interaction.member.permissions.has(PermissionFlagsBits.ManageChannels) ||
                           await security.isExtraOwner(interaction.guild.id, interaction.user.id);
            
            if (!canClose) {
                return interaction.reply({
                    content: `${EMOJIS.error} You don't have permission to close this ticket!`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            if (config.rating_enabled && ticket.user_id === interaction.user.id) {
                // Show rating buttons
                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder().setCustomId(`ticket_rate_${ticketId}_1`).setLabel('⭐').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId(`ticket_rate_${ticketId}_2`).setLabel('⭐⭐').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId(`ticket_rate_${ticketId}_3`).setLabel('⭐⭐⭐').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId(`ticket_rate_${ticketId}_4`).setLabel('⭐⭐⭐⭐').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId(`ticket_rate_${ticketId}_5`).setLabel('⭐⭐⭐⭐⭐').setStyle(ButtonStyle.Primary)
                    );
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle('🎫 Rate Your Experience')
                        .setDescription('Please rate your support experience before closing')
                        .setColor(COLORS.INFO)
                    ],
                    components: [row],
                    flags: [MessageFlags.Ephemeral]
                });
            } else {
                await interaction.deferReply();
                const result = await ticketManager.closeTicket(ticketId, interaction.user, 'Closed via button');
                
                if (result.success) {
                    await interaction.editReply({
                        embeds: [new EmbedBuilder()
                            .setTitle('🔒 Ticket Closing')
                            .setDescription('This ticket will be deleted in 5 seconds...')
                            .setColor(COLORS.WARNING)
                        ]
                    });
                } else {
                    await interaction.editReply({
                        content: `${EMOJIS.error} Error: ${result.error}`
                    });
                }
            }
            return;
        }
        
        // Ticket rating button
        if (customId.startsWith('ticket_rate_')) {
            const parts = customId.split('_');
            const ticketId = parseInt(parts[2]);
            const rating = parseInt(parts[3]);
            
            await interaction.deferUpdate();
            
            const result = await ticketManager.closeTicket(ticketId, interaction.user, 'Closed with rating', rating);
            
            if (result.success) {
                await interaction.editReply({
                    embeds: [new EmbedBuilder()
                        .setTitle('🔒 Ticket Closing')
                        .setDescription(`Thank you for your ${rating} star rating!\nThis ticket will be deleted in 5 seconds...`)
                        .setColor(COLORS.SUCCESS)
                    ],
                    components: []
                });
            }
            return;
        }
        
        // Ticket claim button
        if (customId.startsWith('ticket_claim_')) {
            const ticketId = parseInt(customId.replace('ticket_claim_', ''));
            const ticket = await db.get('SELECT * FROM tickets WHERE ticket_id = ?', [ticketId]);
            
            if (!ticket) {
                return interaction.reply({
                    content: `${EMOJIS.error} Ticket not found!`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            if (ticket.claimed_by) {
                return interaction.reply({
                    content: `${EMOJIS.error} This ticket is already claimed by <@${ticket.claimed_by}>`,
                    flags: [MessageFlags.Ephemeral]
                });
            }

            // Prevent the ticket creator from claiming their own ticket
            if (ticket.user_id === interaction.user.id) {
                return interaction.reply({
                    content: `${EMOJIS.error} You cannot claim your own ticket! Claiming is for support staff.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }

            // Check if user has permission to claim (support role or ManageChannels)
            const ticketConfig = await ticketManager.getConfig(interaction.guild.id);
            const typeConfig = await db.get('SELECT * FROM ticket_types WHERE guild_id = ? AND type_name = ?', [interaction.guild.id, ticket.ticket_type]);
            const supportRoleId = typeConfig?.support_role_id || ticketConfig?.support_role_id;

            const hasPermission = interaction.member.permissions.has(PermissionFlagsBits.ManageChannels) ||
                (supportRoleId && interaction.member.roles.cache.has(supportRoleId)) ||
                await security.isExtraOwner(interaction.guild.id, interaction.user.id);

            if (!hasPermission) {
                return interaction.reply({
                    content: `${EMOJIS.error} Only support staff can claim tickets.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            const result = await ticketManager.claimTicket(ticketId, interaction.user);
            
            if (result.success) {
                // Update the button row to disable claim button
                try {
                    const updatedRow = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId(`ticket_close_${ticketId}`)
                                .setLabel('Close Ticket')
                                .setStyle(ButtonStyle.Danger)
                                .setEmoji('\ud83d\udd12'),
                            new ButtonBuilder()
                                .setCustomId(`ticket_claim_${ticketId}`)
                                .setLabel(`Claimed by ${interaction.user.username}`)
                                .setStyle(ButtonStyle.Success)
                                .setEmoji('\u2705')
                                .setDisabled(true),
                            new ButtonBuilder()
                                .setCustomId(`ticket_adduser_${ticketId}`)
                                .setLabel('Add User')
                                .setStyle(ButtonStyle.Secondary)
                                .setEmoji('\u2795'),
                            new ButtonBuilder()
                                .setCustomId(`ticket_transcript_${ticketId}`)
                                .setLabel('Transcript')
                                .setStyle(ButtonStyle.Secondary)
                                .setEmoji('\ud83d\udcc4')
                        );
                    await interaction.message.edit({ components: [updatedRow] }).catch(() => {});
                } catch (e) {}

                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setDescription(`\u270b ${interaction.user} has claimed this ticket and will be assisting you!`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ]
                });
            } else {
                await interaction.reply({
                    content: `${EMOJIS.error} Error: ${result.error}`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            return;
        }
        
        // Ticket add user button
        if (customId.startsWith('ticket_adduser_')) {
            return interaction.reply({
                content: `${EMOJIS.info} Use \`/ticket add @user\` to add users to this ticket`,
                flags: [MessageFlags.Ephemeral]
            });
        }
        
        // Ticket transcript button
        if (customId.startsWith('ticket_transcript_')) {
            const ticketId = parseInt(customId.replace('ticket_transcript_', ''));
            
            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
            
            const transcriptUrl = await ticketManager.generateTranscript(ticketId, interaction.channel);
            
            if (transcriptUrl) {
                await interaction.editReply({
                    embeds: [new EmbedBuilder()
                        .setTitle('📄 Transcript Generated')
                        .setDescription(`Transcript ID: ${transcriptUrl}`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ]
                });
            } else {
                await interaction.editReply({
                    content: `${EMOJIS.error} Failed to generate transcript`
                });
            }
            return;
        }
    }
    
    // Handle select menu interactions
    if (interaction.isStringSelectMenu()) {
        const customId = interaction.customId;
        
        // Ticket category selection
        if (customId === 'ticket_category_select') {
            const selectedCategory = interaction.values[0];
            
            await interaction.deferUpdate();
            
            const result = await ticketManager.createTicket(interaction.guild, interaction.user, selectedCategory, interaction);
            
            if (result.success) {
                await interaction.editReply({
                    embeds: [new EmbedBuilder()
                        .setTitle('🎫 Ticket Created')
                        .setDescription(`Your **${selectedCategory}** ticket has been created: ${result.channel}`)
                        .addFields(
                            { name: 'Category', value: selectedCategory, inline: true },
                            { name: 'Ticket Number', value: `#${result.ticketNumber}`, inline: true }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ],
                    components: []
                });
            } else {
                await interaction.editReply({
                    content: `${EMOJIS.error} ${result.error}`,
                    components: []
                });
            }
            return;
        }
    }
    
    // Giveaway entry button
    if (interaction.isButton() && interaction.customId === 'giveaway_enter') {
        try {
            const giveaway = await db.get('SELECT * FROM giveaways WHERE message_id = ? AND ended = 0', [interaction.message.id]);
            if (!giveaway) {
                await interaction.reply({ content: 'This giveaway has ended!', flags: [MessageFlags.Ephemeral] });
                return;
            }
            
            // Check if already entered
            const existing = await db.get('SELECT 1 FROM giveaway_entrants WHERE message_id = ? AND user_id = ?', [interaction.message.id, interaction.user.id]);
            if (existing) {
                await interaction.reply({ content: 'You have already entered this giveaway!', flags: [MessageFlags.Ephemeral] });
                return;
            }
            
            // Add entrant
            await db.run(
                'INSERT INTO giveaway_entrants (message_id, user_id, entered_at) VALUES (?, ?, ?)',
                [interaction.message.id, interaction.user.id, new Date().toISOString()]
            );
            
            // Update count
            await db.run('UPDATE giveaways SET entrants_count = entrants_count + 1 WHERE message_id = ?', [interaction.message.id]);
            
            // Update embed
            const newCount = giveaway.entrants_count + 1;
            const embed = EmbedBuilder.from(interaction.message.embeds[0]);
            const fields = embed.data.fields;
            if (fields && fields.length > 0) {
                fields[1].value = newCount.toString();
                embed.setFields(fields);
            }
            
            await interaction.message.edit({ embeds: [embed] });
            await interaction.reply({ content: '✅ You have entered the giveaway! Good luck!', flags: [MessageFlags.Ephemeral] });
            
        } catch (error) {
            console.error('Error handling giveaway entry:', error);
            await interaction.reply({ content: 'An error occurred while entering the giveaway.', flags: [MessageFlags.Ephemeral] });
        }
        return;
    }
    
    // Command interactions
    if (!interaction.isChatInputCommand()) return;
    
    const { commandName, guild, user, member } = interaction;
    
    // Check if command is in a guild (not DM)
    if (!guild) {
        return interaction.reply({ 
            content: '❌ Commands can only be used in servers, not in DMs.',
            flags: [MessageFlags.Ephemeral] 
        });
    }
    
    // Handle command cooldown
    const cooldown = await security.isOnCooldown(guild.id, user.id, commandName);
    if (cooldown > 0) {
        return interaction.reply({ 
            content: `${EMOJIS.timer} Please wait ${Math.ceil(cooldown / 1000)} seconds before using this command again.`,
            flags: [MessageFlags.Ephemeral] 
        });
    }
    
    // Check permissions for specific commands
    const ownerCommands = ['extraowner', 'antinukeconfig', 'autorole', 'stickyroles', 'verifyconfig', 'starboardconfig', 'autopublishconfig'];
    const adminCommands = ['welcome', 'goodbye', 'customcommand', 'giveaway', 'statusmonitor', 'suggestionconfig', 'announce', 'embed', 'serverstats', 'dm'];
    const modCommands = ['ban', 'kick', 'timeout', 'warn', 'purge', 'addrole', 'removerole', 'massrole'];
    
    if (ownerCommands.includes(commandName)) {
        const isOwner = guild.ownerId === user.id;
        const isExtraOwner = await security.isExtraOwner(guild.id, user.id);
        if (!isOwner && !isExtraOwner) {
            return interaction.reply({ 
                content: `${EMOJIS.error} Only server owner or extra owners can use this command.`,
                flags: [MessageFlags.Ephemeral] 
            });
        }
    }
    
    if (adminCommands.includes(commandName) && !member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        return interaction.reply({ 
            content: `${EMOJIS.error} You need Manage Server permission to use this command.`,
            flags: [MessageFlags.Ephemeral] 
        });
    }
    
    if (modCommands.includes(commandName)) {
        if (commandName === 'ban' && !member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return interaction.reply({ 
                content: `${EMOJIS.error} You need Ban Members permission to use this command.`,
                flags: [MessageFlags.Ephemeral] 
            });
        }
        if (commandName === 'kick' && !member.permissions.has(PermissionFlagsBits.KickMembers)) {
            return interaction.reply({ 
                content: `${EMOJIS.error} You need Kick Members permission to use this command.`,
                flags: [MessageFlags.Ephemeral] 
            });
        }
        if ((commandName === 'timeout' || commandName === 'warn') && !member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
            return interaction.reply({ 
                content: `${EMOJIS.error} You need Moderate Members permission to use this command.`,
                flags: [MessageFlags.Ephemeral] 
            });
        }
        if (commandName === 'purge' && !member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return interaction.reply({ 
                content: `${EMOJIS.error} You need Manage Messages permission to use this command.`,
                flags: [MessageFlags.Ephemeral] 
            });
        }
        if ((commandName === 'addrole' || commandName === 'removerole' || commandName === 'massrole') && !member.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return interaction.reply({ 
                content: `${EMOJIS.error} You need Manage Roles permission to use this command.`,
                flags: [MessageFlags.Ephemeral] 
            });
        }
    }
    
    // Check for super admin commands
    if (['superadmin', 'botconfig'].includes(commandName)) {
        if (!configManager.isSuperAdmin(user.id)) {
            return interaction.reply({ 
                content: `${EMOJIS.error} Only super admins can use this command.`,
                flags: [MessageFlags.Ephemeral] 
            });
        }
    }
    
    // Handle commands
    try {
        // Super Admin Commands
        if (commandName === 'superadmin') {
            const subcommand = interaction.options.getSubcommand();
            
            if (subcommand === 'add') {
                const target = interaction.options.getUser('user');
                const added = configManager.addSuperAdmin(target.id);
                
                if (added) {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle(`${EMOJIS.success} Super Admin Added`)
                            .setDescription(`${target.tag} (${target.id}) has been added as a super admin.`)
                            .setColor(COLORS.SUCCESS)
                            .setTimestamp()
                        ]
                    });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} User is already a super admin.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
            } else if (subcommand === 'remove') {
                const target = interaction.options.getUser('user');
                const removed = configManager.removeSuperAdmin(target.id);
                
                if (removed) {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle(`${EMOJIS.success} Super Admin Removed`)
                            .setDescription(`${target.tag} (${target.id}) has been removed from super admins.`)
                            .setColor(COLORS.WARNING)
                            .setTimestamp()
                        ]
                    });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} User is not a super admin or is the bot owner.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
            } else if (subcommand === 'list') {
                const superAdmins = config.SUPER_ADMINS;
                const adminList = superAdmins.length > 0 
                    ? superAdmins.map(id => `<@${id}>`).join('\n')
                    : 'No super admins configured.';
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.crown} Super Admins`)
                        .setDescription(adminList)
                        .setColor(COLORS.PRIMARY)
                        .setFooter({ text: `Total: ${superAdmins.length}` })
                        .setTimestamp()
                    ]
                });
            }
            
        } else if (commandName === 'extraowner') {
            const subcommand = interaction.options.getSubcommand();
            
            if (subcommand === 'add') {
                const target = interaction.options.getUser('user');
                await db.run(
                    'INSERT OR REPLACE INTO extra_owners (guild_id, user_id, added_by, added_at) VALUES (?, ?, ?, ?)',
                    [guild.id, target.id, user.id, new Date().toISOString()]
                );
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Extra Owner Added`)
                        .setDescription(`${target.tag} is now an extra owner.`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ]
                });
                
            } else if (subcommand === 'remove') {
                const target = interaction.options.getUser('user');
                await db.run('DELETE FROM extra_owners WHERE guild_id = ? AND user_id = ?', [guild.id, target.id]);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Extra Owner Removed`)
                        .setDescription(`${target.tag} removed from extra owners.`)
                        .setColor(COLORS.WARNING)
                        .setTimestamp()
                    ]
                });
                
            } else if (subcommand === 'list') {
                const extraOwners = await db.all('SELECT user_id FROM extra_owners WHERE guild_id = ?', [guild.id]);
                const ownerList = extraOwners.length > 0
                    ? extraOwners.map(o => `<@${o.user_id}>`).join('\n')
                    : 'No extra owners.';
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.crown} Extra Owners`)
                        .setDescription(ownerList)
                        .setColor(COLORS.PRIMARY)
                        .setFooter({ text: `Total: ${extraOwners.length}` })
                        .setTimestamp()
                    ]
                });
            }
            
        } else if (commandName === 'botconfig') {
            const subcommand = interaction.options.getSubcommand();
            
            if (subcommand === 'status') {
                const status = interaction.options.getString('status');
                const activity = interaction.options.getString('activity');
                const type = interaction.options.getString('type');
                
                client.user.setPresence({
                    status: status,
                    activities: [{
                        name: activity,
                        type: ActivityType[type]
                    }]
                });
                
                // Update config
                config.BOT_STATUS = status;
                config.BOT_ACTIVITY_NAME = activity;
                config.BOT_ACTIVITY_TYPE = Object.keys(ActivityType).indexOf(type);
                configManager.saveConfig();
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Bot Status Updated`)
                        .setDescription(`Status: **${status}**\nActivity: **${activity}**\nType: **${type}**`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ]
                });
                
            } else if (subcommand === 'watermark') {
                const text = interaction.options.getString('text');
                config.BOT_WATERMARK = text;
                configManager.saveConfig();
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Watermark Updated`)
                        .setDescription(`New watermark: **${text}**`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ]
                });
            }
            
        } else if (commandName === 'antinuke') {
            const subcommand = interaction.options.getSubcommand();
            
            if (subcommand === 'enable' || subcommand === 'disable') {
                const enabled = subcommand === 'enable' ? 1 : 0;
                await db.run('UPDATE antinuke_config SET enabled = ? WHERE guild_id = ?', [enabled, guild.id]);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.shield} Anti-Nuke ${subcommand === 'enable' ? 'Enabled' : 'Disabled'}`)
                        .setDescription(`The anti-nuke system has been ${subcommand === 'enable' ? 'enabled' : 'disabled'}.`)
                        .setColor(subcommand === 'enable' ? COLORS.SUCCESS : COLORS.WARNING)
                        .setTimestamp()
                    ]
                });
                
            } else if (subcommand === 'config') {
                const punishment = interaction.options.getString('punishment');
                const logChannel = interaction.options.getChannel('log_channel');
                const autoRevert = interaction.options.getBoolean('auto_revert');
                const alertThreshold = interaction.options.getInteger('alert_threshold');
                
                let updates = [];
                let params = [];
                
                if (punishment) {
                    updates.push('punishment = ?');
                    params.push(punishment);
                }
                if (logChannel) {
                    updates.push('log_channel_id = ?');
                    params.push(logChannel.id);
                }
                if (autoRevert !== null) {
                    updates.push('revert_actions = ?');
                    params.push(autoRevert ? 1 : 0);
                }
                if (alertThreshold) {
                    updates.push('alert_threshold = ?');
                    params.push(alertThreshold);
                }
                
                if (updates.length > 0) {
                    params.push(guild.id);
                    await db.run(`UPDATE antinuke_config SET ${updates.join(', ')} WHERE guild_id = ?`, params);
                }
                
                const config = await security.getAntiNukeConfig(guild.id);
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.shield} Anti-Nuke Configuration`)
                    .setColor(COLORS.INFO)
                    .addFields(
                        { name: 'Status', value: config.enabled ? 'Enabled' : 'Disabled', inline: true },
                        { name: 'Punishment', value: config.punishment || 'ban', inline: true },
                        { name: 'Auto Revert', value: config.revert_actions ? 'Yes' : 'No', inline: true },
                        { name: 'Alert Threshold', value: (config.alert_threshold || 2).toString(), inline: true },
                        { name: 'Log Channel', value: config.log_channel_id ? `<#${config.log_channel_id}>` : 'Not set', inline: true }
                    )
                    .setTimestamp();
                
                await interaction.reply({ embeds: [embed] });
                
            } else if (subcommand === 'whitelist') {
                const action = interaction.options.getString('action');
                const targetUser = interaction.options.getUser('user');
                
                if (action === 'add' || action === 'remove') {
                    if (!targetUser) {
                        await interaction.reply({
                            content: `${EMOJIS.error} Please specify a user.`,
                            flags: [MessageFlags.Ephemeral]
                        });
                        return;
                    }
                    
                    if (action === 'add') {
                        await db.run(
                            'INSERT OR REPLACE INTO antinuke_whitelist (guild_id, user_id, added_by, added_at) VALUES (?, ?, ?, ?)',
                            [guild.id, targetUser.id, user.id, new Date().toISOString()]
                        );
                        
                        await interaction.reply({
                            embeds: [new EmbedBuilder()
                                .setTitle(`${EMOJIS.success} User Whitelisted`)
                                .setDescription(`${targetUser.tag} has been added to the anti-nuke whitelist.`)
                                .setColor(COLORS.SUCCESS)
                                .setTimestamp()
                            ]
                        });
                    } else {
                        await db.run('DELETE FROM antinuke_whitelist WHERE guild_id = ? AND user_id = ?', [guild.id, targetUser.id]);
                        
                        await interaction.reply({
                            embeds: [new EmbedBuilder()
                                .setTitle(`${EMOJIS.success} User Removed from Whitelist`)
                                .setDescription(`${targetUser.tag} has been removed from the anti-nuke whitelist.`)
                                .setColor(COLORS.WARNING)
                                .setTimestamp()
                            ]
                        });
                    }
                    
                } else if (action === 'list') {
                    const whitelisted = await db.all('SELECT user_id FROM antinuke_whitelist WHERE guild_id = ?', [guild.id]);
                    
                    const list = whitelisted.length > 0
                        ? whitelisted.map(w => `<@${w.user_id}>`).join('\n')
                        : 'No users whitelisted.';
                    
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle(`${EMOJIS.shield} Anti-Nuke Whitelist`)
                            .setDescription(list)
                            .setColor(COLORS.INFO)
                            .setFooter({ text: `Total: ${whitelisted.length}` })
                            .setTimestamp()
                        ]
                    });
                }
                
            } else if (subcommand === 'logs') {
                const limit = interaction.options.getInteger('limit') || 10;
                const logs = await db.all(
                    'SELECT * FROM antinuke_logs WHERE guild_id = ? ORDER BY timestamp DESC LIMIT ?',
                    [guild.id, limit]
                );
                
                if (logs.length === 0) {
                    await interaction.reply({
                        content: `${EMOJIS.info} No anti-nuke logs found.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                    return;
                }
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.shield} Anti-Nuke Logs`)
                    .setColor(COLORS.INFO)
                    .setTimestamp();
                
                logs.forEach(log => {
                    const prevented = log.prevented ? '🟢' : '🔴';
                    embed.addFields({
                        name: `${prevented} ${log.action_type} - <t:${Math.floor(new Date(log.timestamp).getTime() / 1000)}:R>`,
                        value: `User: <@${log.user_id}>\nDetails: ${log.details || 'No details'}`,
                        inline: false
                    });
                });
                
                await interaction.reply({ embeds: [embed] });
            }
            
        } else if (commandName === 'antispam') {
            const subcommand = interaction.options.getSubcommand();
            
            if (subcommand === 'enable' || subcommand === 'disable') {
                const enabled = subcommand === 'enable' ? 1 : 0;
                await db.run('UPDATE antispam_config SET enabled = ? WHERE guild_id = ?', [enabled, guild.id]);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.shield} Anti-Spam ${subcommand === 'enable' ? 'Enabled' : 'Disabled'}`)
                        .setDescription(`The anti-spam system has been ${subcommand === 'enable' ? 'enabled' : 'disabled'}.`)
                        .setColor(subcommand === 'enable' ? COLORS.SUCCESS : COLORS.WARNING)
                        .setTimestamp()
                    ]
                });
                
            } else if (subcommand === 'config') {
                const punishment = interaction.options.getString('punishment');
                const messageThreshold = interaction.options.getInteger('message_threshold');
                const timeWindow = interaction.options.getInteger('time_window');
                const duplicateThreshold = interaction.options.getInteger('duplicate_threshold');
                const mentionThreshold = interaction.options.getInteger('mention_threshold');
                const linkThreshold = interaction.options.getInteger('link_threshold');
                const warnFirst = interaction.options.getBoolean('warn_first');
                
                let updates = [];
                let params = [];
                
                if (punishment) {
                    updates.push('punishment = ?');
                    params.push(punishment);
                }
                if (messageThreshold) {
                    updates.push('message_threshold = ?');
                    params.push(messageThreshold);
                }
                if (timeWindow) {
                    updates.push('time_window = ?');
                    params.push(timeWindow * 1000); // Convert to ms
                }
                if (duplicateThreshold) {
                    updates.push('duplicate_threshold = ?');
                    params.push(duplicateThreshold);
                }
                if (mentionThreshold) {
                    updates.push('mention_threshold = ?');
                    params.push(mentionThreshold);
                }
                if (linkThreshold) {
                    updates.push('link_threshold = ?');
                    params.push(linkThreshold);
                }
                if (warnFirst !== null) {
                    updates.push('warn_before_punish = ?');
                    params.push(warnFirst ? 1 : 0);
                }
                
                if (updates.length > 0) {
                    params.push(guild.id);
                    await db.run(`UPDATE antispam_config SET ${updates.join(', ')} WHERE guild_id = ?`, params);
                }
                
                const config = await security.getAntiSpamConfig(guild.id);
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.shield} Anti-Spam Configuration`)
                    .setColor(COLORS.INFO)
                    .addFields(
                        { name: 'Status', value: config.enabled ? 'Enabled' : 'Disabled', inline: true },
                        { name: 'Punishment', value: config.punishment || 'timeout', inline: true },
                        { name: 'Message Threshold', value: (config.message_threshold || 5).toString(), inline: true },
                        { name: 'Time Window', value: `${(config.time_window || 5000) / 1000}s`, inline: true },
                        { name: 'Duplicate Threshold', value: (config.duplicate_threshold || 3).toString(), inline: true },
                        { name: 'Mention Threshold', value: (config.mention_threshold || 5).toString(), inline: true },
                        { name: 'Link Threshold', value: (config.link_threshold || 2).toString(), inline: true },
                        { name: 'Warn First', value: config.warn_before_punish ? 'Yes' : 'No', inline: true }
                    )
                    .setTimestamp();
                
                await interaction.reply({ embeds: [embed] });
            }
            
        } else if (commandName === 'badwords') {
            const subcommand = interaction.options.getSubcommand();
            const config = await security.getBadWordsConfig(guild.id);
            
            if (subcommand === 'enable' || subcommand === 'disable') {
                const enabled = subcommand === 'enable' ? 1 : 0;
                await db.run('UPDATE bad_words_config SET enabled = ? WHERE guild_id = ?', [enabled, guild.id]);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.shield} Bad Words Filter ${subcommand === 'enable' ? 'Enabled' : 'Disabled'}`)
                        .setDescription(`The bad words filter has been ${subcommand === 'enable' ? 'enabled' : 'disabled'}.`)
                        .setColor(subcommand === 'enable' ? COLORS.SUCCESS : COLORS.WARNING)
                        .setTimestamp()
                    ]
                });
                
            } else if (subcommand === 'add') {
                const wordsInput = interaction.options.getString('words');
                const wordsToAdd = wordsInput.split(',').map(w => w.trim().toLowerCase()).filter(w => w);
                
                const currentWords = config.words || [];
                const newWords = [...new Set([...currentWords, ...wordsToAdd])];
                
                await db.run('UPDATE bad_words_config SET words = ? WHERE guild_id = ?', [JSON.stringify(newWords), guild.id]);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Bad Words Added`)
                        .setDescription(`Added ${wordsToAdd.length} word(s) to the filter.\n\n**Added:** ${wordsToAdd.join(', ')}`)
                        .setColor(COLORS.SUCCESS)
                        .setFooter({ text: `Total: ${newWords.length} words` })
                        .setTimestamp()
                    ]
                });
                
            } else if (subcommand === 'remove') {
                const removeAll = interaction.options.getBoolean('all');
                const wordsInput = interaction.options.getString('words');
                
                if (removeAll) {
                    await db.run('UPDATE bad_words_config SET words = ? WHERE guild_id = ?', [JSON.stringify([]), guild.id]);
                    
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle(`${EMOJIS.success} All Bad Words Removed`)
                            .setDescription('All words have been removed from the filter.')
                            .setColor(COLORS.WARNING)
                            .setTimestamp()
                        ]
                    });
                } else {
                    const wordsToRemove = wordsInput.split(',').map(w => w.trim().toLowerCase()).filter(w => w);
                    const currentWords = config.words || [];
                    const newWords = currentWords.filter(w => !wordsToRemove.includes(w));
                    
                    await db.run('UPDATE bad_words_config SET words = ? WHERE guild_id = ?', [JSON.stringify(newWords), guild.id]);
                    
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle(`${EMOJIS.success} Bad Words Removed`)
                            .setDescription(`Removed ${wordsToRemove.length} word(s) from the filter.\n\n**Removed:** ${wordsToRemove.join(', ')}`)
                            .setColor(COLORS.WARNING)
                            .setFooter({ text: `Total: ${newWords.length} words` })
                            .setTimestamp()
                        ]
                    });
                }
                
            } else if (subcommand === 'list') {
                const words = config.words || [];
                
                if (words.length === 0) {
                    await interaction.reply({
                        content: `${EMOJIS.info} No bad words configured.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                    return;
                }
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.shield} Bad Words List`)
                    .setDescription(words.join(', '))
                    .setColor(COLORS.INFO)
                    .setFooter({ text: `Total: ${words.length} words` })
                    .setTimestamp();
                
                await interaction.reply({ embeds: [embed] });
                
            } else if (subcommand === 'config') {
                const action = interaction.options.getString('action');
                const warningMessage = interaction.options.getString('warning_message');
                
                let updates = [];
                let params = [];
                
                if (action) {
                    updates.push('action = ?');
                    params.push(action);
                }
                if (warningMessage) {
                    updates.push('custom_message = ?');
                    params.push(warningMessage);
                }
                
                if (updates.length > 0) {
                    params.push(guild.id);
                    await db.run(`UPDATE bad_words_config SET ${updates.join(', ')} WHERE guild_id = ?`, params);
                }
                
                const updatedConfig = await security.getBadWordsConfig(guild.id);
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.shield} Bad Words Configuration`)
                    .setColor(COLORS.INFO)
                    .addFields(
                        { name: 'Status', value: updatedConfig.enabled ? 'Enabled' : 'Disabled', inline: true },
                        { name: 'Action', value: updatedConfig.action || 'delete', inline: true },
                        { name: 'Warning Message', value: updatedConfig.custom_message || 'Watch your language!', inline: true },
                        { name: 'Total Words', value: (updatedConfig.words?.length || 0).toString(), inline: true }
                    )
                    .setTimestamp();
                
                await interaction.reply({ embeds: [embed] });
            }
            
        } else if (commandName === 'welcome') {
            const subcommand = interaction.options.getSubcommand();
            
            if (subcommand === 'enable' || subcommand === 'disable') {
                const enabled = subcommand === 'enable' ? 1 : 0;
                const updatedConfig = await welcomeGoodbye.updateWelcomeConfig(guild.id, { enabled });
                const needsChannel = enabled && !updatedConfig.channel_id && !welcomeGoodbye.isEnabled(updatedConfig.dm_enabled);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Welcome Messages ${subcommand === 'enable' ? 'Enabled' : 'Disabled'}`)
                        .setDescription(needsChannel
                            ? 'Welcome messages are enabled, but no welcome channel or DM is configured yet. Use `/welcome config` or `/welcome dm` next.'
                            : `Welcome messages have been ${subcommand === 'enable' ? 'enabled' : 'disabled'}.`)
                        .setColor(subcommand === 'enable' ? COLORS.SUCCESS : COLORS.WARNING)
                        .setTimestamp()
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'config') {
                const channel = interaction.options.getChannel('channel');
                const message = interaction.options.getString('message');
                const color = interaction.options.getString('color');
                const useEmbed = interaction.options.getBoolean('embed');
                const pingUser = interaction.options.getBoolean('ping');

                if (!channel || !channel.isTextBased()) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Please choose a text or announcement channel for welcome messages.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                const normalizedColor = color ? welcomeGoodbye.normalizeHexColor(color, null) : null;
                if (color && !normalizedColor) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Invalid color. Use a 6-digit hex color like \`#57F287\`.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const updates = {
                    channel_id: channel.id,
                    enabled: 1
                };
                
                if (message !== null) updates.message = message;
                if (normalizedColor) updates.embed_color = normalizedColor;
                if (useEmbed !== null) updates.embed_enabled = useEmbed ? 1 : 0;
                if (pingUser !== null) updates.ping_user = pingUser ? 1 : 0;
                
                const config = await welcomeGoodbye.updateWelcomeConfig(guild.id, updates);
                const preview = welcomeGoodbye.truncate(
                    welcomeGoodbye.formatMessage(config.message || 'Welcome {user} to **{server}**!', member),
                    900
                );
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.success} Welcome Configuration Updated`)
                    .setColor(COLORS.SUCCESS)
                    .addFields(
                        { name: '✅ Status', value: 'Enabled', inline: true },
                        { name: '📢 Channel', value: `<#${config.channel_id}>`, inline: true },
                        { name: '📝 Use Embed', value: welcomeGoodbye.isEnabled(config.embed_enabled) ? 'Yes' : 'No', inline: true },
                        { name: '🔔 Ping User', value: welcomeGoodbye.isEnabled(config.ping_user) ? 'Yes' : 'No', inline: true },
                        { name: '🎨 Embed Color', value: config.embed_color || '#57F287', inline: true },
                        { name: '💬 DM Enabled', value: welcomeGoodbye.isEnabled(config.dm_enabled) ? 'Yes' : 'No', inline: true }
                    )
                    .setDescription(`**Message Preview:**\n${preview}`)
                    .setTimestamp()
                    .setFooter({ text: 'Use /welcome dm, /welcome image, /welcome advanced for more options' });
                
                await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
                
            } else if (subcommand === 'dm') {
                const enabled = interaction.options.getBoolean('enabled');
                const dmMessage = interaction.options.getString('message');
                
                const updates = { dm_enabled: enabled ? 1 : 0 };
                if (dmMessage !== null) updates.dm_message = dmMessage;
                const config = await welcomeGoodbye.updateWelcomeConfig(guild.id, updates);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Welcome DM ${enabled ? 'Enabled' : 'Disabled'}`)
                        .setDescription(enabled ? 
                            `New members will receive a DM when they join.\n\n**DM Message:**\n${welcomeGoodbye.truncate(config.dm_message || 'Welcome to **{server}**!', 900)}` :
                            'Welcome DMs have been disabled.')
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'image') {
                const imageUrl = interaction.options.getString('url');
                const thumbnail = interaction.options.getString('thumbnail');
                const parsedImage = welcomeGoodbye.normalizeImageUrlInput(imageUrl);
                
                if (parsedImage.error) {
                    return interaction.reply({
                        content: `${EMOJIS.error} ${parsedImage.error}`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                const updates = {};
                if (parsedImage.touched) updates.image_url = parsedImage.value;
                if (thumbnail !== null) updates.thumbnail_type = thumbnail;

                const config = Object.keys(updates).length > 0
                    ? await welcomeGoodbye.updateWelcomeConfig(guild.id, updates)
                    : await welcomeGoodbye.getWelcomeConfig(guild.id);

                if (Object.keys(updates).length === 0) {
                    return interaction.reply({
                        content: `${EMOJIS.info} No welcome image settings were changed.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Welcome Image Settings Updated`)
                        .setDescription(config.image_url ? 
                            `Banner image set to: ${config.image_url}` :
                            'Banner image removed')
                        .addFields(
                            { name: 'Thumbnail Type', value: config.thumbnail_type || 'avatar', inline: true }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'advanced') {
                const rulesChannel = interaction.options.getChannel('rules_channel');
                const showRules = interaction.options.getBoolean('show_rules');
                const showInviteInfo = interaction.options.getBoolean('show_invite_info');

                if (rulesChannel && !rulesChannel.isTextBased()) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Please choose a text or announcement channel for rules.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const updates = {};
                if (rulesChannel) updates.rules_channel_id = rulesChannel.id;
                if (showRules !== null) updates.show_rules = showRules ? 1 : 0;
                if (showInviteInfo !== null) updates.show_invite_info = showInviteInfo ? 1 : 0;
                
                const config = Object.keys(updates).length > 0
                    ? await welcomeGoodbye.updateWelcomeConfig(guild.id, updates)
                    : await welcomeGoodbye.getWelcomeConfig(guild.id);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Advanced Settings Updated`)
                        .addFields(
                            { name: '📜 Show Rules', value: welcomeGoodbye.isEnabled(config.show_rules) ? 'Yes' : 'No', inline: true },
                            { name: '📜 Rules Channel', value: config.rules_channel_id ? `<#${config.rules_channel_id}>` : 'Not set', inline: true },
                            { name: '🎫 Show Invite Info', value: welcomeGoodbye.isEnabled(config.show_invite_info) ? 'Yes' : 'No', inline: true }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'test') {
                await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
                const result = await welcomeGoodbye.sendWelcomeMessage(member, { force: true });
                const lines = [];

                if (result.channelSent) {
                    lines.push(`${EMOJIS.success} Welcome channel test sent.`);
                } else if (!result.channelConfigured) {
                    lines.push(`${EMOJIS.warning} No welcome channel configured. Use \`/welcome config\` first.`);
                } else if (!result.channelAvailable) {
                    lines.push(`${EMOJIS.error} Welcome channel is missing or the bot lacks View Channel / Send Messages permission.`);
                } else {
                    lines.push(`${EMOJIS.error} Welcome channel test could not be sent.`);
                }

                if (result.dmEnabled) {
                    lines.push(result.dmSent
                        ? `${EMOJIS.success} Welcome DM test sent.`
                        : `${EMOJIS.warning} Welcome DM is enabled, but it was not sent: ${welcomeGoodbye.getDMFailureText(result.dmReason)}`);
                }

                await interaction.editReply({ content: lines.join('\n') });
            }
            
        } else if (commandName === 'goodbye') {
            const subcommand = interaction.options.getSubcommand();
            
            if (subcommand === 'enable' || subcommand === 'disable') {
                const enabled = subcommand === 'enable' ? 1 : 0;
                const updatedConfig = await welcomeGoodbye.updateGoodbyeConfig(guild.id, { enabled });
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Goodbye Messages ${subcommand === 'enable' ? 'Enabled' : 'Disabled'}`)
                        .setDescription(enabled && !updatedConfig.channel_id
                            ? 'Goodbye messages are enabled, but no goodbye channel is configured yet. Use `/goodbye config` next.'
                            : `Goodbye messages have been ${subcommand === 'enable' ? 'enabled' : 'disabled'}.`)
                        .setColor(subcommand === 'enable' ? COLORS.SUCCESS : COLORS.WARNING)
                        .setTimestamp()
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'config') {
                const channel = interaction.options.getChannel('channel');
                const message = interaction.options.getString('message');
                const color = interaction.options.getString('color');
                const useEmbed = interaction.options.getBoolean('embed');
                const showStats = interaction.options.getBoolean('show_stats');

                if (!channel || !channel.isTextBased()) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Please choose a text or announcement channel for goodbye messages.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                const normalizedColor = color ? welcomeGoodbye.normalizeHexColor(color, null) : null;
                if (color && !normalizedColor) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Invalid color. Use a 6-digit hex color like \`#ED4245\`.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const updates = {
                    channel_id: channel.id,
                    enabled: 1
                };
                
                if (message !== null) updates.message = message;
                if (normalizedColor) updates.embed_color = normalizedColor;
                if (useEmbed !== null) updates.embed_enabled = useEmbed ? 1 : 0;
                if (showStats !== null) updates.show_stats = showStats ? 1 : 0;
                
                const config = await welcomeGoodbye.updateGoodbyeConfig(guild.id, updates);
                const preview = welcomeGoodbye.truncate(
                    welcomeGoodbye.formatMessage(config.message || '**{tag}** has left the server.', member),
                    900
                );
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.success} Goodbye Configuration Updated`)
                    .setColor(COLORS.SUCCESS)
                    .addFields(
                        { name: '✅ Status', value: 'Enabled', inline: true },
                        { name: '📢 Channel', value: `<#${config.channel_id}>`, inline: true },
                        { name: '📝 Use Embed', value: welcomeGoodbye.isEnabled(config.embed_enabled) ? 'Yes' : 'No', inline: true },
                        { name: '📊 Show Stats', value: welcomeGoodbye.isEnabled(config.show_stats) ? 'Yes' : 'No', inline: true },
                        { name: '🎨 Embed Color', value: config.embed_color || '#ED4245', inline: true }
                    )
                    .setDescription(`**Message Preview:**\n${preview}`)
                    .setTimestamp()
                    .setFooter({ text: 'Use /goodbye image for more options' });
                
                await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
                
            } else if (subcommand === 'image') {
                const imageUrl = interaction.options.getString('url');
                const thumbnail = interaction.options.getString('thumbnail');
                const parsedImage = welcomeGoodbye.normalizeImageUrlInput(imageUrl);
                
                if (parsedImage.error) {
                    return interaction.reply({
                        content: `${EMOJIS.error} ${parsedImage.error}`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                const updates = {};
                if (parsedImage.touched) updates.image_url = parsedImage.value;
                if (thumbnail !== null) updates.thumbnail_type = thumbnail;

                const config = Object.keys(updates).length > 0
                    ? await welcomeGoodbye.updateGoodbyeConfig(guild.id, updates)
                    : await welcomeGoodbye.getGoodbyeConfig(guild.id);

                if (Object.keys(updates).length === 0) {
                    return interaction.reply({
                        content: `${EMOJIS.info} No goodbye image settings were changed.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Goodbye Image Settings Updated`)
                        .setDescription(config.image_url ? 
                            `Banner image set to: ${config.image_url}` :
                            'Banner image removed')
                        .addFields(
                            { name: 'Thumbnail Type', value: config.thumbnail_type || 'avatar', inline: true }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'test') {
                await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
                const result = await welcomeGoodbye.sendGoodbyeMessage(member, { force: true });
                const lines = [];

                if (result.channelSent) {
                    lines.push(`${EMOJIS.success} Goodbye channel test sent.`);
                } else if (!result.channelConfigured) {
                    lines.push(`${EMOJIS.warning} No goodbye channel configured. Use \`/goodbye config\` first.`);
                } else if (!result.channelAvailable) {
                    lines.push(`${EMOJIS.error} Goodbye channel is missing or the bot lacks View Channel / Send Messages permission.`);
                } else {
                    lines.push(`${EMOJIS.error} Goodbye channel test could not be sent.`);
                }

                await interaction.editReply({ content: lines.join('\n') });
            }
            
        } else if (commandName === 'customcommand') {
            const subcommand = interaction.options.getSubcommand();
            
            if (subcommand === 'add') {
                const trigger = interaction.options.getString('trigger').toLowerCase();
                const response = interaction.options.getString('response');
                
                const success = await customCommands.addCommand(guild.id, trigger, response, user.id);
                
                if (success) {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle(`${EMOJIS.success} Custom Command Added`)
                            .setDescription(`Command **${trigger}** has been added.`)
                            .addFields(
                                { name: 'Trigger', value: trigger, inline: true },
                                { name: 'Response', value: response.substring(0, 100) + (response.length > 100 ? '...' : ''), inline: false }
                            )
                            .setColor(COLORS.SUCCESS)
                            .setTimestamp()
                        ]
                    });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} Failed to add command.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
            } else if (subcommand === 'remove') {
                const trigger = interaction.options.getString('trigger').toLowerCase();
                
                const success = await customCommands.removeCommand(guild.id, trigger);
                
                if (success) {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle(`${EMOJIS.success} Custom Command Removed`)
                            .setDescription(`Command **${trigger}** has been removed.`)
                            .setColor(COLORS.WARNING)
                            .setTimestamp()
                        ]
                    });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} Failed to remove command or command not found.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
            } else if (subcommand === 'list') {
                const commands = await customCommands.getCommands(guild.id);
                const commandList = Array.from(commands.entries());
                
                if (commandList.length === 0) {
                    await interaction.reply({
                        content: `${EMOJIS.info} No custom commands configured.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                    return;
                }
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.gear} Custom Commands`)
                    .setColor(COLORS.INFO)
                    .setTimestamp();
                
                commandList.forEach(([trigger, cmd]) => {
                    embed.addFields({
                        name: trigger,
                        value: `**Response:** ${cmd.response.substring(0, 100)}${cmd.response.length > 100 ? '...' : ''}\n**Uses:** ${cmd.uses || 0}\n**Creator:** <@${cmd.creatorId}>`,
                        inline: false
                    });
                });
                
                await interaction.reply({ embeds: [embed] });
                
            } else if (subcommand === 'edit') {
                const trigger = interaction.options.getString('trigger').toLowerCase();
                const response = interaction.options.getString('response');
                
                const success = await customCommands.addCommand(guild.id, trigger, response, user.id);
                
                if (success) {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle(`${EMOJIS.success} Custom Command Updated`)
                            .setDescription(`Command **${trigger}** has been updated.`)
                            .addFields(
                                { name: 'New Response', value: response.substring(0, 100) + (response.length > 100 ? '...' : ''), inline: false }
                            )
                            .setColor(COLORS.SUCCESS)
                            .setTimestamp()
                        ]
                    });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} Failed to update command.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
            }
            
        } else if (commandName === 'giveaway') {
            const subcommand = interaction.options.getSubcommand();
            
            if (subcommand === 'start') {
                const prize = interaction.options.getString('prize');
                const duration = interaction.options.getString('duration');
                const winners = interaction.options.getInteger('winners');
                const channel = interaction.options.getChannel('channel');
                
                const result = await giveawayManager.startGiveaway(interaction, prize, duration, winners, channel);
                
                if (result.success) {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle(`${EMOJIS.success} Giveaway Started`)
                            .setDescription(`A new giveaway has been started!\n**Prize:** ${prize}\n**Winners:** ${winners}\n**Duration:** ${duration}`)
                            .setColor(COLORS.SUCCESS)
                            .setTimestamp()
                        ],
                        flags: [MessageFlags.Ephemeral]
                    });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} Failed to start giveaway: ${result.error}`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
            } else if (subcommand === 'end') {
                const messageId = interaction.options.getString('message_id');
                await giveawayManager.endGiveaway(guild.id, messageId);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Giveaway Ended`)
                        .setDescription('The giveaway has been ended early.')
                        .setColor(COLORS.WARNING)
                        .setTimestamp()
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'reroll') {
                const messageId = interaction.options.getString('message_id');
                const result = await giveawayManager.rerollGiveaway(guild.id, messageId);
                
                if (result.success) {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle(`${EMOJIS.success} Giveaway Rerolled`)
                            .setDescription(`New winners: ${result.winners}`)
                            .setColor(COLORS.SUCCESS)
                            .setTimestamp()
                        ],
                        flags: [MessageFlags.Ephemeral]
                    });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} Failed to reroll giveaway: ${result.error}`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
            } else if (subcommand === 'list') {
                const giveaways = await db.all('SELECT * FROM giveaways WHERE guild_id = ? AND ended = 0 ORDER BY end_time ASC', [guild.id]);
                
                if (giveaways.length === 0) {
                    await interaction.reply({
                        content: `${EMOJIS.info} No active giveaways.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                    return;
                }
                
                const embed = new EmbedBuilder()
                    .setTitle('🎉 Active Giveaways')
                    .setColor(COLORS.INFO)
                    .setTimestamp();
                
                giveaways.forEach(g => {
                    const endsAt = Math.floor(new Date(g.end_time).getTime() / 1000);
                    embed.addFields({
                        name: g.prize,
                        value: `**Winners:** ${g.winners}\n**Entries:** ${g.entrants_count}\n**Ends:** <t:${endsAt}:R> (<t:${endsAt}:F>)\n**ID:** ${g.message_id}`,
                        inline: false
                    });
                });
                
                await interaction.reply({ embeds: [embed] });
            }
            
        } else if (commandName === 'statusmonitor') {
            const subcommand = interaction.options.getSubcommand();
            
            if (subcommand === 'add') {
                const url = interaction.options.getString('url');
                const channel = interaction.options.getChannel('channel');
                const name = interaction.options.getString('name');
                const interval = interaction.options.getInteger('interval');
                
                // Validate URL
                if (!url.startsWith('http://') && !url.startsWith('https://')) {
                    return await interaction.reply({
                        content: `${EMOJIS.error} URL must start with http:// or https://`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                // Validate channel is text-based
                if (!channel.isTextBased()) {
                    return await interaction.reply({
                        content: `${EMOJIS.error} Please select a text channel.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const checkInterval = interval ? interval * 60000 : 300000; // Convert minutes to ms
                
                await db.run(
                    `INSERT OR REPLACE INTO status_monitors 
                    (guild_id, url, channel_id, name, last_status, last_check, check_interval, uptime_start, total_checks, successful_checks, failed_checks) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [guild.id, url, channel.id, name || url, 'unknown', new Date().toISOString(), checkInterval, new Date().toISOString(), 0, 0, 0]
                );
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Status Monitor Added`)
                        .setDescription(`Now monitoring **${name || url}** in ${channel}`)
                        .addFields(
                            { name: 'URL', value: url, inline: false },
                            { name: 'Check Interval', value: `Every ${interval || 5} minutes`, inline: true },
                            { name: 'Channel', value: channel.toString(), inline: true }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: 'First check will happen shortly' })
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
                // Trigger immediate check
                const monitor = await db.get('SELECT * FROM status_monitors WHERE guild_id = ? AND url = ?', [guild.id, url]);
                if (monitor) {
                    await statusMonitor.checkSingleMonitor(monitor);
                }
                
            } else if (subcommand === 'remove') {
                const url = interaction.options.getString('url');
                
                const monitor = await db.get('SELECT * FROM status_monitors WHERE guild_id = ? AND url = ?', [guild.id, url]);
                if (!monitor) {
                    return await interaction.reply({
                        content: `${EMOJIS.error} Monitor not found.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                await db.run('DELETE FROM status_monitors WHERE guild_id = ? AND url = ?', [guild.id, url]);
                await db.run('DELETE FROM status_monitor_history WHERE guild_id = ? AND url = ?', [guild.id, url]);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Status Monitor Removed`)
                        .setDescription(`No longer monitoring **${monitor.name || url}**`)
                        .setColor(COLORS.WARNING)
                        .setTimestamp()
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'list') {
                const monitors = await db.all('SELECT * FROM status_monitors WHERE guild_id = ?', [guild.id]);
                
                if (monitors.length === 0) {
                    await interaction.reply({
                        content: `${EMOJIS.info} No status monitors configured.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                    return;
                }
                
                const embed = new EmbedBuilder()
                    .setTitle('🌐 Status Monitors')
                    .setDescription(`Total monitors: **${monitors.length}**`)
                    .setColor(COLORS.INFO)
                    .setTimestamp();
                
                for (const monitor of monitors) {
                    const lastCheck = monitor.last_check ? `<t:${Math.floor(new Date(monitor.last_check).getTime() / 1000)}:R>` : 'Never';
                    const uptimePercent = monitor.total_checks > 0 ? 
                        ((monitor.successful_checks / monitor.total_checks) * 100).toFixed(2) : 0;
                    
                    let statusEmoji = '⚪';
                    if (monitor.last_status === 'online') statusEmoji = '🟢';
                    else if (monitor.last_status === 'offline') statusEmoji = '🔴';
                    else if (monitor.last_status === 'redirect' || monitor.last_status === 'client_error') statusEmoji = '🟡';
                    
                    embed.addFields({
                        name: `${statusEmoji} ${monitor.name || monitor.url}`,
                        value: `**URL:** ${monitor.url}\n**Channel:** <#${monitor.channel_id}>\n**Status:** ${monitor.last_status || 'Unknown'}\n**Uptime:** ${uptimePercent}%\n**Last Check:** ${lastCheck}\n**Interval:** ${Math.floor(monitor.check_interval / 60000)} min`,
                        inline: false
                    });
                }
                
                embed.setFooter({ text: 'Use /statusmonitor config to customize monitors' });
                
                await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
                
            } else if (subcommand === 'config') {
                const url = interaction.options.getString('url');
                const color = interaction.options.getString('color');
                const alertRole = interaction.options.getRole('alert_role');
                const alerts = interaction.options.getBoolean('alerts');
                const showResponseTime = interaction.options.getBoolean('show_response_time');
                const showUptime = interaction.options.getBoolean('show_uptime');
                const showHistory = interaction.options.getBoolean('show_history');
                
                const monitor = await db.get('SELECT * FROM status_monitors WHERE guild_id = ? AND url = ?', [guild.id, url]);
                if (!monitor) {
                    return await interaction.reply({
                        content: `${EMOJIS.error} Monitor not found.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const updates = {};
                if (color) updates.embed_color = color;
                if (alertRole) updates.alert_role_id = alertRole.id;
                if (alerts !== null) updates.alert_enabled = alerts ? 1 : 0;
                if (showResponseTime !== null) updates.show_response_time = showResponseTime ? 1 : 0;
                if (showUptime !== null) updates.show_uptime = showUptime ? 1 : 0;
                if (showHistory !== null) updates.show_history = showHistory ? 1 : 0;
                
                if (Object.keys(updates).length > 0) {
                    const keys = Object.keys(updates);
                    const values = Object.values(updates);
                    const setClause = keys.map(k => `${k} = ?`).join(', ');
                    
                    await db.run(
                        `UPDATE status_monitors SET ${setClause} WHERE guild_id = ? AND url = ?`,
                        [...values, guild.id, url]
                    );
                }
                
                const updatedMonitor = await db.get('SELECT * FROM status_monitors WHERE guild_id = ? AND url = ?', [guild.id, url]);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Monitor Configuration Updated`)
                        .setDescription(`Settings for **${updatedMonitor.name || url}**`)
                        .addFields(
                            { name: '🎨 Embed Color', value: updatedMonitor.embed_color || '#5865F2', inline: true },
                            { name: '🔔 Alerts', value: updatedMonitor.alert_enabled ? 'Enabled' : 'Disabled', inline: true },
                            { name: '👥 Alert Role', value: updatedMonitor.alert_role_id ? `<@&${updatedMonitor.alert_role_id}>` : 'None', inline: true },
                            { name: '⚡ Show Response Time', value: updatedMonitor.show_response_time ? 'Yes' : 'No', inline: true },
                            { name: '📊 Show Uptime', value: updatedMonitor.show_uptime ? 'Yes' : 'No', inline: true },
                            { name: '📉 Show History', value: updatedMonitor.show_history ? 'Yes' : 'No', inline: true }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
                // Trigger update to apply new settings
                await statusMonitor.checkSingleMonitor(updatedMonitor);
                
            } else if (subcommand === 'check') {
                const url = interaction.options.getString('url');
                
                const monitor = await db.get('SELECT * FROM status_monitors WHERE guild_id = ? AND url = ?', [guild.id, url]);
                if (!monitor) {
                    return await interaction.reply({
                        content: `${EMOJIS.error} Monitor not found.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
                
                await statusMonitor.checkSingleMonitor(monitor);
                
                await interaction.editReply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Monitor Checked`)
                        .setDescription(`Forced check completed for **${monitor.name || url}**\n\nCheck the monitor channel for updated status.`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ]
                });
                
            } else if (subcommand === 'reset') {
                const url = interaction.options.getString('url');
                
                const monitor = await db.get('SELECT * FROM status_monitors WHERE guild_id = ? AND url = ?', [guild.id, url]);
                if (!monitor) {
                    return await interaction.reply({
                        content: `${EMOJIS.error} Monitor not found.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                await db.run(
                    `UPDATE status_monitors SET 
                        total_checks = 0, 
                        successful_checks = 0, 
                        failed_checks = 0,
                        avg_response_time = 0,
                        uptime_start = ?
                    WHERE guild_id = ? AND url = ?`,
                    [new Date().toISOString(), guild.id, url]
                );
                
                await db.run('DELETE FROM status_monitor_history WHERE guild_id = ? AND url = ?', [guild.id, url]);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Statistics Reset`)
                        .setDescription(`All statistics have been reset for **${monitor.name || url}**`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
        } else if (commandName === 'weather') {
            const city = interaction.options.getString('city');
            
            if (!config.OPENWEATHER_API_KEY) {
                return interaction.reply({
                    content: `${EMOJIS.error} Weather API key not configured.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            try {
                const response = await axios.get(
                    `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${config.OPENWEATHER_API_KEY}&units=metric`
                );
                
                const data = response.data;
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.weather} Weather in ${data.name}, ${data.sys.country}`)
                    .setDescription(data.weather[0].description)
                    .addFields(
                        { name: '🌡️ Temperature', value: `${data.main.temp}°C`, inline: true },
                        { name: '💨 Wind', value: `${data.wind.speed} m/s`, inline: true },
                        { name: '💧 Humidity', value: `${data.main.humidity}%`, inline: true },
                        { name: '🌡️ Feels Like', value: `${data.main.feels_like}°C`, inline: true },
                        { name: '📊 Pressure', value: `${data.main.pressure} hPa`, inline: true },
                        { name: '👁️ Visibility', value: `${data.visibility / 1000} km`, inline: true }
                    )
                    .setThumbnail(`https://openweathermap.org/img/wn/${data.weather[0].icon}.png`)
                    .setColor(COLORS.INFO)
                    .setTimestamp()
                    .setFooter({ text: config.BOT_WATERMARK });
                
                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                await interaction.reply({
                    content: `${EMOJIS.error} Could not fetch weather data for "${city}".`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
        } else if (commandName === 'qrcode') {
            const text = interaction.options.getString('text');
            const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(text)}&size=200x200`;
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.qrcode} QR Code Generated`)
                .setDescription(`**Content:** ${text.substring(0, 100)}${text.length > 100 ? '...' : ''}`)
                .setImage(qrUrl)
                .setColor(COLORS.INFO)
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'remindme') {
            const time = interaction.options.getString('time');
            const reason = interaction.options.getString('reason');
            
            const ms = parseDuration(time);
            if (ms === 0) {
                return interaction.reply({
                    content: `${EMOJIS.error} Invalid time format. Use formats like: 5s, 10m, 1h, 2d, 1w`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            const reminderTime = new Date(Date.now() + ms);
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.reminder} Reminder Set`)
                .setDescription(`I'll remind you about: **${reason}**`)
                .addFields(
                    { name: 'Time', value: `<t:${Math.floor(reminderTime.getTime() / 1000)}:R>`, inline: true },
                    { name: 'Duration', value: time, inline: true }
                )
                .setColor(COLORS.SUCCESS)
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            
            // Set the reminder
            setTimeout(async () => {
                try {
                    await user.send(`⏰ **Reminder:** ${reason}`);
                } catch {
                    // If can't DM, try to reply in channel
                    const channel = guild.channels.cache.get(interaction.channelId);
                    if (channel) {
                        await channel.send(`${user}, ⏰ **Reminder:** ${reason}`).catch(() => {});
                    }
                }
            }, ms);
            
        } else if (commandName === 'poll') {
            const question = interaction.options.getString('question');
            const options = interaction.options.getString('options').split('|').map(opt => opt.trim()).slice(0, 10);
            
            if (options.length < 2) {
                return interaction.reply({
                    content: `${EMOJIS.error} Poll must have at least 2 options.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.poll} Poll: ${question}`)
                .setColor(COLORS.INFO)
                .setFooter({ text: `Poll created by ${user.username} • React to vote!` })
                .setTimestamp();
            
            options.forEach((option, index) => {
                embed.addFields({
                    name: `${index + 1}️⃣ ${option}`,
                    value: '0 votes',
                    inline: true
                });
            });
            
            const pollMessage = await interaction.reply({ embeds: [embed], fetchReply: true });
            
            // Add reactions
            for (let i = 0; i < options.length; i++) {
                await pollMessage.react(`${i + 1}️⃣`).catch(() => {});
            }
            
        } else if (commandName === 'announce') {
            const channel = interaction.options.getChannel('channel') || interaction.channel;
            const message = interaction.options.getString('message');
            const mentionEveryone = interaction.options.getBoolean('mention_everyone') || false;
            const mentionHere = interaction.options.getBoolean('mention_here') || false;
            const mentionRole = interaction.options.getRole('mention_role');
            
            // Validate channel is text-based
            if (!channel.isTextBased()) {
                return await interaction.reply({
                    content: `${EMOJIS.error} Please select a text channel, not a voice channel or category.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            // Convert \n to actual line breaks
            const formattedMessage = message.replace(/\\n/g, '\n');
            
            // Check message length
            if (formattedMessage.length > 2000) {
                return await interaction.reply({
                    content: `${EMOJIS.error} Message is too long! Maximum 2000 characters. Current: ${formattedMessage.length}`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            // Build mention content
            let mentionContent = '';
            if (mentionEveryone) mentionContent = '@everyone\n';
            else if (mentionHere) mentionContent = '@here\n';
            else if (mentionRole) mentionContent = `${mentionRole.toString()}\n`;
            
            // Send announcement
            try {
                const fullMessage = mentionContent + formattedMessage;
                await channel.send(fullMessage);
                
                // Count lines and emojis
                const lineCount = formattedMessage.split('\n').length;
                const emojiCount = (formattedMessage.match(/[\p{Emoji}]/gu) || []).length;
                
                // Send detailed confirmation
                const confirmEmbed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.success} Announcement Sent Successfully!`)
                    .setDescription(`Your announcement has been posted in ${channel}`)
                    .addFields(
                        { name: '📍 Channel', value: channel.toString(), inline: true },
                        { name: '📄 Lines', value: lineCount.toString(), inline: true },
                        { name: '📝 Characters', value: formattedMessage.length.toString(), inline: true },
                        { name: '😀 Emojis', value: emojiCount.toString(), inline: true },
                        { name: '📢 Mentions', value: mentionContent.trim() || 'None', inline: true },
                        { name: '⏰ Time', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true }
                    )
                    .setColor(COLORS.SUCCESS)
                    .setTimestamp()
                    .setFooter({ text: config.BOT_WATERMARK });
                
                // Add preview if message is short enough
                if (formattedMessage.length <= 200) {
                    confirmEmbed.addFields({ 
                        name: '👁️ Preview', 
                        value: formattedMessage.substring(0, 200) 
                    });
                }
                
                await interaction.reply({
                    embeds: [confirmEmbed],
                    flags: [MessageFlags.Ephemeral]
                });
            } catch (error) {
                console.error('Error sending announcement:', error);
                await interaction.reply({
                    content: `${EMOJIS.error} Failed to send announcement. Please check:\n• Bot has Send Messages permission in ${channel}\n• Message doesn't contain invalid content\n• Channel is accessible`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
        } else if (commandName === 'embed') {
            const targetChannel = interaction.options.getChannel('channel') || interaction.channel;
            const title = interaction.options.getString('title');
            const description = interaction.options.getString('description');
            const color = interaction.options.getString('color');
            const footer = interaction.options.getString('footer');
            const image = interaction.options.getString('image');
            
            const embed = new EmbedBuilder()
                .setColor(color ? parseInt(color.replace('#', ''), 16) : COLORS.PRIMARY)
                .setTimestamp();
            
            if (title) embed.setTitle(title);
            if (description) embed.setDescription(description);
            if (footer) embed.setFooter({ text: footer });
            if (image) embed.setImage(image);
            
            await targetChannel.send({ embeds: [embed] });
            
            await interaction.reply({
                content: `${EMOJIS.success} Embed sent to ${targetChannel}!`,
                flags: [MessageFlags.Ephemeral]
            });
            
        } else if (commandName === 'dm') {
            const subcommand = interaction.options.getSubcommand();
            const messageText = interaction.options.getString('message');
            const title = interaction.options.getString('title');
            
            // Defer reply immediately for all subcommands to prevent timeout
            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
            
            if (subcommand === 'user') {
                const target = interaction.options.getUser('user');
                const result = await dmManager.sendDMToUser(target.id, messageText, {
                    title: title || undefined, // Don't set title if not explicitly provided
                    color: COLORS.INFO,
                    author: user,
                    footer: config.BOT_WATERMARK
                });
                
                if (result.success) {
                    await dmManager.logDM(target.id, guild.id, user.id, messageText, 'out');
                    await interaction.editReply({
                        content: `${EMOJIS.success} DM sent to ${target.tag}!`
                    });
                } else {
                    await interaction.editReply({
                        content: `${EMOJIS.error} Failed to send DM: ${result.error}`
                    });
                }
                
            } else if (subcommand === 'role') {
                const role = interaction.options.getRole('role');
                
                const result = await dmManager.sendDMToRole(guild, role.id, messageText, {
                    title: title || undefined,
                    color: COLORS.INFO,
                    author: user,
                    footer: config.BOT_WATERMARK
                });
                
                if (result.success) {
                    await dmManager.logDM('role', guild.id, user.id, messageText, 'out', role.id);
                    await interaction.editReply({
                        embeds: [new EmbedBuilder()
                            .setTitle(`${EMOJIS.success} DM Campaign Sent`)
                            .setDescription(result.message)
                            .addFields(
                                { name: 'Success', value: result.stats.successCount.toString(), inline: true },
                                { name: 'Failed', value: result.stats.failCount.toString(), inline: true },
                                { name: 'Total', value: result.stats.total.toString(), inline: true }
                            )
                            .setColor(COLORS.SUCCESS)
                            .setTimestamp()
                            .setFooter({ text: config.BOT_WATERMARK })
                        ]
                    });
                } else {
                    await interaction.editReply({
                        content: `${EMOJIS.error} Failed to send DM: ${result.error}`
                    });
                }
                
            } else if (subcommand === 'everyone') {
                const result = await dmManager.sendDMToEveryone(guild, messageText, {
                    title: title || undefined,
                    color: COLORS.INFO,
                    author: user,
                    footer: config.BOT_WATERMARK
                });
                
                if (result.success) {
                    await dmManager.logDM('everyone', guild.id, user.id, messageText, 'out', 'everyone');
                    
                    const embed = new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} DM Campaign Completed`)
                        .setDescription(result.message)
                        .addFields(
                            { name: 'Success', value: result.stats.successCount.toString(), inline: true },
                            { name: 'Failed', value: result.stats.failCount.toString(), inline: true },
                            { name: 'Total', value: result.stats.total.toString(), inline: true }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK });
                    
                    await interaction.editReply({ embeds: [embed] });
                } else {
                    await interaction.editReply({
                        content: `${EMOJIS.error} Failed to send DM: ${result.error}`
                    });
                }
            }
            
        } else if (commandName === 'dmlogs') {
            const target = interaction.options.getUser('user');
            const logs = await db.all(
                'SELECT * FROM dm_logs WHERE user_id = ? ORDER BY timestamp DESC LIMIT 20',
                [target.id]
            );
            
            if (logs.length === 0) {
                return interaction.reply({
                    content: `${EMOJIS.info} No DM logs found for ${target.tag}.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.envelope} DM Logs for ${target.tag}`)
                .setColor(COLORS.INFO)
                .setFooter({ text: `Showing ${logs.length} most recent logs` })
                .setTimestamp();
            
            logs.slice(0, 10).forEach(log => {
                const time = Math.floor(new Date(log.timestamp).getTime() / 1000);
                const direction = log.direction === 'in' ? '📥 Incoming' : '📤 Outgoing';
                const moderator = log.moderator_id ? `<@${log.moderator_id}>` : 'System';
                const roleMention = log.role_mention ? ` (Role: <@&${log.role_mention}>)` : '';
                
                embed.addFields({
                    name: `${direction} - <t:${time}:R>`,
                    value: `**Message:** ${log.message.substring(0, 100)}${log.message.length > 100 ? '...' : ''}\n**By:** ${moderator}${roleMention}`,
                    inline: false
                });
            });
            
            await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
            
        } else if (commandName === 'ban') {
            const target = interaction.options.getUser('user');
            const reason = interaction.options.getString('reason') || 'No reason provided';
            
            const targetMember = await guild.members.fetch(target.id).catch(() => null);
            if (!targetMember) {
                return interaction.reply({
                    content: `${EMOJIS.error} User not found in this server.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            if (!targetMember.bannable) {
                return interaction.reply({
                    content: `${EMOJIS.error} I cannot ban this user.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            await targetMember.ban({ reason: `${user.tag}: ${reason}` });
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.hammer} User Banned`)
                .setColor(COLORS.ERROR)
                .addFields(
                    { name: 'User', value: `${target.tag} (${target.id})`, inline: true },
                    { name: 'Moderator', value: user.tag, inline: true },
                    { name: 'Reason', value: reason, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            await logModeration(guild.id, 'ban', target.id, user.id, reason);
            
        } else if (commandName === 'kick') {
            const target = interaction.options.getUser('user');
            const reason = interaction.options.getString('reason') || 'No reason provided';
            
            const targetMember = await guild.members.fetch(target.id).catch(() => null);
            if (!targetMember) {
                return interaction.reply({
                    content: `${EMOJIS.error} User not found in this server.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            if (!targetMember.kickable) {
                return interaction.reply({
                    content: `${EMOJIS.error} I cannot kick this user.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            await targetMember.kick(`${user.tag}: ${reason}`);
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.hammer} User Kicked`)
                .setColor(COLORS.WARNING)
                .addFields(
                    { name: 'User', value: `${target.tag} (${target.id})`, inline: true },
                    { name: 'Moderator', value: user.tag, inline: true },
                    { name: 'Reason', value: reason, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            await logModeration(guild.id, 'kick', target.id, user.id, reason);
            
        } else if (commandName === 'timeout') {
            const target = interaction.options.getUser('user');
            const duration = interaction.options.getString('duration');
            const reason = interaction.options.getString('reason') || 'No reason provided';
            
            const targetMember = await guild.members.fetch(target.id).catch(() => null);
            if (!targetMember) {
                return interaction.reply({
                    content: `${EMOJIS.error} User not found in this server.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            if (!targetMember.moderatable) {
                return interaction.reply({
                    content: `${EMOJIS.error} I cannot timeout this user.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            const ms = parseDuration(duration);
            if (ms === 0 || ms > 2419200000) { // Max 28 days
                return interaction.reply({
                    content: `${EMOJIS.error} Invalid duration. Maximum is 28 days.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            await targetMember.timeout(ms, `${user.tag}: ${reason}`);
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.hammer} User Timed Out`)
                .setColor(COLORS.WARNING)
                .addFields(
                    { name: 'User', value: `${target.tag} (${target.id})`, inline: true },
                    { name: 'Moderator', value: user.tag, inline: true },
                    { name: 'Duration', value: duration, inline: true },
                    { name: 'Reason', value: reason, inline: false }
                )
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            await logModeration(guild.id, 'timeout', target.id, user.id, reason);
            
        } else if (commandName === 'warn') {
            const target = interaction.options.getUser('user');
            const reason = interaction.options.getString('reason');
            
            const warningId = await addWarning(guild.id, target.id, reason, user.id);
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.warning} User Warned`)
                .setColor(COLORS.WARNING)
                .addFields(
                    { name: 'User', value: `${target.tag} (${target.id})`, inline: true },
                    { name: 'Moderator', value: user.tag, inline: true },
                    { name: 'Reason', value: reason, inline: false },
                    { name: 'Warning #', value: warningId.toString(), inline: true }
                )
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            
            // Try to DM the user
            try {
                await target.send(`⚠️ You have been warned in **${guild.name}**\n**Reason:** ${reason}\n**Warning #:** ${warningId}`);
            } catch {}
            
        } else if (commandName === 'warnings') {
            const target = interaction.options.getUser('user');
            const warnings = await getWarnings(guild.id, target.id);
            
            if (warnings.length === 0) {
                return interaction.reply({
                    content: `${EMOJIS.info} ${target.tag} has no warnings.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.warning} Warnings for ${target.tag}`)
                .setColor(COLORS.WARNING)
                .setFooter({ text: `Total: ${warnings.length} warnings` })
                .setTimestamp();
            
            warnings.slice(0, 10).forEach(warn => {
                const time = Math.floor(new Date(warn.timestamp).getTime() / 1000);
                embed.addFields({
                    name: `Warning #${warn.warning_id}`,
                    value: `**Reason:** ${warn.reason}\n**Moderator:** <@${warn.moderator_id}>\n**Date:** <t:${time}:R>`,
                    inline: false
                });
            });
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'clearwarns') {
            const target = interaction.options.getUser('user');
            const cleared = await clearWarnings(guild.id, target.id);
            
            if (cleared) {
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(`${EMOJIS.success} Warnings Cleared`)
                        .setDescription(`All warnings cleared for ${target.tag}.`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                    ]
                });
                await logModeration(guild.id, 'clear_warnings', target.id, user.id, 'All warnings cleared');
            } else {
                await interaction.reply({
                    content: `${EMOJIS.error} Failed to clear warnings.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
        } else if (commandName === 'purge') {
            const amount = interaction.options.getInteger('amount');
            const targetUser = interaction.options.getUser('user');
            
            if (amount < 1 || amount > 100) {
                return interaction.reply({
                    content: `${EMOJIS.error} Amount must be between 1 and 100.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            let messages;
            if (targetUser) {
                messages = await interaction.channel.messages.fetch({ limit: 100 });
                messages = messages.filter(m => m.author.id === targetUser.id).first(amount);
            } else {
                messages = await interaction.channel.messages.fetch({ limit: amount });
            }
            
            const deleted = await interaction.channel.bulkDelete(messages, true).catch(() => {});
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.success} Messages Purged`)
                .setColor(COLORS.SUCCESS)
                .setDescription(`Deleted ${deleted?.size || 0} message(s)${targetUser ? ` from ${targetUser.tag}` : ''}.`)
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
            await logModeration(guild.id, 'purge', targetUser?.id || 'all', user.id, `Deleted ${deleted?.size || 0} messages`);
            
        } else if (commandName === 'ticket') {
            const subcommand = interaction.options.getSubcommand();
            
            if (subcommand === 'setup') {
                const category = interaction.options.getChannel('category');
                const supportRole = interaction.options.getRole('support_role');
                const logChannel = interaction.options.getChannel('log_channel');
                
                await db.run(
                    'INSERT INTO ticket_config (guild_id, category_id, support_role_id, log_channel_id, enabled) VALUES (?, ?, ?, ?, 1) ON CONFLICT(guild_id) DO UPDATE SET category_id = ?, support_role_id = ?, log_channel_id = ?',
                    [guild.id, category.id, supportRole?.id, logChannel?.id, category.id, supportRole?.id, logChannel?.id]
                );
                
                const embed = new EmbedBuilder()
                    .setTitle('🎫 Ticket System Setup')
                    .setDescription('Ticket system has been configured successfully!')
                    .setColor(COLORS.SUCCESS)
                    .addFields(
                        { name: 'Category', value: `${category}`, inline: true },
                        { name: 'Support Role', value: supportRole ? `${supportRole}` : 'None', inline: true },
                        { name: 'Log Channel', value: logChannel ? `${logChannel}` : 'None', inline: true }
                    )
                    .setTimestamp()
                    .setFooter({ text: config.BOT_WATERMARK });
                
                await interaction.reply({ embeds: [embed] });
                
            } else if (subcommand === 'panel') {
                const channel = interaction.options.getChannel('channel');
                const title = interaction.options.getString('title') || '🎫 Support Tickets';
                const description = interaction.options.getString('description') || 'Click the button below to create a support ticket';
                const ticketType = interaction.options.getString('type') || 'general';
                
                const result = await ticketManager.createPanel(guild, channel, {
                    title,
                    description,
                    ticketType
                });
                
                if (result.success) {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle('🎫 Ticket Panel Created')
                            .setDescription(`Ticket panel has been created in ${channel}`)
                            .setColor(COLORS.SUCCESS)
                            .setTimestamp()
                            .setFooter({ text: config.BOT_WATERMARK })
                        ],
                        flags: [MessageFlags.Ephemeral]
                    });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} Error: ${result.error}`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
            } else if (subcommand === 'add') {
                const targetUser = interaction.options.getUser('user');
                const ticket = await db.get('SELECT * FROM tickets WHERE channel_id = ? AND status = ?', [interaction.channel.id, 'open']);
                
                if (!ticket) {
                    return interaction.reply({
                        content: `${EMOJIS.error} This is not a ticket channel!`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const result = await ticketManager.addUserToTicket(ticket.ticket_id, targetUser, user);
                
                if (result.success) {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setDescription(`✅ ${targetUser} has been added to the ticket`)
                            .setColor(COLORS.SUCCESS)
                        ]
                    });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} Error: ${result.error}`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
            } else if (subcommand === 'remove') {
                const targetUser = interaction.options.getUser('user');
                const ticket = await db.get('SELECT * FROM tickets WHERE channel_id = ? AND status = ?', [interaction.channel.id, 'open']);
                
                if (!ticket) {
                    return interaction.reply({
                        content: `${EMOJIS.error} This is not a ticket channel!`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const result = await ticketManager.removeUserFromTicket(ticket.ticket_id, targetUser, user);
                
                if (result.success) {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setDescription(`✅ ${targetUser} has been removed from the ticket`)
                            .setColor(COLORS.SUCCESS)
                        ]
                    });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} Error: ${result.error}`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
            } else if (subcommand === 'close') {
                const reason = interaction.options.getString('reason') || 'No reason provided';
                const ticket = await db.get('SELECT * FROM tickets WHERE channel_id = ? AND status = ?', [interaction.channel.id, 'open']);
                
                if (!ticket) {
                    return interaction.reply({
                        content: `${EMOJIS.error} This is not a ticket channel!`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const ticketConfig = await ticketManager.getConfig(guild.id);
                
                if (ticketConfig.rating_enabled && ticket.user_id === user.id) {
                    // Show rating buttons
                    const row = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder().setCustomId(`ticket_rate_${ticket.ticket_id}_1`).setLabel('⭐').setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`ticket_rate_${ticket.ticket_id}_2`).setLabel('⭐⭐').setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`ticket_rate_${ticket.ticket_id}_3`).setLabel('⭐⭐⭐').setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`ticket_rate_${ticket.ticket_id}_4`).setLabel('⭐⭐⭐⭐').setStyle(ButtonStyle.Secondary),
                            new ButtonBuilder().setCustomId(`ticket_rate_${ticket.ticket_id}_5`).setLabel('⭐⭐⭐⭐⭐').setStyle(ButtonStyle.Primary)
                        );
                    
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle('🎫 Rate Your Experience')
                            .setDescription('Please rate your support experience before closing')
                            .setColor(COLORS.INFO)
                        ],
                        components: [row]
                    });
                } else {
                    await interaction.deferReply();
                    const result = await ticketManager.closeTicket(ticket.ticket_id, user, reason);
                    
                    if (result.success) {
                        await interaction.editReply({
                            embeds: [new EmbedBuilder()
                                .setTitle('🔒 Ticket Closing')
                                .setDescription('This ticket will be deleted in 5 seconds...')
                                .setColor(COLORS.WARNING)
                            ]
                        });
                    } else {
                        await interaction.editReply({
                            content: `${EMOJIS.error} Error: ${result.error}`
                        });
                    }
                }
                
            } else if (subcommand === 'claim') {
                const ticket = await db.get('SELECT * FROM tickets WHERE channel_id = ? AND status = ?', [interaction.channel.id, 'open']);
                            
                if (!ticket) {
                    return interaction.reply({
                        content: `${EMOJIS.error} This is not a ticket channel!`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                            
                if (ticket.claimed_by) {
                    return interaction.reply({
                        content: `${EMOJIS.error} This ticket is already claimed by <@${ticket.claimed_by}>`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
            
                // Prevent ticket creator from claiming their own ticket
                if (ticket.user_id === user.id) {
                    return interaction.reply({
                        content: `${EMOJIS.error} You cannot claim your own ticket! Claiming is for support staff.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
            
                // Check if user has permission to claim
                const claimConfig = await ticketManager.getConfig(guild.id);
                const claimTypeConfig = await db.get('SELECT * FROM ticket_types WHERE guild_id = ? AND type_name = ?', [guild.id, ticket.ticket_type]);
                const claimSupportRoleId = claimTypeConfig?.support_role_id || claimConfig?.support_role_id;
            
                const canClaim = member.permissions.has(PermissionFlagsBits.ManageChannels) ||
                    (claimSupportRoleId && member.roles.cache.has(claimSupportRoleId)) ||
                    await security.isExtraOwner(guild.id, user.id);
            
                if (!canClaim) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Only support staff can claim tickets.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                            
                const result = await ticketManager.claimTicket(ticket.ticket_id, user);
                            
                if (result.success) {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setDescription(`\u270b ${user} has claimed this ticket and will be assisting you!`)
                            .setColor(COLORS.SUCCESS)
                            .setTimestamp()
                        ]
                    });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} Error: ${result.error}`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                            
            } else if (subcommand === 'transcript') {
                const ticket = await db.get('SELECT * FROM tickets WHERE channel_id = ?', [interaction.channel.id]);
                
                if (!ticket) {
                    return interaction.reply({
                        content: `${EMOJIS.error} This is not a ticket channel!`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
                
                const transcriptUrl = await ticketManager.generateTranscript(ticket.ticket_id, interaction.channel);
                
                if (transcriptUrl) {
                    await interaction.editReply({
                        embeds: [new EmbedBuilder()
                            .setTitle('📄 Transcript Generated')
                            .setDescription(`Transcript ID: ${transcriptUrl}`)
                            .setColor(COLORS.SUCCESS)
                            .setTimestamp()
                        ]
                    });
                } else {
                    await interaction.editReply({
                        content: `${EMOJIS.error} Failed to generate transcript`
                    });
                }
                
            } else if (subcommand === 'stats') {
                const targetUser = interaction.options.getUser('user') || user;
                const stats = await ticketManager.getTicketStats(guild.id, targetUser.id);
                
                const embed = new EmbedBuilder()
                    .setTitle(`🎫 Ticket Statistics - ${targetUser.tag}`)
                    .setColor(COLORS.INFO)
                    .setThumbnail(targetUser.displayAvatarURL())
                    .setTimestamp()
                    .setFooter({ text: config.BOT_WATERMARK });
                
                if (stats) {
                    embed.addFields(
                        { name: 'Tickets Created', value: stats.tickets_created.toString(), inline: true },
                        { name: 'Tickets Closed', value: stats.tickets_closed.toString(), inline: true },
                        { name: 'Average Rating', value: stats.average_rating ? `${stats.average_rating.toFixed(1)} ⭐` : 'N/A', inline: true }
                    );
                } else {
                    embed.setDescription('No ticket statistics found for this user');
                }
                
                await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
                
            } else if (subcommand === 'addtype') {
                const typeName = interaction.options.getString('name');
                const emoji = interaction.options.getString('emoji') || '🎫';
                let description = interaction.options.getString('description') || 'No description';
                const supportRole = interaction.options.getRole('support_role');
                
                // Validate and truncate description to Discord's 100 character limit
                if (description.length > 100) {
                    description = description.substring(0, 97) + '...';
                    await interaction.reply({
                        content: `⚠️ Description was too long and has been truncated to 100 characters.\nTruncated: "${description}"`,
                        flags: [MessageFlags.Ephemeral]
                    });
                    return;
                }
                
                // Validate type name length (max 100 chars for Discord select menu)
                if (typeName.length > 100) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Type name is too long! Maximum 100 characters allowed.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                await db.run(
                    'INSERT INTO ticket_types (guild_id, type_name, emoji, description, support_role_id) VALUES (?, ?, ?, ?, ?) ON CONFLICT(guild_id, type_name) DO UPDATE SET emoji = ?, description = ?, support_role_id = ?',
                    [guild.id, typeName, emoji, description, supportRole?.id, emoji, description, supportRole?.id]
                );
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle('🎫 Ticket Type Added')
                        .setDescription(`Ticket type **${typeName}** has been added/updated`)
                        .addFields(
                            { name: 'Emoji', value: emoji, inline: true },
                            { name: 'Support Role', value: supportRole ? `${supportRole}` : 'None', inline: true }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK })
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'listtypes') {
                // List all ticket types
                const types = await db.all('SELECT * FROM ticket_types WHERE guild_id = ? ORDER BY type_name', [guild.id]);
                
                if (types.length === 0) {
                    return interaction.reply({
                        content: `${EMOJIS.error} No ticket types found. Create one with \`/ticket addtype\``,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const embed = new EmbedBuilder()
                    .setTitle('🎫 Ticket Types')
                    .setDescription(`Found ${types.length} ticket type(s) in this server`)
                    .setColor(COLORS.INFO)
                    .setTimestamp()
                    .setFooter({ text: config.BOT_WATERMARK });
                
                for (const type of types) {
                    const supportRole = type.support_role_id ? guild.roles.cache.get(type.support_role_id) : null;
                    const supportRoleName = supportRole ? `${supportRole}` : 'None';
                    
                    embed.addFields({
                        name: `${type.emoji} ${type.type_name}`,
                        value: `**Description:** ${type.description}\n**Support Role:** ${supportRoleName}`,
                        inline: false
                    });
                }
                
                await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
                
            } else if (subcommand === 'edittype') {
                // Edit ticket type
                const typeName = interaction.options.getString('name');
                let newName = interaction.options.getString('new_name');
                const newEmoji = interaction.options.getString('emoji');
                let newDescription = interaction.options.getString('description');
                const newSupportRole = interaction.options.getRole('support_role');
                
                // Validate lengths
                if (newName && newName.length > 100) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Type name is too long! Maximum 100 characters allowed.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                if (newDescription && newDescription.length > 100) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Description is too long! Maximum 100 characters allowed.\nCurrent length: ${newDescription.length}`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const type = await db.get('SELECT * FROM ticket_types WHERE guild_id = ? AND type_name = ?', [guild.id, typeName]);
                
                if (!type) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Ticket type **${typeName}** not found. Use \`/ticket listtypes\` to see all types.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                // Update database
                const updates = [];
                const values = [];
                
                if (newName) {
                    updates.push('type_name = ?');
                    values.push(newName);
                }
                if (newEmoji) {
                    updates.push('emoji = ?');
                    values.push(newEmoji);
                }
                if (newDescription) {
                    updates.push('description = ?');
                    values.push(newDescription);
                }
                if (newSupportRole) {
                    updates.push('support_role_id = ?');
                    values.push(newSupportRole.id);
                }
                
                if (updates.length === 0) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Please provide at least one field to update.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                values.push(guild.id, typeName);
                await db.run(`UPDATE ticket_types SET ${updates.join(', ')} WHERE guild_id = ? AND type_name = ?`, values);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle('✅ Ticket Type Updated')
                        .setDescription(`Ticket type **${typeName}** has been updated successfully!`)
                        .addFields(
                            { name: 'Updated Fields', value: updates.map(u => u.split(' = ')[0]).join(', '), inline: false }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK })
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'deletetype') {
                // Delete ticket type
                const typeName = interaction.options.getString('name');
                
                const type = await db.get('SELECT * FROM ticket_types WHERE guild_id = ? AND type_name = ?', [guild.id, typeName]);
                
                if (!type) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Ticket type **${typeName}** not found. Use \`/ticket listtypes\` to see all types.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                // Delete from database
                await db.run('DELETE FROM ticket_types WHERE guild_id = ? AND type_name = ?', [guild.id, typeName]);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle('🗑️ Ticket Type Deleted')
                        .setDescription(`Ticket type **${typeName}** has been deleted successfully!`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK })
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'config') {
                const setting = interaction.options.getString('setting');
                const value = interaction.options.getString('value');
                
                let updateQuery = '';
                let updateValue = value;
                
                switch (setting) {
                    case 'max_tickets':
                        updateQuery = 'UPDATE ticket_config SET max_tickets = ? WHERE guild_id = ?';
                        updateValue = parseInt(value);
                        break;
                    case 'welcome_message':
                        updateQuery = 'UPDATE ticket_config SET welcome_message = ? WHERE guild_id = ?';
                        break;
                    case 'ticket_name_format':
                        updateQuery = 'UPDATE ticket_config SET ticket_name_format = ? WHERE guild_id = ?';
                        break;
                    case 'enabled':
                        updateQuery = 'UPDATE ticket_config SET enabled = ? WHERE guild_id = ?';
                        updateValue = value.toLowerCase() === 'true' || value === '1' ? 1 : 0;
                        break;
                    case 'transcript_enabled':
                        updateQuery = 'UPDATE ticket_config SET transcript_enabled = ? WHERE guild_id = ?';
                        updateValue = value.toLowerCase() === 'true' || value === '1' ? 1 : 0;
                        break;
                    case 'rating_enabled':
                        updateQuery = 'UPDATE ticket_config SET rating_enabled = ? WHERE guild_id = ?';
                        updateValue = value.toLowerCase() === 'true' || value === '1' ? 1 : 0;
                        break;
                }
                
                await db.run(updateQuery, [updateValue, guild.id]);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle('⚙️ Ticket Configuration Updated')
                        .setDescription(`**${setting}** has been set to: ${value}`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK })
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'panels') {
                // List all ticket panels
                const panels = await db.all('SELECT * FROM ticket_panels WHERE guild_id = ? ORDER BY created_at DESC', [guild.id]);
                
                if (panels.length === 0) {
                    return interaction.reply({
                        content: `${EMOJIS.error} No ticket panels found. Create one with \`/ticket panel\``,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const embed = new EmbedBuilder()
                    .setTitle('🎫 Ticket Panels')
                    .setDescription(`Found ${panels.length} ticket panel(s) in this server`)
                    .setColor(COLORS.INFO)
                    .setTimestamp()
                    .setFooter({ text: config.BOT_WATERMARK });
                
                for (const panel of panels.slice(0, 10)) { // Limit to 10 panels
                    const channel = guild.channels.cache.get(panel.channel_id);
                    const channelName = channel ? `#${channel.name}` : 'Unknown Channel';
                    
                    embed.addFields({
                        name: `Panel ID: ${panel.id}`,
                        value: `**Title:** ${panel.title}\n**Channel:** ${channelName}\n**Type:** ${panel.ticket_type}\n**Created:** <t:${Math.floor(new Date(panel.created_at).getTime() / 1000)}:R>`,
                        inline: false
                    });
                }
                
                if (panels.length > 10) {
                    embed.setFooter({ text: `Showing 10 of ${panels.length} panels | ${config.BOT_WATERMARK}` });
                }
                
                await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
                
            } else if (subcommand === 'editpanel') {
                // Edit ticket panel
                const panelId = interaction.options.getString('panel_id');
                const newTitle = interaction.options.getString('title');
                const newDescription = interaction.options.getString('description');
                const newButtonLabel = interaction.options.getString('button_label');
                const newEmoji = interaction.options.getString('emoji');
                const newColor = interaction.options.getString('color');
                
                const panel = await db.get('SELECT * FROM ticket_panels WHERE id = ? AND guild_id = ?', [panelId, guild.id]);
                
                if (!panel) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Panel not found. Use \`/ticket panels\` to see all panels.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                // Update database
                const updates = [];
                const values = [];
                
                if (newTitle) {
                    updates.push('title = ?');
                    values.push(newTitle);
                }
                if (newDescription) {
                    updates.push('description = ?');
                    values.push(newDescription);
                }
                if (newButtonLabel) {
                    updates.push('button_label = ?');
                    values.push(newButtonLabel);
                }
                if (newEmoji) {
                    updates.push('emoji = ?');
                    values.push(newEmoji);
                }
                if (newColor) {
                    updates.push('color = ?');
                    values.push(newColor);
                }
                
                if (updates.length === 0) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Please provide at least one field to update.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                values.push(panelId, guild.id);
                await db.run(`UPDATE ticket_panels SET ${updates.join(', ')} WHERE id = ? AND guild_id = ?`, values);
                
                // Get updated panel
                const updatedPanel = await db.get('SELECT * FROM ticket_panels WHERE id = ?', [panelId]);
                
                // Update the message
                try {
                    const channel = guild.channels.cache.get(updatedPanel.channel_id);
                    if (channel) {
                        const message = await channel.messages.fetch(updatedPanel.message_id);
                        
                        const embed = new EmbedBuilder()
                            .setTitle(updatedPanel.title)
                            .setDescription(updatedPanel.description)
                            .setColor(updatedPanel.color || COLORS.PRIMARY)
                            .setTimestamp()
                            .setFooter({ text: config.BOT_WATERMARK });
                        
                        const button = new ButtonBuilder()
                            .setCustomId(`ticket_create_${updatedPanel.ticket_type}`)
                            .setLabel(updatedPanel.button_label)
                            .setStyle(ButtonStyle.Primary)
                            .setEmoji(updatedPanel.emoji);
                        
                        const row = new ActionRowBuilder().addComponents(button);
                        
                        await message.edit({ embeds: [embed], components: [row] });
                    }
                } catch (error) {
                    console.error('Error updating panel message:', error);
                }
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle('✅ Panel Updated')
                        .setDescription(`Ticket panel **${panelId}** has been updated successfully!`)
                        .addFields(
                            { name: 'Updated Fields', value: updates.map(u => u.split(' = ')[0]).join(', '), inline: false }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK })
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'deletepanel') {
                // Delete ticket panel
                const panelId = interaction.options.getString('panel_id');
                
                const panel = await db.get('SELECT * FROM ticket_panels WHERE id = ? AND guild_id = ?', [panelId, guild.id]);
                
                if (!panel) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Panel not found. Use \`/ticket panels\` to see all panels.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                // Delete the message
                try {
                    const channel = guild.channels.cache.get(panel.channel_id);
                    if (channel) {
                        const message = await channel.messages.fetch(panel.message_id);
                        await message.delete();
                    }
                } catch (error) {
                    console.error('Error deleting panel message:', error);
                }
                
                // Delete from database
                await db.run('DELETE FROM ticket_panels WHERE id = ? AND guild_id = ?', [panelId, guild.id]);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle('🗑️ Panel Deleted')
                        .setDescription(`Ticket panel **${panelId}** has been deleted successfully!`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK })
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'closeall') {
                // Close all open tickets
                const reason = interaction.options.getString('reason') || 'Mass ticket closure by admin';
                
                await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
                
                // Get all open tickets
                const openTickets = await db.all('SELECT * FROM tickets WHERE guild_id = ? AND status = ?', [guild.id, 'open']);
                
                if (openTickets.length === 0) {
                    return interaction.editReply({
                        content: `${EMOJIS.info} No open tickets to close.`
                    });
                }
                
                let closedCount = 0;
                let failedCount = 0;
                
                for (const ticket of openTickets) {
                    try {
                        const channel = guild.channels.cache.get(ticket.channel_id);
                        
                        if (channel) {
                            // Send closing message
                            await channel.send({
                                embeds: [new EmbedBuilder()
                                    .setTitle('🔒 Ticket Closing')
                                    .setDescription(`This ticket is being closed.\n**Reason:** ${reason}`)
                                    .setColor(COLORS.WARNING)
                                    .setTimestamp()
                                ]
                            });
                            
                            // Update database
                            await db.run(
                                'UPDATE tickets SET status = ?, closed_at = ?, closed_by = ? WHERE ticket_id = ?',
                                ['closed', new Date().toISOString(), user.id, ticket.ticket_id]
                            );
                            
                            // Delete channel after 5 seconds
                            setTimeout(async () => {
                                try {
                                    await channel.delete();
                                } catch (error) {
                                    console.error('Error deleting ticket channel:', error);
                                }
                            }, 5000);
                            
                            closedCount++;
                        } else {
                            // Channel doesn't exist, just update database
                            await db.run(
                                'UPDATE tickets SET status = ?, closed_at = ?, closed_by = ? WHERE ticket_id = ?',
                                ['closed', new Date().toISOString(), user.id, ticket.ticket_id]
                            );
                            closedCount++;
                        }
                    } catch (error) {
                        console.error('Error closing ticket:', error);
                        failedCount++;
                    }
                }
                
                await interaction.editReply({
                    embeds: [new EmbedBuilder()
                        .setTitle('🔒 Mass Ticket Closure')
                        .setDescription(`Successfully closed ${closedCount} ticket(s).${failedCount > 0 ? `\nFailed to close ${failedCount} ticket(s).` : ''}`)
                        .addFields(
                            { name: 'Reason', value: reason, inline: false },
                            { name: 'Closed By', value: user.tag, inline: true },
                            { name: 'Total Closed', value: closedCount.toString(), inline: true }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK })
                    ]
                });
                
                // Update ticket list if configured
                await ticketManager.updateTicketList(guild.id);
                
            } else if (subcommand === 'listchannel') {
                // Set ticket list channel
                const channel = interaction.options.getChannel('channel');
                
                // Validate channel is text-based
                if (!channel.isTextBased() || channel.type === ChannelType.GuildVoice || channel.type === ChannelType.GuildCategory) {
                    return await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle(`${EMOJIS.error} Invalid Channel Type`)
                            .setDescription('Please select a text channel for the ticket list.')
                            .setColor(COLORS.ERROR)
                            .setTimestamp()
                            .setFooter({ text: config.BOT_WATERMARK })
                        ],
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                await db.run(
                    'INSERT OR REPLACE INTO ticket_list_channel (guild_id, channel_id, last_updated) VALUES (?, ?, ?)',
                    [guild.id, channel.id, new Date().toISOString()]
                );
                
                // Create initial list
                await ticketManager.updateTicketList(guild.id);
                
                await interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle('✅ Ticket List Channel Set')
                        .setDescription(`Ticket list will be displayed in ${channel}\n\nThe list will automatically update when tickets are created or closed.`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK })
                    ],
                    flags: [MessageFlags.Ephemeral]
                });
                
            } else if (subcommand === 'updatelist') {
                // Manually update ticket list
                await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
                
                const result = await ticketManager.updateTicketList(guild.id);
                
                if (result && result.success) {
                    await interaction.editReply({
                        embeds: [new EmbedBuilder()
                            .setTitle('✅ Ticket List Updated')
                            .setDescription('The ticket list has been updated successfully!')
                            .setColor(COLORS.SUCCESS)
                            .setTimestamp()
                            .setFooter({ text: config.BOT_WATERMARK })
                        ]
                    });
                } else {
                    await interaction.editReply({
                        content: `${EMOJIS.error} Failed to update ticket list. Make sure you have set a list channel with \`/ticket listchannel\``
                    });
                }
            }
            
        } else if (commandName === 'help') {
            const embed = new EmbedBuilder()
                .setTitle(`📚 ${client.user.username} - Complete Command Guide`)
                .setDescription('**A powerful all-in-one Discord bot with advanced features**\n\n*Use the commands below to manage your server effectively*')
                .setColor(COLORS.PRIMARY)
                .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
                .addFields(
                    { 
                        name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 
                        value: '** **', 
                        inline: false 
                    },
                    { 
                        name: `${EMOJIS.crown} **SUPER ADMIN COMMANDS**`, 
                        value: '```/superadmin add/remove/list - Manage bot super admins\n/botconfig - Configure bot-wide settings\n/extraowner add/remove/list - Manage server extra owners```', 
                        inline: false 
                    },
                    { 
                        name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 
                        value: '** **', 
                        inline: false 
                    },
                    { 
                        name: `${EMOJIS.shield} **SECURITY & PROTECTION**`, 
                        value: '```/antinuke enable/disable/config - Anti-nuke protection system\n/antinuke whitelist - Manage anti-nuke whitelist\n/antinuke logs - View security logs\n/antispam enable/disable/config - Anti-spam system\n/badwords add/remove/list - Bad words filter```', 
                        inline: false 
                    },
                    { 
                        name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 
                        value: '** **', 
                        inline: false 
                    },
                    { 
                        name: `${EMOJIS.hammer} **MODERATION COMMANDS**`, 
                        value: '```/ban - Ban a user from the server\n/kick - Kick a user from the server\n/timeout - Timeout a user (mute temporarily)\n/warn - Warn a user for rule violations\n/warnings - View user warnings\n/clearwarns - Clear user warnings\n/purge - Delete multiple messages at once\n/lock - Lock a channel\n/unlock - Unlock a channel\n/slowmode - Set channel slowmode```', 
                        inline: false 
                    },
                    { 
                        name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 
                        value: '** **', 
                        inline: false 
                    },
                    { 
                        name: `🎫 **TICKET SYSTEM**`, 
                        value: '```/ticket setup - Initial ticket system setup\n/ticket panel - Create a ticket panel\n/ticket panels - List all ticket panels\n/ticket editpanel - Edit existing panel\n/ticket deletepanel - Delete a panel\n/ticket closeall - Close all open tickets\n/ticket add - Add user to ticket\n/ticket remove - Remove user from ticket\n/ticket close - Close a ticket\n/ticket claim - Claim a ticket\n/ticket transcript - Generate ticket transcript\n/ticket stats - View ticket statistics\n/ticket addtype - Add ticket category\n/ticket listtypes - List ticket categories\n/ticket edittype - Edit ticket category\n/ticket deletetype - Delete ticket category\n/ticket config - Configure ticket settings```', 
                        inline: false 
                    },
                    { 
                        name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 
                        value: '** **', 
                        inline: false 
                    },
                    { 
                        name: `${EMOJIS.envelope} **WELCOME & GOODBYE**`, 
                        value: '```/welcome setup - Configure welcome messages\n/welcome test - Test welcome message\n/welcome disable - Disable welcome messages\n/goodbye setup - Configure goodbye messages\n/goodbye test - Test goodbye message\n/goodbye disable - Disable goodbye messages```', 
                        inline: false 
                    },
                    { 
                        name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 
                        value: '** **', 
                        inline: false 
                    },
                    { 
                        name: `${EMOJIS.envelope} **DM SYSTEM**`, 
                        value: '```/dm user - Send DM to specific user\n/dm role - Send DM to all users with a role\n/dm everyone - Send DM to all server members\n/dmlogs - View DM logs and history```', 
                        inline: false 
                    }
                )
                .setFooter({ text: `${config.BOT_WATERMARK} | Page 1/2 - Use buttons below to navigate` })
                .setTimestamp();

            const embed2 = new EmbedBuilder()
                .setTitle(`📚 ${client.user.username} - Complete Command Guide`)
                .setDescription('**Continued from previous page...**')
                .setColor(COLORS.PRIMARY)
                .setThumbnail(client.user.displayAvatarURL({ size: 256 }))
                .addFields(
                    { 
                        name: `${EMOJIS.invite} **INVITE TRACKING**`, 
                        value: '```/invites - Check your or someone\'s invite stats\n/inviteleaderboard - View top inviters\n/resetinvites - Reset user invite count (Admin)```', 
                        inline: false 
                    },
                    { 
                        name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 
                        value: '** **', 
                        inline: false 
                    },
                    { 
                        name: `${EMOJIS.gear} **UTILITY & TOOLS**`, 
                        value: '```/customcommand add/remove/list - Custom commands\n/giveaway start/end/reroll - Giveaway system\n/statusmonitor add/remove/list - Website monitoring\n/weather - Get weather information\n/qrcode - Generate QR codes\n/remindme - Set reminders\n/poll - Create polls\n/afk - Set AFK status```', 
                        inline: false 
                    },
                    { 
                        name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 
                        value: '** **', 
                        inline: false 
                    },
                    { 
                        name: `${EMOJIS.info} **INFORMATION COMMANDS**`, 
                        value: '```/serverinfo - View server information\n/userinfo - View user information\n/roleinfo - View role information\n/avatar - View user avatar\n/banner - View user banner\n/membercount - View member count\n/ping - Check bot latency\n/stats - View bot statistics\n/help - Show this help menu```', 
                        inline: false 
                    },
                    { 
                        name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 
                        value: '** **', 
                        inline: false 
                    },
                    { 
                        name: `⚙️ **SERVER MANAGEMENT**`, 
                        value: '```/autorole set/remove - Auto-assign roles to new members\n/stickyroles enable/disable - Restore roles on rejoin\n/addrole - Add role to user\n/removerole - Remove role from user\n/verifyconfig - Setup verification system\n/verify - Verify yourself\n/serverstats setup/remove - Server statistics channels```', 
                        inline: false 
                    },
                    { 
                        name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 
                        value: '** **', 
                        inline: false 
                    },
                    { 
                        name: `🎉 **FUN & ENGAGEMENT**`, 
                        value: '```/starboard setup/remove - Starboard system\n/reactionrole add/remove/list - Reaction roles\n/autopublish setup/remove - Auto-publish announcements```', 
                        inline: false 
                    },
                    { 
                        name: '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', 
                        value: '** **', 
                        inline: false 
                    },
                    { 
                        name: '💡 **QUICK TIPS**', 
                        value: '• Most commands require specific permissions\n• Use `/help` anytime to see this menu\n• Commands marked (Admin) require Manage Server\n• Protected users: Owner, Extra Owners, Super Admins\n• Join our support server for help and updates', 
                        inline: false 
                    }
                )
                .setFooter({ text: `${config.BOT_WATERMARK} | Page 2/2 - Total Commands: ${commands.length}` })
                .setTimestamp();

            // Create navigation buttons
            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('help_page_1')
                        .setLabel('◀ Page 1')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId('help_page_2')
                        .setLabel('Page 2 ▶')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setLabel('Support Server')
                        .setStyle(ButtonStyle.Link)
                        .setURL('https://discord.gg/your-support-server')
                        .setEmoji('🔗')
                );

            await interaction.reply({ embeds: [embed], components: [row] });
            
        } else if (commandName === 'ping') {
            const latency = Date.now() - interaction.createdTimestamp;
            const apiLatency = Math.round(client.ws.ping);
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.ping} Pong!`)
                .setColor(COLORS.SUCCESS)
                .addFields(
                    { name: 'Bot Latency', value: `${latency}ms`, inline: true },
                    { name: 'API Latency', value: `${apiLatency}ms`, inline: true },
                    { name: 'Uptime', value: botStartTime ? `<t:${Math.floor(botStartTime.getTime() / 1000)}:R>` : 'Unknown', inline: true }
                )
                .setFooter({ text: config.BOT_WATERMARK })
                .setTimestamp();
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'imagine') {
            // Image Generation Command
            const prompt = interaction.options.getString('prompt');
            const isPrivate = interaction.options.getBoolean('private') || false;

            await interaction.deferReply({ ephemeral: isPrivate });

            try {
                // Check cooldown
                const cooldown = imageGenerator.getCooldownTime(user.id);
                if (cooldown > 0) {
                    const embed = new EmbedBuilder()
                        .setTitle(`${EMOJIS.timer} Cooldown Active`)
                        .setDescription(`Please wait **${cooldown} seconds** before generating another image.`)
                        .setColor(COLORS.WARNING)
                        .setFooter({ text: config.BOT_WATERMARK })
                        .setTimestamp();
                    
                    return interaction.editReply({ embeds: [embed] });
                }

                // Get user roles for content filter
                const member = interaction.member;
                const userRoles = member ? member.roles.cache.map(r => r.id) : [];
                
                // Add admin flag if user has administrator permission
                if (member?.permissions.has(PermissionFlagsBits.Administrator)) {
                    userRoles.push('admin');
                }

                // Generate image
                const result = await imageGenerator.generateImage(prompt, user.id, userRoles);

                // Create embed with image
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.star} Image Generated!`)
                    .setDescription(`**Prompt:** ${prompt}`)
                    .setColor(COLORS.SUCCESS)
                    .setImage('attachment://generated.png')
                    .setFooter({ text: `Generated by ${user.tag} | ${config.BOT_WATERMARK}` })
                    .setTimestamp();

                // Add download button
                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setLabel('Download Image')
                            .setStyle(ButtonStyle.Link)
                            .setURL('https://discord.com/channels/@me')
                            .setEmoji('📥')
                    );

                await interaction.editReply({
                    embeds: [embed],
                    files: [{
                        attachment: result.buffer,
                        name: 'generated.png'
                    }]
                });

                console.log(`✓ Image generated for ${user.tag}: "${prompt}"`);

            } catch (error) {
                console.error('Image generation error:', error);
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.error} Generation Failed`)
                    .setDescription(error.message || 'Failed to generate image. Please try again later.')
                    .setColor(COLORS.ERROR)
                    .setFooter({ text: config.BOT_WATERMARK })
                    .setTimestamp();
                
                await interaction.editReply({ embeds: [embed] });
            }
            
        } else if (commandName === 'imagehistory') {
            // Image History Command
            const limit = interaction.options.getInteger('limit') || 5;

            await interaction.deferReply({ ephemeral: true });

            try {
                const history = await imageGenerator.getImageHistory(user.id, limit);

                if (history.length === 0) {
                    const embed = new EmbedBuilder()
                        .setTitle(`${EMOJIS.info} No Image History`)
                        .setDescription('You haven\'t generated any images yet! Use `/imagine` to create your first image.')
                        .setColor(COLORS.INFO)
                        .setFooter({ text: config.BOT_WATERMARK })
                        .setTimestamp();
                    
                    return interaction.editReply({ embeds: [embed] });
                }

                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.headphones} Your Image History`)
                    .setDescription(`Showing your last ${history.length} generated image(s)`)
                    .setColor(COLORS.PRIMARY)
                    .setFooter({ text: config.BOT_WATERMARK })
                    .setTimestamp();

                history.forEach((img, index) => {
                    embed.addFields({
                        name: `${index + 1}. ${img.filename}`,
                        value: `Generated: <t:${Math.floor(img.timestamp / 1000)}:R>`,
                        inline: false
                    });
                });

                await interaction.editReply({ embeds: [embed] });

            } catch (error) {
                console.error('Image history error:', error);
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.error} Error`)
                    .setDescription('Failed to retrieve image history.')
                    .setColor(COLORS.ERROR)
                    .setFooter({ text: config.BOT_WATERMARK })
                    .setTimestamp();
                
                await interaction.editReply({ embeds: [embed] });
            }
            
        } else if (commandName === 'imagestats') {
            // Image Stats Command
            await interaction.deferReply({ ephemeral: true });

            try {
                const stats = imageGenerator.getStats();
                const cooldown = imageGenerator.getCooldownTime(user.id);

                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.stats} Image Generation Statistics`)
                    .setColor(COLORS.INFO)
                    .addFields(
                        { name: '📊 Total Images Generated', value: stats.totalImages.toString(), inline: true },
                        { name: '💾 Total Storage Used', value: `${stats.totalSizeMB} MB`, inline: true },
                        { name: '⏰ Active Cooldowns', value: stats.activeCooldowns.toString(), inline: true },
                        { name: '🎨 Your Cooldown', value: cooldown > 0 ? `${cooldown} seconds` : 'Ready!', inline: true },
                        { name: '⚙️ API Status', value: config.IMAGE_GENERATION?.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                        { name: '📁 Save Images', value: config.IMAGE_GENERATION?.save_images ? '✅ Yes' : '❌ No', inline: true }
                    )
                    .setFooter({ text: config.BOT_WATERMARK })
                    .setTimestamp();

                await interaction.editReply({ embeds: [embed] });

            } catch (error) {
                console.error('Image stats error:', error);
                
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.error} Error`)
                    .setDescription('Failed to retrieve statistics.')
                    .setColor(COLORS.ERROR)
                    .setFooter({ text: config.BOT_WATERMARK })
                    .setTimestamp();
                
                await interaction.editReply({ embeds: [embed] });
            }
            
        } else if (commandName === 'stats') {
            const guilds = client.guilds.cache.size;
            const users = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);
            const channels = client.guilds.cache.reduce((acc, guild) => acc + guild.channels.cache.size, 0);
            const commandsCount = commands.length;
            
            const embed = new EmbedBuilder()
                .setTitle(`${client.user.username} Statistics`)
                .setColor(COLORS.INFO)
                .addFields(
                    { name: 'Servers', value: guilds.toString(), inline: true },
                    { name: 'Users', value: users.toString(), inline: true },
                    { name: 'Channels', value: channels.toString(), inline: true },
                    { name: 'Commands', value: commandsCount.toString(), inline: true },
                    { name: 'Uptime', value: botStartTime ? `<t:${Math.floor(botStartTime.getTime() / 1000)}:R>` : 'Unknown', inline: true },
                    { name: 'Ping', value: `${Math.round(client.ws.ping)}ms`, inline: true }
                )
                .setFooter({ text: config.BOT_WATERMARK })
                .setTimestamp();
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'serverinfo') {
            const owner = await guild.fetchOwner();
            const categories = guild.channels.cache.filter(c => c.type === ChannelType.GuildCategory).size;
            const textChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildText).size;
            const voiceChannels = guild.channels.cache.filter(c => c.type === ChannelType.GuildVoice).size;
            const roles = guild.roles.cache.size;
            const emojis = guild.emojis.cache.size;
            const boosts = guild.premiumSubscriptionCount || 0;
            const boostLevel = guild.premiumTier || 0;
            
            const embed = new EmbedBuilder()
                .setTitle(guild.name)
                .setThumbnail(guild.iconURL({ size: 4096 }))
                .setColor(COLORS.PRIMARY)
                .addFields(
                    { name: 'Owner', value: owner.user.tag, inline: true },
                    { name: 'Members', value: guild.memberCount.toString(), inline: true },
                    { name: 'Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
                    { name: 'Channels', value: `${categories} Categories\n${textChannels} Text / ${voiceChannels} Voice`, inline: true },
                    { name: 'Roles', value: roles.toString(), inline: true },
                    { name: 'Emojis', value: emojis.toString(), inline: true },
                    { name: 'Boosts', value: `Level ${boostLevel} (${boosts} boosts)`, inline: true }
                )
                .setFooter({ text: `ID: ${guild.id}` })
                .setTimestamp();
            
            if (guild.banner) embed.setImage(guild.bannerURL({ size: 4096 }));
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'userinfo') {
            const target = interaction.options.getUser('user') || user;
            const targetMember = await guild.members.fetch(target.id).catch(() => null);
            
            const embed = new EmbedBuilder()
                .setTitle(target.tag)
                .setThumbnail(target.displayAvatarURL({ size: 4096 }))
                .setColor(targetMember?.displayHexColor || COLORS.PRIMARY)
                .addFields(
                    { name: 'ID', value: target.id, inline: true },
                    { name: 'Account Created', value: `<t:${Math.floor(target.createdTimestamp / 1000)}:R>`, inline: true },
                    { name: 'Bot', value: target.bot ? 'Yes' : 'No', inline: true }
                )
                .setFooter({ text: config.BOT_WATERMARK })
                .setTimestamp();
            
            if (targetMember) {
                embed.addFields(
                    { name: 'Joined Server', value: `<t:${Math.floor(targetMember.joinedTimestamp / 1000)}:R>`, inline: true },
                    { name: 'Roles', value: targetMember.roles.cache.size.toString(), inline: true },
                    { name: 'Highest Role', value: targetMember.roles.highest.toString(), inline: true }
                );
                
                if (targetMember.premiumSince) {
                    embed.addFields({ name: 'Boosting Since', value: `<t:${Math.floor(targetMember.premiumSinceTimestamp / 1000)}:R>`, inline: true });
                }
            }
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'roleinfo') {
            const role = interaction.options.getRole('role');
            
            const embed = new EmbedBuilder()
                .setTitle(role.name)
                .setColor(role.color || COLORS.PRIMARY)
                .addFields(
                    { name: 'ID', value: role.id, inline: true },
                    { name: 'Color', value: role.hexColor, inline: true },
                    { name: 'Members', value: role.members.size.toString(), inline: true },
                    { name: 'Position', value: role.position.toString(), inline: true },
                    { name: 'Created', value: `<t:${Math.floor(role.createdTimestamp / 1000)}:R>`, inline: true },
                    { name: 'Hoisted', value: role.hoist ? 'Yes' : 'No', inline: true },
                    { name: 'Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },
                    { name: 'Managed', value: role.managed ? 'Yes' : 'No', inline: true },
                    { name: 'Permissions', value: role.permissions.toArray().length.toString(), inline: true }
                )
                .setFooter({ text: config.BOT_WATERMARK })
                .setTimestamp();
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'avatar') {
            const target = interaction.options.getUser('user') || user;
            
            const embed = new EmbedBuilder()
                .setTitle(`${target.username}'s Avatar`)
                .setImage(target.displayAvatarURL({ size: 4096, dynamic: true }))
                .setColor(COLORS.PRIMARY)
                .setFooter({ text: config.BOT_WATERMARK })
                .setTimestamp();
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'banner') {
            const target = interaction.options.getUser('user') || user;
            const bannerUrl = target.bannerURL({ size: 4096, dynamic: true });
            
            if (!bannerUrl) {
                return interaction.reply({
                    content: `${EMOJIS.info} ${target.username} doesn't have a banner.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            const embed = new EmbedBuilder()
                .setTitle(`${target.username}'s Banner`)
                .setImage(bannerUrl)
                .setColor(COLORS.PRIMARY)
                .setFooter({ text: config.BOT_WATERMARK })
                .setTimestamp();
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'membercount') {
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.users} Member Count`)
                .setDescription(`**${guild.name}** has **${guild.memberCount}** members.`)
                .addFields(
                    { name: 'Humans', value: guild.members.cache.filter(m => !m.user.bot).size.toString(), inline: true },
                    { name: 'Bots', value: guild.members.cache.filter(m => m.user.bot).size.toString(), inline: true }
                )
                .setColor(COLORS.INFO)
                .setFooter({ text: config.BOT_WATERMARK })
                .setTimestamp();
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'afk') {
            let reason = interaction.options.getString('reason') || 'AFK';
            // Sanitize reason to prevent @everyone, @here, and user mentions
            reason = sanitizeMentions(reason);
            
            await db.run(
                'INSERT OR REPLACE INTO afk (guild_id, user_id, reason, timestamp) VALUES (?, ?, ?, ?)',
                [guild.id, user.id, reason, new Date().toISOString()]
            );
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.afk} AFK Status Set`)
                .setDescription(`You are now AFK: **${reason}**`)
                .setColor(COLORS.WARNING)
                .setFooter({ text: config.BOT_WATERMARK })
                .setTimestamp();
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'invites') {
            const targetUser = interaction.options.getUser('user') || user;
            
            await interaction.deferReply();
            
            const stats = await inviteTracker.getInviteStats(guild.id, targetUser.id);
            
            if (!stats || stats.total_invites === 0) {
                return interaction.editReply({
                    content: `${EMOJIS.info} ${targetUser.tag} has not invited anyone yet.`
                });
            }
            
            const embed = new EmbedBuilder()
                .setTitle(`📊 Invite Statistics - ${targetUser.tag}`)
                .setThumbnail(targetUser.displayAvatarURL({ size: 256 }))
                .setColor(COLORS.INFO)
                .addFields(
                    { name: '✅ Valid Invites', value: stats.valid_invites.toString(), inline: true },
                    { name: '📊 Total Invites', value: stats.total_invites.toString(), inline: true },
                    { name: '🚫 Fake Invites', value: stats.fake_invites.toString(), inline: true },
                    { name: '👋 Left Server', value: stats.left_invites.toString(), inline: true },
                    { name: '🎯 Success Rate', value: stats.total_invites > 0 ? `${Math.round((stats.valid_invites / stats.total_invites) * 100)}%` : '0%', inline: true }
                )
                .setFooter({ text: config.BOT_WATERMARK })
                .setTimestamp();
            
            await interaction.editReply({ embeds: [embed] });
            
        } else if (commandName === 'inviteleaderboard') {
            const limit = interaction.options.getInteger('limit') || 10;
            
            await interaction.deferReply();
            
            const leaderboard = await inviteTracker.getLeaderboard(guild.id, Math.min(limit, 25));
            
            if (leaderboard.length === 0) {
                return interaction.editReply({
                    content: `${EMOJIS.info} No invite data available yet.`
                });
            }
            
            const embed = new EmbedBuilder()
                .setTitle(`🏆 Top Inviters - ${guild.name}`)
                .setColor(COLORS.PRIMARY)
                .setFooter({ text: config.BOT_WATERMARK })
                .setTimestamp();
            
            let description = '';
            for (let i = 0; i < leaderboard.length; i++) {
                const stat = leaderboard[i];
                const member = await guild.members.fetch(stat.user_id).catch(() => null);
                const username = member ? member.user.tag : 'Unknown User';
                
                const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
                description += `${medal} **${username}** - ${stat.valid_invites} invites\n`;
            }
            
            embed.setDescription(description);
            
            await interaction.editReply({ embeds: [embed] });
            
        } else if (commandName === 'resetinvites') {
            const targetUser = interaction.options.getUser('user');
            
            await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
            
            const success = await inviteTracker.resetInvites(guild.id, targetUser.id);
            
            if (success) {
                await interaction.editReply({
                    embeds: [new EmbedBuilder()
                        .setTitle('✅ Invites Reset')
                        .setDescription(`Successfully reset invite count for ${targetUser}`)
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK })
                    ]
                });
            } else {
                await interaction.editReply({
                    content: `${EMOJIS.error} Failed to reset invites for ${targetUser}`
                });
            }
            
        } else if (commandName === 'addrole') {
            const target = interaction.options.getUser('user');
            const role = interaction.options.getRole('role');
            
            const targetMember = await guild.members.fetch(target.id).catch(() => null);
            if (!targetMember) {
                return interaction.reply({
                    content: `${EMOJIS.error} User not found in this server.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            if (targetMember.roles.cache.has(role.id)) {
                return interaction.reply({
                    content: `${EMOJIS.error} User already has this role.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            await targetMember.roles.add(role);
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.success} Role Added`)
                .setDescription(`Added **${role.name}** to ${target.tag}.`)
                .setColor(COLORS.SUCCESS)
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            await logModeration(guild.id, 'add_role', target.id, user.id, role.name);
            
        } else if (commandName === 'removerole') {
            const target = interaction.options.getUser('user');
            const role = interaction.options.getRole('role');
            
            const targetMember = await guild.members.fetch(target.id).catch(() => null);
            if (!targetMember) {
                return interaction.reply({
                    content: `${EMOJIS.error} User not found in this server.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            if (!targetMember.roles.cache.has(role.id)) {
                return interaction.reply({
                    content: `${EMOJIS.error} User doesn't have this role.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            await targetMember.roles.remove(role);
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.success} Role Removed`)
                .setDescription(`Removed **${role.name}** from ${target.tag}.`)
                .setColor(COLORS.WARNING)
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            await logModeration(guild.id, 'remove_role', target.id, user.id, role.name);
            
        } else if (commandName === 'massrole') {
            const subcommand = interaction.options.getSubcommand();

            if (subcommand === 'status') {
                const op = massRoleOps.get(guild.id);
                if (!op || op.completed) {
                    return interaction.reply({
                        content: `${EMOJIS.info} No mass role operation is currently running.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                const progress = Math.round((op.processed / op.total) * 100);
                const elapsed = Math.round((Date.now() - op.startTime) / 1000);
                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.gear} Mass Role Operation In Progress`)
                    .setColor(COLORS.INFO)
                    .addFields(
                        { name: 'Action', value: op.action.toUpperCase(), inline: true },
                        { name: 'Role', value: op.roleName, inline: true },
                        { name: 'Progress', value: `${op.processed}/${op.total} (${progress}%)`, inline: true },
                        { name: 'Successes', value: `${op.success}`, inline: true },
                        { name: 'Failures', value: `${op.failed}`, inline: true },
                        { name: 'Elapsed', value: `${elapsed}s`, inline: true }
                    )
                    .setTimestamp();

                return interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
            }

            // Check for already running operation
            const existingOp = massRoleOps.get(guild.id);
            if (existingOp && !existingOp.completed) {
                return interaction.reply({
                    content: `${EMOJIS.error} A mass role operation is already running in this server. Use \`/massrole status\` to check progress.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }

            const role = interaction.options.getRole('role');
            const filterRole = interaction.options.getRole('filter_role');
            const includeBots = interaction.options.getBoolean('include_bots') || false;

            // Validate role hierarchy - bot must be higher than the target role
            const botMember = guild.members.me;
            if (role.position >= botMember.roles.highest.position) {
                return interaction.reply({
                    content: `${EMOJIS.error} I cannot manage the role **${role.name}** because it's higher than or equal to my highest role.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }

            // Cannot assign @everyone or managed roles
            if (role.id === guild.id) {
                return interaction.reply({
                    content: `${EMOJIS.error} You cannot mass-assign the @everyone role.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }

            if (role.managed) {
                return interaction.reply({
                    content: `${EMOJIS.error} The role **${role.name}** is managed by an integration and cannot be manually assigned.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }

            // Check user's role hierarchy
            if (role.position >= member.roles.highest.position && guild.ownerId !== user.id) {
                return interaction.reply({
                    content: `${EMOJIS.error} You cannot manage the role **${role.name}** because it's higher than or equal to your highest role.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }

            await interaction.deferReply();

            // Fetch all members
            let members;
            try {
                members = await guild.members.fetch();
            } catch (e) {
                return interaction.editReply({
                    content: `${EMOJIS.error} Failed to fetch server members. Please try again.`
                });
            }

            // Filter members based on criteria
            let targetMembers = members.filter(m => {
                // Exclude bots if not included
                if (!includeBots && m.user.bot) return false;
                // Filter by role if specified
                if (filterRole && !m.roles.cache.has(filterRole.id)) return false;

                if (subcommand === 'add') {
                    // Only include members who don't already have the role
                    return !m.roles.cache.has(role.id);
                } else {
                    // Only include members who have the role
                    return m.roles.cache.has(role.id);
                }
            });

            const totalMembers = targetMembers.size;

            if (totalMembers === 0) {
                const noTargetEmbed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.info} No Members to Process`)
                    .setDescription(subcommand === 'add'
                        ? `All eligible members already have the role **${role.name}**.`
                        : `No eligible members have the role **${role.name}**.`)
                    .setColor(COLORS.WARNING)
                    .setTimestamp();
                return interaction.editReply({ embeds: [noTargetEmbed] });
            }

            // Initialize operation tracking
            const operation = {
                action: subcommand,
                roleName: role.name,
                roleId: role.id,
                total: totalMembers,
                processed: 0,
                success: 0,
                failed: 0,
                startTime: Date.now(),
                completed: false,
                requestedBy: user.id
            };
            massRoleOps.set(guild.id, operation);

            // Send initial status
            const startEmbed = new EmbedBuilder()
                .setTitle(`${EMOJIS.gear} Mass Role Operation Started`)
                .setColor(COLORS.INFO)
                .setDescription(`${subcommand === 'add' ? 'Adding' : 'Removing'} role **${role.name}** ${subcommand === 'add' ? 'to' : 'from'} **${totalMembers}** members...`)
                .addFields(
                    { name: 'Role', value: `${role}`, inline: true },
                    { name: 'Members', value: `${totalMembers}`, inline: true },
                    { name: 'Filter', value: filterRole ? `Members with ${filterRole}` : 'All members', inline: true },
                    { name: 'Include Bots', value: includeBots ? 'Yes' : 'No', inline: true }
                )
                .setFooter({ text: `Requested by ${user.tag} | Use /massrole status to check progress` })
                .setTimestamp();

            await interaction.editReply({ embeds: [startEmbed] });

            // Process members in background (non-blocking)
            const membersArray = [...targetMembers.values()];
            const BATCH_SIZE = 5;
            const DELAY_BETWEEN_BATCHES = 2000; // 2 seconds between batches to avoid rate limits

            (async () => {
                for (let i = 0; i < membersArray.length; i += BATCH_SIZE) {
                    const batch = membersArray.slice(i, i + BATCH_SIZE);

                    await Promise.allSettled(batch.map(async (m) => {
                        try {
                            if (subcommand === 'add') {
                                await m.roles.add(role, `Mass role add by ${user.tag}`);
                            } else {
                                await m.roles.remove(role, `Mass role remove by ${user.tag}`);
                            }
                            operation.success++;
                        } catch (e) {
                            operation.failed++;
                        }
                        operation.processed++;
                    }));

                    // Rate limit protection
                    if (i + BATCH_SIZE < membersArray.length) {
                        await new Promise(resolve => setTimeout(resolve, DELAY_BETWEEN_BATCHES));
                    }
                }

                // Mark operation as complete
                operation.completed = true;
                const elapsed = Math.round((Date.now() - operation.startTime) / 1000);

                // Send completion message
                const completeEmbed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.success} Mass Role Operation Complete`)
                    .setColor(COLORS.SUCCESS)
                    .setDescription(`${subcommand === 'add' ? 'Added' : 'Removed'} role **${role.name}** ${subcommand === 'add' ? 'to' : 'from'} members.`)
                    .addFields(
                        { name: '\u2705 Successful', value: `${operation.success}`, inline: true },
                        { name: '\u274c Failed', value: `${operation.failed}`, inline: true },
                        { name: '\u23f1\ufe0f Duration', value: `${elapsed}s`, inline: true }
                    )
                    .setFooter({ text: `Requested by ${user.tag} | ${config.BOT_WATERMARK}` })
                    .setTimestamp();

                try {
                    await interaction.channel.send({ embeds: [completeEmbed] });
                } catch (e) {
                    // Channel might be deleted or bot lost access
                }

                // Clean up after 5 minutes
                setTimeout(() => {
                    if (massRoleOps.get(guild.id)?.startTime === operation.startTime) {
                        massRoleOps.delete(guild.id);
                    }
                }, 300000);
            })();

        } else if (commandName === 'review') {
            const subcommand = interaction.options.getSubcommand();

            if (subcommand === 'setup') {
                // Admin only
                if (!member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                    return interaction.reply({
                        content: `${EMOJIS.error} You need **Manage Server** permission to setup the review system.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                const reviewChannel = interaction.options.getChannel('review_channel');
                const logChannel = interaction.options.getChannel('log_channel');
                const maxReviews = interaction.options.getInteger('max_reviews') || 3;
                const cooldownHours = interaction.options.getInteger('cooldown_hours') || 24;
                const allowAnonymous = interaction.options.getBoolean('allow_anonymous') ? 1 : 0;
                const requireRole = interaction.options.getRole('require_role');

                await db.run(
                    `INSERT OR REPLACE INTO review_config (guild_id, enabled, review_channel_id, log_channel_id, max_reviews_per_user, cooldown_hours, allow_anonymous, require_role_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                    [guild.id, 1, reviewChannel.id, logChannel?.id || null, maxReviews, cooldownHours, allowAnonymous, requireRole?.id || null]
                );

                const embed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.success} Review System Configured`)
                    .setColor(COLORS.SUCCESS)
                    .addFields(
                        { name: '\u2b50 Review Channel', value: `${reviewChannel}`, inline: true },
                        { name: '\ud83d\udcdd Log Channel', value: logChannel ? `${logChannel}` : 'Not set', inline: true },
                        { name: '\ud83d\udc64 Max Reviews/User', value: `${maxReviews}`, inline: true },
                        { name: '\u23f1\ufe0f Cooldown', value: `${cooldownHours} hours`, inline: true },
                        { name: '\ud83d\udc7b Anonymous', value: allowAnonymous ? 'Allowed' : 'Not allowed', inline: true },
                        { name: '\ud83c\udfad Required Role', value: requireRole ? `${requireRole}` : 'None', inline: true }
                    )
                    .setTimestamp()
                    .setFooter({ text: config.BOT_WATERMARK });

                await interaction.reply({ embeds: [embed] });

            } else if (subcommand === 'submit') {
                const reviewConfig = await db.get('SELECT * FROM review_config WHERE guild_id = ?', [guild.id]);

                if (!reviewConfig || !reviewConfig.enabled) {
                    return interaction.reply({
                        content: `${EMOJIS.error} The review system is not configured in this server. Ask an admin to use \`/review setup\`.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                // Check if user has required role
                if (reviewConfig.require_role_id && !member.roles.cache.has(reviewConfig.require_role_id)) {
                    return interaction.reply({
                        content: `${EMOJIS.error} You need the <@&${reviewConfig.require_role_id}> role to leave a review.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                // Check account age
                const accountAgeDays = Math.floor((Date.now() - user.createdTimestamp) / (1000 * 60 * 60 * 24));
                if (accountAgeDays < (reviewConfig.min_account_age_days || 7)) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Your account must be at least **${reviewConfig.min_account_age_days || 7} days** old to leave a review.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                // Check max reviews per user
                const userReviewCount = await db.get(
                    'SELECT COUNT(*) as count FROM reviews WHERE guild_id = ? AND user_id = ? AND status = ?',
                    [guild.id, user.id, 'published']
                );

                if (userReviewCount && userReviewCount.count >= reviewConfig.max_reviews_per_user) {
                    return interaction.reply({
                        content: `${EMOJIS.error} You have reached the maximum of **${reviewConfig.max_reviews_per_user}** reviews for this server.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                // Check cooldown
                const lastReview = await db.get(
                    'SELECT created_at FROM reviews WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT 1',
                    [guild.id, user.id]
                );

                if (lastReview) {
                    const lastReviewTime = new Date(lastReview.created_at).getTime();
                    const cooldownMs = (reviewConfig.cooldown_hours || 24) * 60 * 60 * 1000;
                    const timeLeft = (lastReviewTime + cooldownMs) - Date.now();

                    if (timeLeft > 0) {
                        const hoursLeft = Math.ceil(timeLeft / (1000 * 60 * 60));
                        return interaction.reply({
                            content: `${EMOJIS.error} You must wait **${hoursLeft} hour(s)** before submitting another review.`,
                            flags: [MessageFlags.Ephemeral]
                        });
                    }
                }

                const rating = interaction.options.getInteger('rating');
                const note = interaction.options.getString('note') || null;
                const anonymous = interaction.options.getBoolean('anonymous') || false;

                // Check if anonymous is allowed
                if (anonymous && !reviewConfig.allow_anonymous) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Anonymous reviews are not allowed in this server.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

                const stars = '\u2b50'.repeat(rating) + '\u2606'.repeat(5 - rating);
                const now = new Date().toISOString();

                // Insert the review
                const result = await db.run(
                    'INSERT INTO reviews (guild_id, user_id, rating, note, anonymous, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                    [guild.id, user.id, rating, note, anonymous ? 1 : 0, now]
                );

                const reviewId = result.lastID;

                // Post to review channel
                const reviewChannel = guild.channels.cache.get(reviewConfig.review_channel_id);
                if (reviewChannel) {
                    const reviewEmbed = new EmbedBuilder()
                        .setTitle(`\u2b50 New Review #${reviewId}`)
                        .setColor(rating >= 4 ? COLORS.SUCCESS : rating >= 3 ? COLORS.WARNING : COLORS.ERROR)
                        .addFields(
                            { name: 'Rating', value: stars, inline: true },
                            { name: 'Reviewer', value: anonymous ? '\ud83d\udc7b Anonymous' : `<@${user.id}>`, inline: true },
                            { name: 'Date', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true }
                        )
                        .setTimestamp()
                        .setFooter({ text: `Review ID: ${reviewId} | ${config.BOT_WATERMARK}` });

                    if (note) {
                        reviewEmbed.setDescription(`\u201c${note}\u201d`);
                    }

                    if (!anonymous) {
                        reviewEmbed.setThumbnail(user.displayAvatarURL({ dynamic: true, size: 64 }));
                    }

                    const msg = await reviewChannel.send({ embeds: [reviewEmbed] }).catch(() => null);
                    if (msg) {
                        await db.run('UPDATE reviews SET message_id = ? WHERE id = ?', [msg.id, reviewId]);
                        // Add star reactions for visual appeal
                        try { await msg.react('\u2b50'); } catch (e) {}
                    }
                }

                // Post to log channel
                const logChannel = reviewConfig.log_channel_id ? guild.channels.cache.get(reviewConfig.log_channel_id) : null;
                if (logChannel) {
                    const logEmbed = new EmbedBuilder()
                        .setTitle(`\ud83d\udcdd New Review Submitted`)
                        .setColor(COLORS.INFO)
                        .addFields(
                            { name: 'Review ID', value: `#${reviewId}`, inline: true },
                            { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
                            { name: 'Rating', value: stars, inline: true },
                            { name: 'Anonymous', value: anonymous ? 'Yes' : 'No', inline: true },
                            { name: 'Note', value: note || 'No note provided', inline: false }
                        )
                        .setTimestamp();

                    await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
                }

                // Confirm to user
                const confirmEmbed = new EmbedBuilder()
                    .setTitle(`${EMOJIS.success} Review Submitted!`)
                    .setColor(COLORS.SUCCESS)
                    .setDescription(`Thank you for your review! Your feedback is appreciated.`)
                    .addFields(
                        { name: 'Rating', value: stars, inline: true },
                        { name: 'Review ID', value: `#${reviewId}`, inline: true }
                    )
                    .setTimestamp();

                if (note) {
                    confirmEmbed.addFields({ name: 'Your Note', value: note, inline: false });
                }

                await interaction.editReply({ embeds: [confirmEmbed] });

            } else if (subcommand === 'list') {
                const page = interaction.options.getInteger('page') || 1;
                const filterUser = interaction.options.getUser('user');
                const perPage = 5;
                const offset = (page - 1) * perPage;

                let query = 'SELECT * FROM reviews WHERE guild_id = ? AND status = ?';
                let countQuery = 'SELECT COUNT(*) as count FROM reviews WHERE guild_id = ? AND status = ?';
                let params = [guild.id, 'published'];

                if (filterUser) {
                    query += ' AND user_id = ?';
                    countQuery += ' AND user_id = ?';
                    params.push(filterUser.id);
                }

                query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';

                const totalResult = await db.get(countQuery, params);
                const totalReviews = totalResult?.count || 0;
                const totalPages = Math.ceil(totalReviews / perPage) || 1;

                const reviews = await db.all(query, [...params, perPage, offset]);

                if (!reviews || reviews.length === 0) {
                    return interaction.reply({
                        content: `${EMOJIS.info} No reviews found${filterUser ? ` for ${filterUser.tag}` : ''}.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                // Calculate average rating
                const avgResult = await db.get('SELECT AVG(rating) as avg, COUNT(*) as total FROM reviews WHERE guild_id = ? AND status = ?', [guild.id, 'published']);
                const avgRating = avgResult?.avg ? avgResult.avg.toFixed(1) : '0.0';

                let description = '';
                for (const review of reviews) {
                    const stars = '\u2b50'.repeat(review.rating) + '\u2606'.repeat(5 - review.rating);
                    const reviewer = review.anonymous ? '\ud83d\udc7b Anonymous' : `<@${review.user_id}>`;
                    const date = `<t:${Math.floor(new Date(review.created_at).getTime() / 1000)}:R>`;
                    description += `**#${review.id}** | ${stars} | ${reviewer} | ${date}\n`;
                    if (review.note) {
                        description += `> ${review.note.substring(0, 100)}${review.note.length > 100 ? '...' : ''}\n`;
                    }
                    description += '\n';
                }

                const embed = new EmbedBuilder()
                    .setTitle(`\u2b50 Server Reviews ${filterUser ? `by ${filterUser.tag}` : ''}`)
                    .setColor(COLORS.INFO)
                    .setDescription(description)
                    .addFields(
                        { name: 'Average Rating', value: `${avgRating}/5.0 \u2b50`, inline: true },
                        { name: 'Total Reviews', value: `${totalReviews}`, inline: true },
                        { name: 'Page', value: `${page}/${totalPages}`, inline: true }
                    )
                    .setTimestamp()
                    .setFooter({ text: config.BOT_WATERMARK });

                await interaction.reply({ embeds: [embed] });

            } else if (subcommand === 'stats') {
                const stats = await db.get(
                    'SELECT COUNT(*) as total, AVG(rating) as avg, MIN(rating) as min, MAX(rating) as max FROM reviews WHERE guild_id = ? AND status = ?',
                    [guild.id, 'published']
                );

                const ratingDistribution = await db.all(
                    'SELECT rating, COUNT(*) as count FROM reviews WHERE guild_id = ? AND status = ? GROUP BY rating ORDER BY rating DESC',
                    [guild.id, 'published']
                );

                const total = stats?.total || 0;
                const avg = stats?.avg ? stats.avg.toFixed(2) : '0.00';

                // Build distribution bars
                let distributionStr = '';
                for (let i = 5; i >= 1; i--) {
                    const found = ratingDistribution.find(r => r.rating === i);
                    const count = found ? found.count : 0;
                    const percentage = total > 0 ? Math.round((count / total) * 100) : 0;
                    const barLength = Math.round(percentage / 10);
                    const bar = '\u2588'.repeat(barLength) + '\u2591'.repeat(10 - barLength);
                    distributionStr += `${'\u2b50'.repeat(i)}${'\u2606'.repeat(5 - i)} \u2502 ${bar} ${count} (${percentage}%)\n`;
                }

                // Recent reviewers
                const recentReviews = await db.all(
                    'SELECT user_id, rating, created_at FROM reviews WHERE guild_id = ? AND status = ? AND anonymous = 0 ORDER BY created_at DESC LIMIT 5',
                    [guild.id, 'published']
                );

                let recentStr = recentReviews.length > 0
                    ? recentReviews.map(r => `<@${r.user_id}> - ${'\u2b50'.repeat(r.rating)} (<t:${Math.floor(new Date(r.created_at).getTime() / 1000)}:R>)`).join('\n')
                    : 'No public reviews yet.';

                const embed = new EmbedBuilder()
                    .setTitle(`\ud83d\udcca Review Statistics - ${guild.name}`)
                    .setColor(COLORS.PRIMARY)
                    .setThumbnail(guild.iconURL({ dynamic: true, size: 128 }))
                    .addFields(
                        { name: '\u2b50 Average Rating', value: `**${avg}** / 5.0`, inline: true },
                        { name: '\ud83d\udcdd Total Reviews', value: `${total}`, inline: true },
                        { name: '\ud83d\udcc8 Highest', value: `${stats?.max || 0} \u2b50`, inline: true },
                        { name: '\ud83d\udcc9 Lowest', value: `${stats?.min || 0} \u2b50`, inline: true },
                        { name: '\ud83d\udcca Rating Distribution', value: `\`\`\`\n${distributionStr}\`\`\``, inline: false },
                        { name: '\ud83d\udd51 Recent Reviews', value: recentStr, inline: false }
                    )
                    .setTimestamp()
                    .setFooter({ text: config.BOT_WATERMARK });

                await interaction.reply({ embeds: [embed] });

            } else if (subcommand === 'delete') {
                const reviewId = interaction.options.getInteger('review_id');

                const review = await db.get('SELECT * FROM reviews WHERE id = ? AND guild_id = ?', [reviewId, guild.id]);

                if (!review) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Review #${reviewId} not found.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                // Only the author or admins can delete
                if (review.user_id !== user.id && !member.permissions.has(PermissionFlagsBits.ManageGuild)) {
                    return interaction.reply({
                        content: `${EMOJIS.error} You can only delete your own reviews, or need **Manage Server** permission.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                // Soft delete
                await db.run('UPDATE reviews SET status = ? WHERE id = ?', ['deleted', reviewId]);

                // Try to delete the message from review channel
                const reviewConfig = await db.get('SELECT * FROM review_config WHERE guild_id = ?', [guild.id]);
                if (reviewConfig?.review_channel_id && review.message_id) {
                    try {
                        const channel = guild.channels.cache.get(reviewConfig.review_channel_id);
                        if (channel) {
                            const msg = await channel.messages.fetch(review.message_id).catch(() => null);
                            if (msg) await msg.delete().catch(() => {});
                        }
                    } catch (e) {}
                }

                await interaction.reply({
                    content: `${EMOJIS.success} Review #${reviewId} has been deleted.`,
                    flags: [MessageFlags.Ephemeral]
                });

            } else if (subcommand === 'edit') {
                const reviewId = interaction.options.getInteger('review_id');
                const newRating = interaction.options.getInteger('rating');
                const newNote = interaction.options.getString('note');

                if (!newRating && !newNote) {
                    return interaction.reply({
                        content: `${EMOJIS.error} You must provide at least a new rating or a new note to edit.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                const review = await db.get('SELECT * FROM reviews WHERE id = ? AND guild_id = ? AND status = ?', [reviewId, guild.id, 'published']);

                if (!review) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Review #${reviewId} not found.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                // Only the author can edit
                if (review.user_id !== user.id) {
                    return interaction.reply({
                        content: `${EMOJIS.error} You can only edit your own reviews.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }

                const updatedRating = newRating || review.rating;
                const updatedNote = newNote !== null ? newNote : review.note;
                const editedAt = new Date().toISOString();

                await db.run(
                    'UPDATE reviews SET rating = ?, note = ?, edited_at = ? WHERE id = ?',
                    [updatedRating, updatedNote, editedAt, reviewId]
                );

                // Update the message in review channel
                const reviewConfig = await db.get('SELECT * FROM review_config WHERE guild_id = ?', [guild.id]);
                if (reviewConfig?.review_channel_id && review.message_id) {
                    try {
                        const channel = guild.channels.cache.get(reviewConfig.review_channel_id);
                        if (channel) {
                            const msg = await channel.messages.fetch(review.message_id).catch(() => null);
                            if (msg) {
                                const stars = '\u2b50'.repeat(updatedRating) + '\u2606'.repeat(5 - updatedRating);
                                const editedEmbed = new EmbedBuilder()
                                    .setTitle(`\u2b50 Review #${reviewId} (Edited)`)
                                    .setColor(updatedRating >= 4 ? COLORS.SUCCESS : updatedRating >= 3 ? COLORS.WARNING : COLORS.ERROR)
                                    .addFields(
                                        { name: 'Rating', value: stars, inline: true },
                                        { name: 'Reviewer', value: review.anonymous ? '\ud83d\udc7b Anonymous' : `<@${user.id}>`, inline: true },
                                        { name: 'Edited', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true }
                                    )
                                    .setTimestamp()
                                    .setFooter({ text: `Review ID: ${reviewId} | ${config.BOT_WATERMARK}` });

                                if (updatedNote) {
                                    editedEmbed.setDescription(`\u201c${updatedNote}\u201d`);
                                }

                                if (!review.anonymous) {
                                    editedEmbed.setThumbnail(user.displayAvatarURL({ dynamic: true, size: 64 }));
                                }

                                await msg.edit({ embeds: [editedEmbed] }).catch(() => {});
                            }
                        }
                    } catch (e) {}
                }

                const stars = '\u2b50'.repeat(updatedRating) + '\u2606'.repeat(5 - updatedRating);
                await interaction.reply({
                    content: `${EMOJIS.success} Review #${reviewId} has been updated! ${stars}`,
                    flags: [MessageFlags.Ephemeral]
                });
            }

        } else if (commandName === 'verifyconfig') {
            const role = interaction.options.getRole('role');
            const channel = interaction.options.getChannel('channel');
            
            await db.run(
                'INSERT OR REPLACE INTO verification (guild_id, role_id, channel_id) VALUES (?, ?, ?)',
                [guild.id, role.id, channel.id]
            );
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.success} Verification System Configured`)
                .setDescription(`Verification channel set to ${channel}.\nVerified role set to ${role}.`)
                .setColor(COLORS.SUCCESS)
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'verify') {
            const config = await db.get('SELECT * FROM verification WHERE guild_id = ?', [guild.id]);
            
            if (!config) {
                return interaction.reply({
                    content: `${EMOJIS.error} Verification system not configured.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            if (interaction.channel.id !== config.channel_id) {
                return interaction.reply({
                    content: `${EMOJIS.error} Please use the verification channel.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            const role = guild.roles.cache.get(config.role_id);
            if (!role) {
                return interaction.reply({
                    content: `${EMOJIS.error} Verified role not found.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            if (member.roles.cache.has(role.id)) {
                return interaction.reply({
                    content: `${EMOJIS.info} You are already verified.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            await member.roles.add(role);
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.verification} Verification Successful`)
                .setDescription(`You have been verified and granted the **${role.name}** role.`)
                .setColor(COLORS.SUCCESS)
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
            
        } else if (commandName === 'autorole') {
            const role = interaction.options.getRole('role');
            
            await db.run(
                'INSERT OR REPLACE INTO autorole (guild_id, role_id) VALUES (?, ?)',
                [guild.id, role.id]
            );
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.success} Auto Role Configured`)
                .setDescription(`New members will automatically receive the **${role.name}** role.`)
                .setColor(COLORS.SUCCESS)
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'starboardconfig') {
            const channel = interaction.options.getChannel('channel');
            const threshold = interaction.options.getInteger('threshold') || 5;
            
            await db.run(
                'INSERT OR REPLACE INTO starboard (guild_id, channel_id, threshold) VALUES (?, ?, ?)',
                [guild.id, channel.id, threshold]
            );
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.success} Starboard Configured`)
                .setDescription(`Starboard channel set to ${channel}.\nMinimum stars required: ${threshold}`)
                .setColor(COLORS.SUCCESS)
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'autopublishconfig') {
            const channel = interaction.options.getChannel('channel');
            
            if (channel.type !== ChannelType.GuildAnnouncement) {
                return interaction.reply({
                    content: `${EMOJIS.error} Channel must be an announcement channel.`,
                    flags: [MessageFlags.Ephemeral]
                });
            }
            
            await db.run(
                'INSERT OR REPLACE INTO auto_publish (guild_id, channel_id) VALUES (?, ?)',
                [guild.id, channel.id]
            );
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.success} Auto Publish Configured`)
                .setDescription(`Messages in ${channel} will be auto-published.`)
                .setColor(COLORS.SUCCESS)
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'serverstats') {
            // Create or update server stats channels
            const categoryName = '📊 Server Stats';
            let category = guild.channels.cache.find(c => c.name === categoryName && c.type === ChannelType.GuildCategory);
            
            if (!category) {
                category = await guild.channels.create({
                    name: categoryName,
                    type: ChannelType.GuildCategory,
                    permissionOverwrites: [
                        {
                            id: guild.id,
                            deny: [PermissionFlagsBits.Connect]
                        }
                    ]
                });
            }
            
            // Members channel
            let membersChannel = guild.channels.cache.find(c => c.name.startsWith('👥 Members:') && c.parentId === category.id);
            if (!membersChannel) {
                membersChannel = await guild.channels.create({
                    name: `👥 Members: ${guild.memberCount}`,
                    type: ChannelType.GuildVoice,
                    parent: category.id,
                    permissionOverwrites: [
                        {
                            id: guild.id,
                            deny: [PermissionFlagsBits.Connect]
                        }
                    ]
                });
            } else {
                await membersChannel.setName(`👥 Members: ${guild.memberCount}`);
            }
            
            // Bots channel
            const botCount = guild.members.cache.filter(m => m.user.bot).size;
            let botsChannel = guild.channels.cache.find(c => c.name.startsWith('🤖 Bots:') && c.parentId === category.id);
            if (!botsChannel) {
                botsChannel = await guild.channels.create({
                    name: `🤖 Bots: ${botCount}`,
                    type: ChannelType.GuildVoice,
                    parent: category.id,
                    permissionOverwrites: [
                        {
                            id: guild.id,
                            deny: [PermissionFlagsBits.Connect]
                        }
                    ]
                });
            } else {
                await botsChannel.setName(`🤖 Bots: ${botCount}`);
            }
            
            // Save to database
            await db.run(
                'INSERT OR REPLACE INTO server_stats_channels (guild_id, category_id, members_channel_id, bots_channel_id) VALUES (?, ?, ?, ?)',
                [guild.id, category.id, membersChannel.id, botsChannel.id]
            );
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.stats} Server Stats Setup Complete`)
                .setDescription(`Server stats channels have been created/updated in the **${categoryName}** category.`)
                .addFields(
                    { name: 'Members Channel', value: membersChannel.toString(), inline: true },
                    { name: 'Bots Channel', value: botsChannel.toString(), inline: true }
                )
                .setColor(COLORS.SUCCESS)
                .setTimestamp()
                .setFooter({ text: config.BOT_WATERMARK });
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'features') {
            const embed = new EmbedBuilder()
                .setTitle(`${client.user.username} Features`)
                .setDescription('A comprehensive Discord bot with advanced features and security systems.')
                .setColor(COLORS.PRIMARY)
                .addFields(
                    { name: '🛡️ Advanced Security', value: '• Anti-Nuke System with auto-revert\n• Anti-Spam with multiple detection methods\n• Bad Words Filter with custom lists\n• Whitelist system for trusted users', inline: false },
                    { name: '🔧 Moderation Tools', value: '• Ban/Kick/Timeout/Warn systems\n• Custom warning system with logs\n• Message purging with user filtering\n• Role management commands', inline: false },
                    { name: '📨 DM System', value: '• DM specific users with beautiful embeds\n• DM all members with specific role\n• DM everyone in the server\n• DM logs tracking system', inline: false },
                    { name: '⚙️ Utility Features', value: '• Custom commands with placeholders\n• Status monitoring for websites\n• Giveaway system with automatic winner selection', inline: false },
                    { name: '🎫 Ticket System', value: '• Professional support ticket system\n• Multiple ticket types\n• Ticket claiming and management\n• Automatic transcripts\n• Rating system\n• Advanced statistics', inline: false },
                    { name: '👋 Community Features', value: '• Welcome/Goodbye messages with embeds\n• AFK system with automatic removal\n• Birthday announcements\n• Suggestion system with voting', inline: false },
                    { name: '🌐 Utility Commands', value: '• Weather information\n• Text translation\n• Currency conversion\n• QR code generation\n• Poll creation\n• Reminders system', inline: false },
                    { name: '📊 Information', value: '• Server/User/Role information\n• Avatar/Banner display\n• Member count tracking\n• Bot statistics and ping', inline: false },
                    { name: '🎭 Role Management', value: '• Auto role assignment\n• Verification system\n• Starboard for popular messages\n• Auto-publish for announcement channels', inline: false }
                )
                .setFooter({ text: config.BOT_WATERMARK })
                .setTimestamp();
            
            await interaction.reply({ embeds: [embed] });
            
        } else if (commandName === 'invite') {
            const invite = `https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`;
            
            const embed = new EmbedBuilder()
                .setTitle(`${EMOJIS.info} Bot Invite`)
                .setDescription(`[Click here to invite ${client.user.username} to your server](${invite})`)
                .addFields(
                    { name: 'Required Permissions', value: 'Administrator (for full functionality)', inline: false },
                    { name: 'Support', value: 'For support, please contact the bot owner.', inline: false }
                )
                .setColor(COLORS.INFO)
                .setFooter({ text: config.BOT_WATERMARK })
                .setTimestamp();
            
            await interaction.reply({ embeds: [embed] });
        
        } else if (commandName === 'ai') {
            const subcommand = interaction.options.getSubcommand();
            
            if (subcommand === 'enable') {
                const channel = interaction.options.getChannel('channel') || interaction.channel;
                const provider = interaction.options.getString('provider') || 'auto';
                const systemPrompt = interaction.options.getString('system_prompt');
                
                const success = await aiManager.enableChannel(guild.id, channel.id, {
                    provider,
                    system_prompt: systemPrompt
                });
                
                if (success) {
                    const embed = new EmbedBuilder()
                        .setTitle('🤖 AI Chat Enabled')
                        .setDescription(`AI chat has been enabled in ${channel}`)
                        .addFields(
                            { name: 'Provider', value: provider === 'auto' ? 'Auto (Fallback enabled)' : provider, inline: true },
                            { name: 'How to Use', value: `• Messages in ${channel} will get AI responses\n• Or mention the bot anywhere: ${client.user}`, inline: false }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK });
                    
                    await interaction.reply({ embeds: [embed] });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} Failed to enable AI chat. Please try again.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
            } else if (subcommand === 'disable') {
                const channel = interaction.options.getChannel('channel') || interaction.channel;
                
                const success = await aiManager.disableChannel(guild.id, channel.id);
                
                if (success) {
                    await interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setTitle('🤖 AI Chat Disabled')
                            .setDescription(`AI chat has been disabled in ${channel}`)
                            .setColor(COLORS.SUCCESS)
                            .setTimestamp()
                            .setFooter({ text: config.BOT_WATERMARK })
                        ]
                    });
                } else {
                    await interaction.reply({
                        content: `${EMOJIS.error} Failed to disable AI chat.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
            } else if (subcommand === 'status') {
                const providers = config.AI_CONFIG?.providers || {};
                const enabledProviders = Object.entries(providers)
                    .filter(([_, p]) => p.enabled && p.api_key)
                    .map(([name, p]) => `${name} (Priority: ${p.priority})`)
                    .join('\n') || 'None configured';
                
                const embed = new EmbedBuilder()
                    .setTitle('🤖 AI System Status')
                    .addFields(
                        { name: 'System Status', value: config.AI_CONFIG?.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                        { name: 'Fallback', value: config.AI_CONFIG?.settings?.fallback_enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                        { name: 'Available Providers', value: enabledProviders, inline: false },
                        { name: 'Rate Limit', value: `${config.AI_CONFIG?.settings?.rate_limit?.requests_per_user || 5} requests/minute per user`, inline: true },
                        { name: 'Max Tokens', value: `${config.AI_CONFIG?.settings?.max_tokens || 1000}`, inline: true },
                        { name: 'Temperature', value: `${config.AI_CONFIG?.settings?.temperature || 0.7}`, inline: true }
                    )
                    .setColor(COLORS.INFO)
                    .setTimestamp()
                    .setFooter({ text: config.BOT_WATERMARK });
                
                await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
                
            } else if (subcommand === 'stats') {
                const stats = await aiManager.getStats(guild.id);
                
                const embed = new EmbedBuilder()
                    .setTitle('📊 AI Usage Statistics')
                    .addFields(
                        { name: 'Total Messages', value: `${stats.total_messages || 0}`, inline: true },
                        { name: 'Total Tokens', value: `${stats.total_tokens || 0}`, inline: true },
                        { name: 'Avg Response Time', value: `${Math.round(stats.avg_response_time || 0)}ms`, inline: true },
                        { name: 'Primary Provider', value: stats.provider || 'N/A', inline: true }
                    )
                    .setColor(COLORS.INFO)
                    .setTimestamp()
                    .setFooter({ text: config.BOT_WATERMARK });
                
                await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
                
            } else if (subcommand === 'test') {
                const testMessage = interaction.options.getString('message');
                const provider = interaction.options.getString('provider');
                
                await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
                
                try {
                    const channelConfig = provider ? { provider } : {};
                    const result = await aiManager.getAIResponse(testMessage, channelConfig, interaction.guild.id, interaction.channel.id, interaction.user.id);
                    
                    const embed = new EmbedBuilder()
                        .setTitle('🧪 AI Test Response')
                        .addFields(
                            { name: 'Your Message', value: testMessage.substring(0, 1024), inline: false },
                            { name: 'AI Response', value: result.text.substring(0, 1024), inline: false },
                            { name: 'Provider', value: result.provider, inline: true },
                            { name: 'Tokens Used', value: `${result.tokens}`, inline: true },
                            { name: 'Response Time', value: `${result.responseTime}ms`, inline: true }
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK });
                    
                    await interaction.editReply({ embeds: [embed] });
                } catch (error) {
                    await interaction.editReply({
                        content: `${EMOJIS.error} Test failed: ${error.message}`
                    });
                }
                
            } else if (subcommand === 'channels') {
                const channels = await db.all(
                    'SELECT channel_id, provider FROM ai_channels WHERE guild_id = ? AND enabled = 1',
                    [guild.id]
                );
                
                if (channels.length === 0) {
                    return interaction.reply({
                        content: `${EMOJIS.info} No AI-enabled channels in this server.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                const channelList = channels.map(c => {
                    const ch = guild.channels.cache.get(c.channel_id);
                    return `• ${ch || 'Unknown Channel'} (Provider: ${c.provider})`;
                }).join('\n');
                
                const embed = new EmbedBuilder()
                    .setTitle('🤖 AI-Enabled Channels')
                    .setDescription(channelList)
                    .setColor(COLORS.INFO)
                    .setTimestamp()
                    .setFooter({ text: config.BOT_WATERMARK });
                
                await interaction.reply({ embeds: [embed], flags: [MessageFlags.Ephemeral] });
                
            } else if (subcommand === 'config') {
                const channel = interaction.options.getChannel('channel') || interaction.channel;
                const temperature = interaction.options.getNumber('temperature');
                const maxTokens = interaction.options.getInteger('max_tokens');
                
                const updates = {};
                if (temperature !== null) updates.temperature = temperature;
                if (maxTokens !== null) updates.max_tokens = maxTokens;
                
                if (Object.keys(updates).length === 0) {
                    return interaction.reply({
                        content: `${EMOJIS.error} Please specify at least one setting to update.`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
                
                try {
                    const setClauses = Object.keys(updates).map(key => `${key} = ?`).join(', ');
                    const values = [...Object.values(updates), guild.id, channel.id];
                    
                    await db.run(
                        `UPDATE ai_channels SET ${setClauses} WHERE guild_id = ? AND channel_id = ?`,
                        values
                    );
                    
                    const embed = new EmbedBuilder()
                        .setTitle('⚙️ AI Configuration Updated')
                        .setDescription(`Settings updated for ${channel}`)
                        .addFields(
                            Object.entries(updates).map(([key, value]) => ({
                                name: key.replace('_', ' ').toUpperCase(),
                                value: `${value}`,
                                inline: true
                            }))
                        )
                        .setColor(COLORS.SUCCESS)
                        .setTimestamp()
                        .setFooter({ text: config.BOT_WATERMARK });
                    
                    await interaction.reply({ embeds: [embed] });
                } catch (error) {
                    await interaction.reply({
                        content: `${EMOJIS.error} Failed to update configuration: ${error.message}`,
                        flags: [MessageFlags.Ephemeral]
                    });
                }
            }
        }
    } catch (error) {
        console.error(`Error handling command:`, error);
        
        const errorEmbed = new EmbedBuilder()
            .setTitle(`${EMOJIS.error} Command Error`)
            .setDescription('An error occurred while executing this command.')
            .setColor(COLORS.ERROR)
            .setFooter({ text: config.BOT_WATERMARK })
            .setTimestamp();
        
        await interaction.reply({ embeds: [errorEmbed], flags: [MessageFlags.Ephemeral] }).catch(() => {});
    }
});

// Reaction events for starboard and reaction roles
client.on('messageReactionAdd', async (reaction, user) => {
    if (user.bot) return;
    
    if (reaction.partial) {
        try {
            await reaction.fetch();
        } catch (error) {
            console.error('Error fetching reaction:', error);
            return;
        }
    }
    
    const { message } = reaction;
    if (!message.guild) return;
    
    // Starboard
    if (reaction.emoji.name === '⭐') {
        const starboardConfig = await db.get('SELECT * FROM starboard WHERE guild_id = ?', [message.guild.id]);
        if (!starboardConfig) return;
        
        // Check if message is already in starboard
        const existing = await db.get('SELECT * FROM starred_messages WHERE original_message_id = ?', [message.id]);
        
        // Get total star count
        const starReaction = message.reactions.cache.get('⭐');
        const starCount = starReaction ? starReaction.count : 1;
        
        if (starCount >= starboardConfig.threshold) {
            const starboardChannel = message.guild.channels.cache.get(starboardConfig.channel_id);
            if (!starboardChannel) return;
            
            const embed = new EmbedBuilder()
                .setColor(COLORS.WARNING)
                .setAuthor({
                    name: message.author.tag,
                    iconURL: message.author.displayAvatarURL()
                })
                .setDescription(message.content || '[No content]')
                .addFields(
                    { name: 'Source', value: `[Jump to message](${message.url})`, inline: true },
                    { name: 'Stars', value: `⭐ ${starCount}`, inline: true }
                )
                .setTimestamp(message.createdAt);
            
            if (message.attachments.size > 0) {
                const attachment = message.attachments.first();
                if (attachment.contentType?.startsWith('image/')) {
                    embed.setImage(attachment.url);
                }
            }
            
            if (existing) {
                // Update existing starboard message
                try {
                    const starboardMessage = await starboardChannel.messages.fetch(existing.starboard_message_id);
                    await starboardMessage.edit({ embeds: [embed] });
                    await db.run('UPDATE starred_messages SET stars = ? WHERE original_message_id = ?', [starCount, message.id]);
                } catch {
                    // Message not found, create new one
                    const newMessage = await starboardChannel.send({ embeds: [embed] });
                    await db.run('UPDATE starred_messages SET starboard_message_id = ?, stars = ? WHERE original_message_id = ?', [newMessage.id, starCount, message.id]);
                }
            } else {
                // Create new starboard message
                const starboardMessage = await starboardChannel.send({ embeds: [embed] });
                await db.run('INSERT INTO starred_messages (original_message_id, starboard_message_id, stars) VALUES (?, ?, ?)', [message.id, starboardMessage.id, starCount]);
            }
        }
    }
    
    // Reaction roles
    const emojiStr = reaction.emoji.id ? `${reaction.emoji.name}:${reaction.emoji.id}` : reaction.emoji.name;
    const reactionRole = await db.get('SELECT * FROM reaction_roles WHERE guild_id = ? AND message_id = ? AND emoji = ?', [message.guild.id, message.id, emojiStr]);
    
    if (reactionRole) {
        const member = await message.guild.members.fetch(user.id).catch(() => null);
        const role = message.guild.roles.cache.get(reactionRole.role_id);
        
        if (member && role) {
            await member.roles.add(role).catch(() => {});
        }
    }
});

client.on('messageReactionRemove', async (reaction, user) => {
    if (user.bot) return;
    
    if (reaction.partial) {
        try {
            await reaction.fetch();
        } catch (error) {
            console.error('Error fetching reaction:', error);
            return;
        }
    }
    
    const { message } = reaction;
    if (!message.guild) return;
    
    // Starboard update on removal
    if (reaction.emoji.name === '⭐') {
        const starboardConfig = await db.get('SELECT * FROM starboard WHERE guild_id = ?', [message.guild.id]);
        if (!starboardConfig) return;
        
        const existing = await db.get('SELECT * FROM starred_messages WHERE original_message_id = ?', [message.id]);
        if (!existing) return;
        
        const starboardChannel = message.guild.channels.cache.get(starboardConfig.channel_id);
        if (!starboardChannel) return;
        
        const starReaction = message.reactions.cache.get('⭐');
        const starCount = starReaction ? starReaction.count : 0;
        
        if (starCount < starboardConfig.threshold) {
            // Remove from starboard
            try {
                const starboardMessage = await starboardChannel.messages.fetch(existing.starboard_message_id);
                await starboardMessage.delete();
            } catch {}
            await db.run('DELETE FROM starred_messages WHERE original_message_id = ?', [message.id]);
        } else {
            // Update star count
            try {
                const starboardMessage = await starboardChannel.messages.fetch(existing.starboard_message_id);
                const embed = EmbedBuilder.from(starboardMessage.embeds[0]);
                const fields = embed.data.fields;
                if (fields && fields.length > 1) {
                    fields[1].value = `⭐ ${starCount}`;
                    embed.setFields(fields);
                    await starboardMessage.edit({ embeds: [embed] });
                }
                await db.run('UPDATE starred_messages SET stars = ? WHERE original_message_id = ?', [starCount, message.id]);
            } catch {}
        }
    }
    
    // Reaction roles removal
    const emojiStr = reaction.emoji.id ? `${reaction.emoji.name}:${reaction.emoji.id}` : reaction.emoji.name;
    const reactionRole = await db.get('SELECT * FROM reaction_roles WHERE guild_id = ? AND message_id = ? AND emoji = ?', [message.guild.id, message.id, emojiStr]);
    
    if (reactionRole) {
        const member = await message.guild.members.fetch(user.id).catch(() => null);
        const role = message.guild.roles.cache.get(reactionRole.role_id);
        
        if (member && role) {
            await member.roles.remove(role).catch(() => {});
        }
    }
});

// Member join/leave events
client.on('guildMemberAdd', async (member) => {
    // Track invite
    const usedInvite = await inviteTracker.findUsedInvite(member.guild);
    if (usedInvite) {
        await inviteTracker.trackInvite(member, usedInvite);
    }
    
    // Send welcome message
    await welcomeGoodbye.sendWelcomeMessage(member);
    
    // Assign auto role
    const autoRole = await db.get('SELECT * FROM autorole WHERE guild_id = ?', [member.guild.id]);
    if (autoRole && autoRole.role_id) {
        const role = member.guild.roles.cache.get(autoRole.role_id);
        if (role) {
            await member.roles.add(role).catch(() => {});
        }
    }
    
    // Restore sticky roles
    const stickyConfig = await db.get('SELECT * FROM sticky_config WHERE guild_id = ?', [member.guild.id]);
    if (stickyConfig && stickyConfig.enabled) {
        const stickyRoles = await db.get('SELECT * FROM sticky_roles WHERE guild_id = ? AND user_id = ?', [member.guild.id, member.id]);
        if (stickyRoles && stickyRoles.roles) {
            const roleIds = stickyRoles.roles.split(',').filter(id => id);
            for (const roleId of roleIds) {
                const role = member.guild.roles.cache.get(roleId);
                if (role) {
                    await member.roles.add(role).catch(() => {});
                }
            }
            // Remove from database after restoring
            await db.run('DELETE FROM sticky_roles WHERE guild_id = ? AND user_id = ?', [member.guild.id, member.id]);
        }
    }
    
    // Update server stats channels
    const statsChannels = await db.get('SELECT * FROM server_stats_channels WHERE guild_id = ?', [member.guild.id]);
    if (statsChannels) {
        const membersChannel = member.guild.channels.cache.get(statsChannels.members_channel_id);
        const botsChannel = member.guild.channels.cache.get(statsChannels.bots_channel_id);
        
        if (membersChannel) {
            await membersChannel.setName(`👥 Members: ${member.guild.memberCount}`).catch(() => {});
        }
        
        if (botsChannel) {
            const botCount = member.guild.members.cache.filter(m => m.user.bot).size;
            await botsChannel.setName(`🤖 Bots: ${botCount}`).catch(() => {});
        }
    }
});

client.on('guildMemberRemove', async (member) => {
    // Track member leave for invite system
    await inviteTracker.handleMemberLeave(member);
    
    // Send goodbye message
    await welcomeGoodbye.sendGoodbyeMessage(member);
    
    // Save sticky roles
    const stickyConfig = await db.get('SELECT * FROM sticky_config WHERE guild_id = ?', [member.guild.id]);
    if (stickyConfig && stickyConfig.enabled) {
        const roles = member.roles.cache.filter(r => r.id !== member.guild.id && !r.managed).map(r => r.id);
        if (roles.length > 0) {
            await db.run(
                'INSERT OR REPLACE INTO sticky_roles (guild_id, user_id, roles) VALUES (?, ?, ?)',
                [member.guild.id, member.id, roles.join(',')]
            );
        }
    }
    
    // Update server stats channels
    const statsChannels = await db.get('SELECT * FROM server_stats_channels WHERE guild_id = ?', [member.guild.id]);
    if (statsChannels) {
        const membersChannel = member.guild.channels.cache.get(statsChannels.members_channel_id);
        const botsChannel = member.guild.channels.cache.get(statsChannels.bots_channel_id);
        
        if (membersChannel) {
            await membersChannel.setName(`👥 Members: ${member.guild.memberCount}`).catch(() => {});
        }
        
        if (botsChannel) {
            const botCount = member.guild.members.cache.filter(m => m.user.bot).size;
            await botsChannel.setName(`🤖 Bots: ${botCount}`).catch(() => {});
        }
    }
});

// Invite tracking events
client.on('inviteCreate', async (invite) => {
    await inviteTracker.cacheInvites(invite.guild);
});

client.on('inviteDelete', async (invite) => {
    await inviteTracker.cacheInvites(invite.guild);
});

client.on('guildCreate', async (guild) => {
    await inviteTracker.cacheInvites(guild);
});

// Cleanup interval for spam trackers
setInterval(() => {
    const now = Date.now();
    
    // Clean spam tracker
    for (const [key, messages] of security.spamTracker.entries()) {
        const filtered = messages.filter(msg => now - msg.time < 60000); // Keep last 60 seconds
        if (filtered.length === 0) {
            security.spamTracker.delete(key);
        } else {
            security.spamTracker.set(key, filtered);
        }
    }
    
    // Clean mention spam tracker
    for (const [key, mentions] of security.mentionSpamTracker.entries()) {
        const filtered = mentions.filter(m => now - m.time < 60000);
        if (filtered.length === 0) {
            security.mentionSpamTracker.delete(key);
        } else {
            security.mentionSpamTracker.set(key, filtered);
        }
    }
    
    // Clean link spam tracker
    for (const [key, links] of security.linkSpamTracker.entries()) {
        const filtered = links.filter(l => now - l.time < 60000);
        if (filtered.length === 0) {
            security.linkSpamTracker.delete(key);
        } else {
            security.linkSpamTracker.set(key, filtered);
        }
    }
}, config.CLEANUP_INTERVAL || 3600000);

// Error handling
client.on('error', console.error);
process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});
process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
});

// Login
client.login(config.DISCORD_TOKEN).catch(console.error);
